package app.fuckrun.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.goSection
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import app.fuckrun.data.AppSettings
import app.fuckrun.data.PlanState
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.db.RunStatus
import app.fuckrun.data.shared.SessionStatus
import app.fuckrun.data.sportEnum
import app.fuckrun.data.state
import app.fuckrun.domain.*
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Inicio: el camino que más se usa. Arriba, Athlete Club y Perfil. La tarjeta principal muestra «Tu próxima actividad»
 * con el deporte (pictograma grande y chevrón en el propio selector) y una sola acción verde «Empezar actividad».
 * Con una actividad en curso, la primera tarjeta ofrece «Volver a la actividad» con el tiempo en directo.
 */
@Composable
fun HomeScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val runs by remember { g.runs.finishedRuns() }.collectAsStateWithLifecycle(emptyList())
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    val shared by remember { g.shared.mySessions() }.collectAsStateWithLifecycle(emptyList())
    val live by Tracking.live.collectAsStateWithLifecycle()
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()

    val sport = settings.lastFreeSport
    val week = PeriodRange.current(Period.WEEK)
    val weekRuns = ProgressCalc.inRange(runs, week)
    val totals = ProgressCalc.totals(weekRuns)
    val today = LocalDate.now()
    val next = planned.filter { it.state() == PlanState.PENDING }.minByOrNull { it.epochDay }
    val nextMeet = shared.filter { it.status == SessionStatus.SCHEDULED && it.startAt > System.currentTimeMillis() }.minByOrNull { it.startAt }
    val proposal = remember(settings.answersFor(sport), sport) { RecommendationEngine.proposal(settings.answersFor(sport), sport) }

    ScreenScaffold(title = null, header = {
        BrandName()
        Spacer(Modifier.weight(1f))
        // Retrato personalizable: abre el vestidor. Vista ligera (sin animación continua).
        Box(Modifier.size(52.dp).liquid(CircleShape, C.Control, onClickLabel = "Abrir el vestidor de tu avatar") { nav.navigate(Routes.wardrobe()) }
            .semantics { contentDescription = "Tu avatar. Abre el vestidor" }, contentAlignment = Alignment.Center) {
            Avatar(settings.avatarLook, settings.avatarOutfit, Modifier.size(48.dp), animated = false, portrait = true)
        }
        Spacer(Modifier.width(8.dp))
        RoundIconButton(Icons.Rounded.Person, "Perfil y ajustes") { nav.navigate(Routes.PROFILE) }
    }) {
        item {
            val l = live
            if (l != null) {
                val paused = l.status == RunStatus.PAUSED
                FCard(onClick = { nav.navigate(Routes.ACTIVE) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SportBadge(l.sport, 52.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (paused) "Actividad en pausa" else "Actividad en curso", style = T.Label)
                            Text(l.sport.label, style = T.Section)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(Fmt.duration(l.stats?.activeMs), style = T.HomeFigure.copy(fontSize = 52.sp),
                        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
                    Text("${Fmt.km(l.stats?.distanceM)} km", style = T.Label)
                    Spacer(Modifier.height(14.dp))
                    PillButton("Volver a la actividad", color = if (paused) C.Red else C.Green, icon = if (paused) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        big = true, modifier = Modifier.fillMaxWidth()) { nav.navigate(Routes.ACTIVE) }
                }
            } else FCard {
                Text("Tu próxima actividad", style = T.Label)
                Spacer(Modifier.height(10.dp))
                SportSelector(sport) { s -> scope.launch { g.profile.update { it.copy(lastFreeSport = s) } } }
                Spacer(Modifier.height(12.dp))
                PillButton("Empezar actividad", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true, modifier = Modifier.fillMaxWidth()) {
                    nav.navigate(Routes.prerun())
                }
            }
        }
        item { SectionTitle("Esta semana") }
        item {
            FCard(onClick = { nav.goSection(Routes.PROGRESS) }) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(Fmt.km(totals.distanceM, 1), style = T.HomeFigure)
                    Text(" km", style = T.Section.copy(color = C.TextSec), modifier = Modifier.padding(bottom = 6.dp))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Stat("Tiempo activo", Fmt.durationShort(totals.activeMs))
                    Stat("Sesiones", "${totals.sessions}")
                }
                if (weekRuns.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Sport.entries.forEach { s ->
                            val n = weekRuns.count { it.sportEnum == s }
                            if (n > 0) Row(Modifier.clip(RoundedCornerShape(50)).background(s.color.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Icon(s.icon, null, tint = s.color, modifier = Modifier.size(16.dp)); Text(" $n", style = T.Label.copy(color = C.Text))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    (0..6).forEach { i ->
                        val d = week.start.plusDays(i.toLong())
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(28.dp).clip(CircleShape).background(if (d in totals.activeDays) C.Chart else C.Control))
                            Text(Fmt.dayShort(d.dayOfWeek).take(1), style = T.Label)
                        }
                    }
                }
            }
        }
        if (next != null) {
            item { SectionTitle("Próxima sesión planificada") }
            item {
                val ns = Sport.of(next.sport)
                FCard(onClick = { nav.goSection(Routes.ROUTINES) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SportBadge(ns, 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            val d = LocalDate.ofEpochDay(next.epochDay)
                            Text(if (d == today) "Hoy" else Fmt.dateLong(d), style = T.Label)
                            Text(next.name, style = T.BodyStrong)
                            Text(listOfNotNull(next.targetMinutes?.let { "$it min" }, next.targetKm?.let { "${Fmt.km(it * 1000, 1)} km" }).joinToString(" · "), style = T.Label)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    PillButton("Preparar esta sesión", color = C.Control, textColor = C.Text, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {
                        nav.navigate(Routes.prerun(RunKind.ROUTINE, planned = next.id))
                    }
                }
            }
        }
        if (nextMeet != null) {
            item { SectionTitle("Siguiente encuentro") }
            item {
                FCard(onClick = { nav.navigate(Routes.clubSession(nextMeet.id)) }) {
                    val dt = Instant.ofEpochMilli(nextMeet.startAt).atZone(ZoneId.systemDefault())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SportBadge(Sport.of(nextMeet.sport), 44.dp); Spacer(Modifier.width(12.dp))
                        Column {
                            Text("${Fmt.dateLong(dt.toLocalDate())} · ${"%02d:%02d".format(dt.hour, dt.minute)}", style = T.Label)
                            Text(nextMeet.name, style = T.BodyStrong)
                            Text(nextMeet.meetingLabel, style = T.Label)
                        }
                    }
                }
            }
        }
        item { SectionTitle("Para hoy · ${sport.label}") }
        item {
            ProposalCard(proposal, onStart = { nav.navigate(Routes.prerun()) }, onSave = { p ->
                sheet.pick("¿Qué día?", (0..6).map { today.plusDays(it.toLong()) }, { if (it == today) "Hoy" else Fmt.dateLong(it) }, null) { d ->
                    scope.launch { planProposal(p, d, sport) }
                }
            }, onPersonalize = { nav.navigate(Routes.onboarding(sport.name)) })
        }
        item {
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                CircleAction(Icons.Rounded.CalendarMonth, "Rutinas") { nav.goSection(Routes.ROUTINES) }
                CircleAction(Icons.Rounded.EditNote, "Añadir manual") { nav.navigate(Routes.MANUAL) }
                CircleAction(Icons.Rounded.Tune, "Tu nivel") { nav.navigate(Routes.onboarding(sport.name)) }
                CircleAction(Icons.Rounded.HelpOutline, "Cómo se usa") { nav.navigate(Routes.tutorial(replay = true)) }
            }
        }
    }
}
