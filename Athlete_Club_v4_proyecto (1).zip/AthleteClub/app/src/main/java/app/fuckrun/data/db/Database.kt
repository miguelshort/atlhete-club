package app.fuckrun.data.db

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/*
 * ALMACENAMIENTO PERSONAL. Funciona sin cobertura y sin cuenta. Si hay cuenta, se copia en el espacio PRIVADO del
 * usuario (private/{uid}/… en Firestore, ver data/account/Sync.kt). Nunca se mezcla con los datos de Club.
 */

fun newSyncId(): String = UUID.randomUUID().toString()

object RunStatus { const val RECORDING = "RECORDING"; const val PAUSED = "PAUSED"; const val ENDED_UNSAVED = "ENDED_UNSAVED"; const val FINISHED = "FINISHED" }
object RunSource { const val GPS = "GPS"; const val MANUAL = "MANUAL" }
object RunKind { const val FREE = "FREE"; const val ROUTINE = "ROUTINE"; const val ROUTE = "ROUTE"; const val SHARED = "SHARED" }
object EventType { const val START = "START"; const val PAUSE = "PAUSE"; const val RESUME = "RESUME"; const val STOP = "STOP"
    const val INTERRUPTED = "INTERRUPTED"; const val SIGNAL_LOST = "SIGNAL_LOST"; const val SIGNAL_BACK = "SIGNAL_BACK"
    const val GPS_OFF = "GPS_OFF"; const val PERMISSION_LOST = "PERMISSION_LOST"; const val BATTERY_LOW = "BATTERY_LOW"; const val TIME_CHANGED = "TIME_CHANGED" }

@Entity(tableName = "runs")
data class RunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAtWall: Long,
    val endedAtWall: Long? = null,
    val status: String,
    val source: String = RunSource.GPS,
    val kind: String = RunKind.FREE,
    val plannedSessionId: Long? = null,
    val routeId: String? = null,
    val sharedSessionId: String? = null,
    val sharedSessionName: String? = null,
    val note: String = "",
    // Resumen calculado al terminar (null = sin datos suficientes; nunca valores inventados)
    val distanceM: Double? = null,
    val elapsedMs: Long = 0,
    val activeMs: Long = 0,
    val avgSpeedMps: Double? = null,
    val maxSpeedMps: Double? = null,
    val minMovingSpeedMps: Double? = null,
    val lostMs: Long = 0,           // tramo perdido por cierre de la app / reinicio
    val gapCount: Int = 0,
    val currentSegment: Int = 0,
    /** Deporte (Sport.name). Las carreras anteriores a la versión 2 se migran como RUN. */
    @ColumnInfo(defaultValue = "'RUN'") val sport: String = "RUN",
    /** Identificador estable entre dispositivos: evita duplicados al sincronizar y restaurar. */
    @ColumnInfo(defaultValue = "'-'") val syncId: String = newSyncId(),
    @ColumnInfo(defaultValue = "0") val updatedAt: Long = System.currentTimeMillis(),
    /** updatedAt confirmado por el servidor (0 = nunca). Pendiente si syncedAt < updatedAt. */
    @ColumnInfo(defaultValue = "0") val syncedAt: Long = 0,
    /** Desnivel positivo (m). null = sin medición fiable. */
    val elevationGainM: Double? = null,
    /** Mejor tramo continuo de 1 km (ms) para los récords de ritmo/velocidad. null = sin tramo válido. */
    val best1kMs: Long? = null,
    /** Fracción del trazado de la ruta verificada seguida (0–1). null = sin ruta o sin datos. */
    val routeCoverage: Double? = null,
)

@Entity(tableName = "points", indices = [Index("runId")],
    foreignKeys = [ForeignKey(entity = RunEntity::class, parentColumns = ["id"], childColumns = ["runId"], onDelete = ForeignKey.CASCADE)])
data class PointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runId: Long,
    val segment: Int,
    val wallMs: Long,
    val monoMs: Long,       // elapsedRealtime del fijo (solo comparable dentro del mismo arranque)
    val bootCount: Int,
    val lat: Double,
    val lon: Double,
    val accuracyM: Float,
    val altitudeM: Double?,
)

@Entity(tableName = "events", indices = [Index("runId")],
    foreignKeys = [ForeignKey(entity = RunEntity::class, parentColumns = ["id"], childColumns = ["runId"], onDelete = ForeignKey.CASCADE)])
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runId: Long,
    val type: String,
    val wallMs: Long,
    val monoMs: Long,
    val bootCount: Int,
    val detail: String = "",
)

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val kind: String,           // WEEKLY, MONTHLY, CUSTOM
    val startEpochDay: Long,
    val endEpochDay: Long,
    val templateId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'-'") val syncId: String = newSyncId(),
    @ColumnInfo(defaultValue = "0") val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val syncedAt: Long = 0,
)

@Entity(tableName = "planned", indices = [Index("routineId"), Index("epochDay")],
    foreignKeys = [ForeignKey(entity = RoutineEntity::class, parentColumns = ["id"], childColumns = ["routineId"], onDelete = ForeignKey.CASCADE)])
data class PlannedSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routineId: Long,
    val name: String,
    val epochDay: Long,
    val type: String,           // SessionType.name
    val targetMinutes: Int? = null,
    val targetKm: Double? = null,
    val intensity: String = "EASY",
    val structure: String = "",
    val routeId: String? = null,
    val reminderMinuteOfDay: Int? = null,
    val skipped: Boolean = false,
    val linkedRunId: Long? = null,
    @ColumnInfo(defaultValue = "'RUN'") val sport: String = "RUN",
    @ColumnInfo(defaultValue = "'-'") val syncId: String = newSyncId(),
    @ColumnInfo(defaultValue = "0") val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val syncedAt: Long = 0,
)

@Entity(tableName = "favorite_routes")
data class FavoriteRouteEntity(
    @PrimaryKey val routeId: String,
    val addedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val syncedAt: Long = 0,
)

/**
 * Registro de borrados. Impide que una restauración o un reintento recupere algo que el usuario eliminó.
 * key = syncId de actividad/rutina/sesión, o "fav:<routeId>" para favoritos.
 */
@Entity(tableName = "tombstones")
data class TombstoneEntity(
    @PrimaryKey val key: String,
    val kind: String,           // RUN, ROUTINE, PLANNED, FAVORITE
    val deletedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val syncedAt: Long = 0,
)

@Dao
interface RunDao {
    @Insert suspend fun insert(run: RunEntity): Long
    @Update suspend fun update(run: RunEntity)
    @Query("SELECT * FROM runs WHERE id = :id") suspend fun get(id: Long): RunEntity?
    @Query("SELECT * FROM runs WHERE id = :id") fun observe(id: Long): Flow<RunEntity?>
    @Query("SELECT * FROM runs WHERE status = 'FINISHED' ORDER BY startedAtWall DESC") fun finished(): Flow<List<RunEntity>>
    @Query("SELECT * FROM runs WHERE status != 'FINISHED' ORDER BY startedAtWall DESC LIMIT 1") suspend fun unfinished(): RunEntity?
    @Query("DELETE FROM runs WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM runs") suspend fun deleteAll()
    @Query("SELECT * FROM runs WHERE status = 'FINISHED'") suspend fun finishedOnce(): List<RunEntity>
    @Query("SELECT * FROM runs WHERE syncId = :syncId LIMIT 1") suspend fun bySyncId(syncId: String): RunEntity?
    @Query("SELECT COUNT(*) FROM runs WHERE status = 'FINISHED'") suspend fun finishedCount(): Int
    @Query("SELECT COUNT(*) FROM runs WHERE status = 'FINISHED' AND syncedAt < updatedAt") fun pendingCount(): Flow<Int>
    @Query("UPDATE runs SET syncedAt = :at WHERE id = :id") suspend fun markSynced(id: Long, at: Long)
    @Insert suspend fun insertPoints(p: List<PointEntity>)
    @Insert suspend fun insertEvents(e: List<EventEntity>)

    @Insert suspend fun insertPoint(p: PointEntity)
    @Query("SELECT * FROM points WHERE runId = :runId ORDER BY segment, id") suspend fun points(runId: Long): List<PointEntity>
    @Query("SELECT * FROM points WHERE runId = :runId ORDER BY id DESC LIMIT 1") suspend fun lastPoint(runId: Long): PointEntity?

    @Insert suspend fun insertEvent(e: EventEntity)
    @Query("SELECT * FROM events WHERE runId = :runId ORDER BY id") suspend fun events(runId: Long): List<EventEntity>
}

@Dao
interface RoutineDao {
    @Insert suspend fun insert(r: RoutineEntity): Long
    @Update suspend fun update(r: RoutineEntity)
    @Query("DELETE FROM routines WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT * FROM routines ORDER BY startEpochDay DESC") fun routines(): Flow<List<RoutineEntity>>
    @Insert suspend fun insertPlanned(p: PlannedSessionEntity): Long
    @Insert suspend fun insertPlannedAll(p: List<PlannedSessionEntity>)
    @Update suspend fun updatePlanned(p: PlannedSessionEntity)
    @Query("DELETE FROM planned WHERE id = :id") suspend fun deletePlanned(id: Long)
    @Query("SELECT * FROM planned WHERE id = :id") suspend fun planned(id: Long): PlannedSessionEntity?
    @Query("SELECT * FROM planned ORDER BY epochDay") fun allPlanned(): Flow<List<PlannedSessionEntity>>
    @Query("SELECT * FROM planned") suspend fun allPlannedOnce(): List<PlannedSessionEntity>
    @Query("SELECT * FROM planned WHERE linkedRunId = :runId LIMIT 1") suspend fun byRun(runId: Long): PlannedSessionEntity?
    @Query("UPDATE planned SET linkedRunId = NULL, updatedAt = CAST(strftime('%s','now') AS INTEGER) * 1000 WHERE linkedRunId = :runId") suspend fun unlinkRun(runId: Long)
    @Query("DELETE FROM routines") suspend fun deleteAll()
    @Query("SELECT * FROM routines") suspend fun routinesOnce(): List<RoutineEntity>
    @Query("SELECT * FROM routines WHERE id = :id") suspend fun routine(id: Long): RoutineEntity?
    @Query("SELECT * FROM routines WHERE syncId = :syncId LIMIT 1") suspend fun routineBySyncId(syncId: String): RoutineEntity?
    @Query("SELECT * FROM planned WHERE syncId = :syncId LIMIT 1") suspend fun plannedBySyncId(syncId: String): PlannedSessionEntity?
    @Query("SELECT * FROM planned WHERE routineId = :routineId") suspend fun plannedOfRoutine(routineId: Long): List<PlannedSessionEntity>
    @Query("UPDATE routines SET syncedAt = :at WHERE id = :id") suspend fun markRoutineSynced(id: Long, at: Long)
    @Query("UPDATE planned SET syncedAt = :at WHERE id = :id") suspend fun markPlannedSynced(id: Long, at: Long)
    @Query("SELECT (SELECT COUNT(*) FROM routines WHERE syncedAt < updatedAt) + (SELECT COUNT(*) FROM planned WHERE syncedAt < updatedAt)") fun pendingCount(): Flow<Int>
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorite_routes") fun all(): Flow<List<FavoriteRouteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun add(f: FavoriteRouteEntity)
    @Query("DELETE FROM favorite_routes WHERE routeId = :id") suspend fun remove(id: String)
    @Query("DELETE FROM favorite_routes") suspend fun deleteAll()
    @Query("SELECT * FROM favorite_routes") suspend fun allOnce(): List<FavoriteRouteEntity>
    @Query("UPDATE favorite_routes SET syncedAt = :at WHERE routeId = :id") suspend fun markSynced(id: String, at: Long)
    @Query("SELECT COUNT(*) FROM favorite_routes WHERE syncedAt = 0") fun pendingCount(): Flow<Int>
}

/**
 * Movimientos de puntos (abonos por actividad y récord, cargos por compra). El identificador es estable
 * («act:<syncId>», «rec:<syncId>:<categoría>», «buy:<artículo>»): guardar dos veces, reintentar o sincronizar
 * desde otro móvil conserva un único abono y un único cargo.
 */
@Entity(tableName = "ledger")
data class LedgerEntity(
    @PrimaryKey val id: String,
    val amount: Int,
    val reason: String,
    val runSyncId: String? = null,
    val itemId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val syncedAt: Long = 0,
)

/**
 * Artículos conseguidos: comprados con puntos (BOUGHT) o concedidos por un logro (ACHIEVEMENT; MILESTONE en la v3).
 * Identificador por cuenta y premio: cada base de datos es de un perfil, así que la clave es el propio artículo.
 * Las prendas iniciales no se guardan: son gratuitas. Eliminar una actividad NO retira lo ya conseguido.
 */
@Entity(tableName = "inventory")
data class InventoryEntity(
    @PrimaryKey val itemId: String,
    val how: String,            // BOUGHT o MILESTONE
    val runSyncId: String? = null,
    val acquiredAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val syncedAt: Long = 0,
)

@Dao
interface RewardsDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertEntry(e: LedgerEntity): Long
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertItem(i: InventoryEntity): Long
    @Query("SELECT COALESCE(SUM(amount), 0) FROM ledger") fun balance(): Flow<Int>
    @Query("SELECT COALESCE(SUM(amount), 0) FROM ledger") suspend fun balanceOnce(): Int
    @Query("SELECT * FROM ledger ORDER BY createdAt DESC") fun entries(): Flow<List<LedgerEntity>>
    @Query("SELECT * FROM ledger WHERE runSyncId = :runSyncId") fun entriesForRun(runSyncId: String): Flow<List<LedgerEntity>>
    @Query("SELECT COUNT(*) FROM ledger WHERE id = :id") suspend fun hasEntry(id: String): Int
    @Query("SELECT * FROM inventory") fun inventory(): Flow<List<InventoryEntity>>
    @Query("SELECT * FROM inventory") suspend fun inventoryOnce(): List<InventoryEntity>
    @Query("SELECT * FROM ledger") suspend fun entriesOnce(): List<LedgerEntity>
    @Query("UPDATE ledger SET syncedAt = :at WHERE id = :id") suspend fun markEntrySynced(id: String, at: Long)
    @Query("UPDATE inventory SET syncedAt = :at WHERE itemId = :id") suspend fun markItemSynced(id: String, at: Long)
    @Query("SELECT (SELECT COUNT(*) FROM ledger WHERE syncedAt = 0) + (SELECT COUNT(*) FROM inventory WHERE syncedAt = 0)") fun pendingCount(): Flow<Int>
    @Query("SELECT COALESCE(SUM(amount), 0) FROM ledger WHERE syncedAt = 0") fun pendingPoints(): Flow<Int>
    @Query("SELECT * FROM inventory WHERE runSyncId = :runSyncId AND how != 'BOUGHT'") fun unlockedByRun(runSyncId: String): Flow<List<InventoryEntity>>
    @Query("SELECT COUNT(*) FROM inventory WHERE syncedAt = 0") fun pendingItems(): Flow<Int>
}

@Dao
interface TombstoneDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(t: TombstoneEntity)
    @Query("SELECT * FROM tombstones") suspend fun all(): List<TombstoneEntity>
    @Query("SELECT `key` FROM tombstones") suspend fun keys(): List<String>
    @Query("UPDATE tombstones SET syncedAt = :at WHERE `key` = :key") suspend fun markSynced(key: String, at: Long)
    @Query("SELECT COUNT(*) FROM tombstones WHERE syncedAt = 0") fun pendingCount(): Flow<Int>
    @Query("DELETE FROM tombstones") suspend fun deleteAll()
}

@Database(entities = [RunEntity::class, PointEntity::class, EventEntity::class, RoutineEntity::class,
    PlannedSessionEntity::class, FavoriteRouteEntity::class, TombstoneEntity::class, LedgerEntity::class, InventoryEntity::class],
    version = 4, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun runs(): RunDao
    abstract fun routines(): RoutineDao
    abstract fun favorites(): FavoriteDao
    abstract fun tombstones(): TombstoneDao
    abstract fun rewards(): RewardsDao

    companion object {
        /** Nombre histórico: el perfil invitado conserva este archivo para que la actualización no pierda entrenamientos. */
        const val GUEST_DB = "fuckrun-personal.db"
        fun nameFor(accountUid: String?) = if (accountUid == null) GUEST_DB else "athlete-$accountUid.db"

        fun build(ctx: Context, accountUid: String? = null) =
            Room.databaseBuilder(ctx, AppDatabase::class.java, nameFor(accountUid)).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build()

        /**
         * v1 → v2: deporte (las carreras existentes quedan como RUN), identificadores estables, marcas de sincronización,
         * desnivel y tabla de borrados. No se borra ni recrea ninguna tabla: los entrenamientos se conservan.
         */
        /**
         * v3 → v4: cobertura de ruta verificada por actividad y traducción de los identificadores de artículos de la v3 a
         * los actuales (los accesorios por hito pasan a ser las piezas de logro equivalentes). No se borra nada conseguido.
         */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE runs ADD COLUMN routeCoverage REAL")
                for ((old, new) in app.fuckrun.domain.art.GearCatalog.renamed) {
                    db.execSQL("INSERT OR IGNORE INTO inventory (itemId, how, runSyncId, acquiredAt, syncedAt) " +
                        "SELECT '$new', CASE how WHEN 'MILESTONE' THEN 'ACHIEVEMENT' ELSE how END, runSyncId, acquiredAt, 0 FROM inventory WHERE itemId = '$old'")
                    db.execSQL("DELETE FROM inventory WHERE itemId = '$old'")
                    db.execSQL("UPDATE ledger SET itemId = '$new' WHERE itemId = '$old'")
                }
            }
        }

        /** v2 → v3: mejor kilómetro por actividad, movimientos de puntos e inventario del avatar. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE runs ADD COLUMN best1kMs INTEGER")
                db.execSQL("CREATE TABLE IF NOT EXISTS `ledger` (`id` TEXT NOT NULL, `amount` INTEGER NOT NULL, `reason` TEXT NOT NULL, " +
                    "`runSyncId` TEXT, `itemId` TEXT, `createdAt` INTEGER NOT NULL, `syncedAt` INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(`id`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `inventory` (`itemId` TEXT NOT NULL, `how` TEXT NOT NULL, `runSyncId` TEXT, " +
                    "`acquiredAt` INTEGER NOT NULL, `syncedAt` INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(`itemId`))")
            }
        }

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE runs ADD COLUMN sport TEXT NOT NULL DEFAULT 'RUN'")
                db.execSQL("ALTER TABLE runs ADD COLUMN syncId TEXT NOT NULL DEFAULT '-'")
                db.execSQL("ALTER TABLE runs ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE runs ADD COLUMN syncedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE runs ADD COLUMN elevationGainM REAL")
                db.execSQL("ALTER TABLE routines ADD COLUMN syncId TEXT NOT NULL DEFAULT '-'")
                db.execSQL("ALTER TABLE routines ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE routines ADD COLUMN syncedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE planned ADD COLUMN sport TEXT NOT NULL DEFAULT 'RUN'")
                db.execSQL("ALTER TABLE planned ADD COLUMN syncId TEXT NOT NULL DEFAULT '-'")
                db.execSQL("ALTER TABLE planned ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE planned ADD COLUMN syncedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE favorite_routes ADD COLUMN syncedAt INTEGER NOT NULL DEFAULT 0")
                // Identificadores aleatorios con formato UUID v4 para las filas existentes.
                val uuid = "lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || " +
                    "substr('89ab', 1 + (abs(random()) % 4), 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6)))"
                db.execSQL("UPDATE runs SET syncId = $uuid, updatedAt = COALESCE(endedAtWall, startedAtWall)")
                db.execSQL("UPDATE routines SET syncId = $uuid, updatedAt = createdAt")
                db.execSQL("UPDATE planned SET syncId = $uuid, updatedAt = 1")
                db.execSQL("CREATE TABLE IF NOT EXISTS `tombstones` (`key` TEXT NOT NULL, `kind` TEXT NOT NULL, `deletedAt` INTEGER NOT NULL, " +
                    "`syncedAt` INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(`key`))")
            }
        }
    }
}
