package app.fuckrun.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.*
import app.fuckrun.data.db.FavoriteRouteEntity
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.db.TombstoneEntity
import app.fuckrun.domain.*
import app.fuckrun.domain.Sport
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

/**
 * «Rutas en {municipio}»: hasta cinco recorridos reales y distintos, aptos para el deporte elegido, con trazado de
 * OpenStreetMap. Cambiar de ciudad o deporte renueva el conjunto; consultar una ficha o volver conserva las mismas cinco.
 */
@Composable
fun RoutesScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val favs by remember { g.db.favorites().all() }.collectAsStateWithLifecycle(emptyList())
    var sportId by rememberSaveable { mutableStateOf<String?>(null) }
    val sport = sportId?.let { Sport.of(it) } ?: settings.lastFreeSport
    val a = settings.answers
    val municipality = a.municipality?.let { m -> g.municipalities.all.firstOrNull { it.name == m && it.province == a.province } }
    var filter by remember { mutableStateOf(RouteFilter()) }
    var reload by remember { mutableIntStateOf(0) }
    var result by remember(municipality?.key, sport) { mutableStateOf<OsmRoutes.CityResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var nearby by remember(municipality?.key, sport) { mutableStateOf<List<OsmRoutes.NearbyRoute>?>(null) }
    var nearbyLoading by remember { mutableStateOf(false) }

    fun accepts(r: VerifiedRoute) = (filter.minKm == null || r.distanceM >= filter.minKm!! * 1000) &&
        (filter.maxKm == null || r.distanceM <= filter.maxKm!! * 1000) &&
        (filter.surface == null || r.surface == filter.surface) &&
        (!filter.flatOnly || (r.elevationGainM != null && r.elevationGainM < 30))

    LaunchedEffect(municipality?.key, sport, filter, reload) {
        val m = municipality ?: return@LaunchedEffect
        loading = true
        if (result == null) result = g.osm.cached(m, sport)
        result = g.osm.forCity(m, sport, ::accepts, refresh = reload > 0)
        loading = false
    }

    fun pickCity() = sheet.page("Elige tu ciudad") {
        MunicipalityPicker(null) { m -> if (m != null) { scope.launch { g.profile.update { it.copy(answers = it.answers.copy(municipality = m.name, province = m.province)) } }; sheet.hide() } }
    }
    fun open(r: VerifiedRoute) = sheet.page(r.name) {
        val fav = favs.any { it.routeId == r.id }
        RouteDetail(r, fav, onFav = { scope.launch { toggleFavorite(r, fav) } },
            onStart = { sheet.hide(); nav.navigate(Routes.prerun(RunKind.ROUTE, route = r.id)) })
    }

    val res = result
    val title = municipality?.let { "Rutas en ${it.name}" } ?: "Rutas"
    var mapMode by rememberSaveable { mutableStateOf(true) }
    if (mapMode && municipality != null) {
        RoutesMap(title, sport, res?.routes.orEmpty(), res?.center, loading && res == null, onSport = { sportId = it.name }, onCity = { pickCity() },
            onList = { mapMode = false }, onOpen = { open(it) })
        return
    }
    ScreenScaffold(title, header = { if (municipality != null) RoundIconButton(Icons.Rounded.Map, "Ver en el mapa") { mapMode = true } }) {
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                SportSelector(sport, compact = true) { sportId = it.name }
                Chip(municipality?.name ?: "Elegir ciudad", Icons.Rounded.LocationCity, selected = false) { pickCity() }
                val active = listOfNotNull(filter.minKm, filter.maxKm, filter.surface).size + if (filter.flatOnly) 1 else 0
                Chip(if (active > 0) "Filtros ($active)" else "Filtros", Icons.Rounded.Tune, selected = active > 0) {
                    sheet.show { FilterPanel(filter, g.routes.surfaces + listOf("Asfalto", "Tierra", "Grava compactada").distinct()) { filter = it; sheet.hide() } }
                }
            }
        }
        if (municipality == null) {
            item {
                FCard {
                    Text("Elige tu ciudad", style = T.Section)
                    Text("Buscaremos recorridos reales, señalizados y aptos para ${sport.label.lowercase()}.", style = T.Body.copy(color = C.TextSec))
                    Spacer(Modifier.height(12.dp))
                    PillButton("Elegir municipio", color = C.Text, textColor = C.Bg, icon = Icons.Rounded.LocationCity) { pickCity() }
                }
            }
        } else {
            item {
                val n = res?.routes?.size ?: 0
                val status = when {
                    loading && res == null -> "Buscando rutas en OpenStreetMap…"
                    n >= RouteSelect.TARGET -> "${RouteSelect.TARGET} rutas para ${sport.label.lowercase()}" + (res?.totalInCity?.takeIf { it > 5 }?.let { " de $it encontradas" } ?: "")
                    n in 1..4 -> "$n ${if (n == 1) "ruta" else "rutas"} en tu ciudad"
                    res != null -> "Aún no hay rutas verificadas para esta zona"
                    else -> ""
                }
                Column(Modifier.padding(horizontal = 4.dp)) {
                    if (status.isNotEmpty()) Text(status, style = T.BodyStrong)
                    if (res != null) {
                        val t = res.fetchedAt
                        if (t != null) {
                            val d = Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault()).toLocalDate()
                            Text((if (loading) "Actualizando… · " else if (res.fromCache || res.error != null) "Sin conexión: última selección guardada · " else "Actualizado · ") + Fmt.date(d), style = T.Label)
                        }
                        val err = res.error
                        if (err != null && res.routes.isEmpty()) Text(err, style = T.Label.copy(color = C.Red))
                    }
                }
            }
            res?.routes?.forEach { r ->
                item(key = r.id) { RouteCard(r, favs.any { it.routeId == r.id }, null, onOpen = { open(r) }, onFav = { f -> scope.launch { toggleFavorite(r, f) } }) }
            }
            val n = res?.routes?.size ?: 0
            if (res != null && !loading && n < RouteSelect.TARGET) item {
                FCard {
                    if (n == 0) {
                        Text("No hay recorridos con estos datos", style = T.Section)
                        Text("Prueba otros filtros, busca en los alrededores o prepara una sesión por tiempo o distancia.", style = T.Body.copy(color = C.TextSec))
                        Spacer(Modifier.height(10.dp))
                    }
                    val center = res.center
                    if (center != null) PillButton(if (nearbyLoading) "Buscando…" else "Ampliar a los alrededores (15 km)", color = C.Control, textColor = C.Text,
                        icon = Icons.Rounded.TravelExplore, enabled = !nearbyLoading, modifier = Modifier.fillMaxWidth()) {
                        nearbyLoading = true
                        scope.launch {
                            nearby = runCatching { g.osm.nearby(municipality, sport, center, 15, res.routes.map { it.id }.toSet()) }.getOrDefault(emptyList())
                            nearbyLoading = false
                        }
                    }
                    if (n == 0) {
                        Spacer(Modifier.height(8.dp))
                        PillButton("Cambiar filtros", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Tune, modifier = Modifier.fillMaxWidth()) { filter = RouteFilter() }
                        Spacer(Modifier.height(8.dp))
                        PillButton("Preparar una sesión por tiempo", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Timer, modifier = Modifier.fillMaxWidth()) {
                            nav.navigate(Routes.prerun())
                        }
                    }
                }
            }
            nearby?.let { list ->
                item { SectionTitle("Alrededores de ${municipality.name}") }
                if (list.isEmpty()) item { Text("No hay más recorridos aptos a menos de 15 km.", style = T.Label, modifier = Modifier.padding(4.dp)) }
                list.forEach { nb ->
                    item(key = "nb" + nb.route.id) {
                        RouteCard(nb.route, favs.any { it.routeId == nb.route.id }, "${nb.municipality ?: "Otro municipio"} · a ${Fmt.km(nb.distanceKm * 1000, 1)} km",
                            onOpen = { open(nb.route) }, onFav = { f -> scope.launch { toggleFavorite(nb.route, f) } })
                    }
                }
            }
            if (res != null && !loading) item {
                Text("Actualizar rutas", style = T.Body.copy(color = C.Blue),
                    modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50)) { reload++ }.padding(horizontal = 8.dp, vertical = 12.dp))
            }
        }
        val favRoutes = favs.mapNotNull { g.routes.byId(it.routeId) }
        if (favRoutes.isNotEmpty()) {
            item { SectionTitle("Tus favoritas") }
            favRoutes.forEach { r -> item(key = "fav" + r.id) { RouteCard(r, true, r.municipality.ifBlank { null }, onOpen = { open(r) }, onFav = { scope.launch { toggleFavorite(r, true) } }) } }
        }
        item {
            Text("Rutas y mapas: © colaboradores de OpenStreetMap (ODbL). La modalidad sale de las etiquetas del recorrido; comprueba el estado antes de salir.",
                style = T.Label, modifier = Modifier.padding(4.dp))
        }
    }
}

/** Favoritos: al quitar uno se deja constancia para que la copia de la cuenta no lo recupere. */
private suspend fun toggleFavorite(r: VerifiedRoute, fav: Boolean) {
    val g = FuckrunApp.graph
    if (fav) { g.db.favorites().remove(r.id); g.db.tombstones().put(TombstoneEntity("fav:${r.id}", "FAVORITE")) }
    else { g.osm.remember(r); g.db.favorites().add(FavoriteRouteEntity(r.id)) }
    if (g.accountUid != null) FuckrunApp.instance.sync.request()
}

/** Tarjeta: miniatura del trazado real, nombre, distancia y hasta dos datos útiles. */
@Composable
private fun RouteCard(r: VerifiedRoute, fav: Boolean, subtitle: String?, onOpen: () -> Unit, onFav: (Boolean) -> Unit) {
    val facts = listOfNotNull(r.surface, r.elevationGainM?.let { "+${it.toInt()} m" }, r.shape.label).take(2)
    FCard(onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TrackThumb(r.track, Modifier.size(72.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, style = T.BodyStrong, maxLines = 2)
                Text((listOf("${Fmt.km(r.distanceM, 1)} km") + facts).joinToString(" · "), style = T.Label)
                if (subtitle != null) Text(subtitle, style = T.Label)
            }
            RoundIconButton(if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder, if (fav) "Quitar de favoritas" else "Guardar como favorita",
                bg = androidx.compose.ui.graphics.Color.Transparent, tint = if (fav) C.Amber else C.TextSec) { onFav(fav) }
        }
    }
}

@Composable
fun TrackThumb(track: List<LatLon>, modifier: Modifier) {
    val line = C.Blue; val bg = C.Surface; val start = C.Green
    Canvas(modifier.clip(RoundedCornerShape(16.dp)).background(bg).semantics { contentDescription = "Miniatura del trazado" }) {
        if (track.size < 2) return@Canvas
        val minLat = track.minOf { it.lat }; val maxLat = track.maxOf { it.lat }
        val minLon = track.minOf { it.lon }; val maxLon = track.maxOf { it.lon }
        val cos = kotlin.math.cos(Math.toRadians((minLat + maxLat) / 2))
        val w = ((maxLon - minLon) * cos).coerceAtLeast(1e-6); val h = (maxLat - minLat).coerceAtLeast(1e-6)
        val pad = 8.dp.toPx(); val s = minOf((size.width - 2 * pad) / w, (size.height - 2 * pad) / h).toFloat()
        val ox = (size.width - (w * s).toFloat()) / 2; val oy = (size.height - (h * s).toFloat()) / 2
        fun p(l: LatLon) = Offset(ox + ((l.lon - minLon) * cos * s).toFloat(), oy + ((maxLat - l.lat) * s).toFloat())
        val path = Path().apply { moveTo(p(track[0]).x, p(track[0]).y); track.drop(1).forEach { val q = p(it); lineTo(q.x, q.y) } }
        drawPath(path, line, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(start, 4.dp.toPx(), p(track.first()))
    }
}

@Composable
private fun Chip(text: String, icon: ImageVector, selected: Boolean, tint: androidx.compose.ui.graphics.Color? = null, onClick: () -> Unit) {
    val bg = when { tint != null -> tint.copy(alpha = 0.16f); selected -> C.Text; else -> C.Control }
    val fg = if (tint == null && selected) C.Bg else C.Text
    Row(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), bg, role = androidx.compose.ui.semantics.Role.DropdownList, onClick = onClick).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint ?: fg, modifier = Modifier.size(20.dp))
        Text(" $text", style = T.Body.copy(color = fg), maxLines = 1)
        Icon(Icons.Rounded.ExpandMore, null, tint = tint ?: fg, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun FilterPanel(f0: RouteFilter, surfaces: List<String>, onApply: (RouteFilter) -> Unit) {
    var f by remember { mutableStateOf(f0) }
    Column(Modifier.padding(12.dp)) {
        MenuTitle("Filtros")
        Text("Distancia", style = T.Label, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
        val ranges = listOf(null to null, null to 5.0, 5.0 to 10.0, 10.0 to null)
        ChoiceChips(ranges, { (lo, hi) -> when { lo == null && hi == null -> "Cualquiera"; lo == null -> "Hasta ${hi!!.toInt()} km"; hi == null -> "Más de ${lo.toInt()} km"; else -> "${lo.toInt()}–${hi.toInt()} km" } },
            { it == (f.minKm to f.maxKm) }) { f = f.copy(minKm = it.first, maxKm = it.second) }
        Text("Superficie", style = T.Label, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
        ChoiceChips(listOf<String?>(null) + surfaces, { it ?: "Cualquiera" }, { it == f.surface }) { f = f.copy(surface = it) }
        Text("Desnivel", style = T.Label, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
        ChoiceChips(listOf(false, true), { if (it) "Solo llanas (dato conocido)" else "Cualquiera" }, { it == f.flatOnly }) { f = f.copy(flatOnly = it) }
        Spacer(Modifier.height(14.dp))
        PillButton("Aplicar", color = C.Text, textColor = C.Bg, modifier = Modifier.fillMaxWidth()) { onApply(f) }
        Spacer(Modifier.height(8.dp))
        PillButton("Quitar filtros", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { onApply(RouteFilter()) }
    }
}

@Composable
private fun RouteDetail(r: VerifiedRoute, fav: Boolean, onFav: () -> Unit, onStart: () -> Unit) {
    val uri = LocalUriHandler.current
    Text(listOf(r.municipality, r.province).filter { it.isNotBlank() }.joinToString(" · "), style = T.Label)
    Spacer(Modifier.height(10.dp))
    RunMap(listOf(r.track), Modifier.fillMaxWidth().height(240.dp), markers = listOf(MapMarker(LatLon(r.start.lat, r.start.lon), "Salida")), showGaps = false)
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PillButton(if (fav) "Guardada" else "Guardar", color = C.Control, textColor = C.Text, icon = if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
            modifier = Modifier.weight(1f)) { onFav() }
        PillButton("Usar esta ruta", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.weight(1f)) { onStart() }
    }
    Spacer(Modifier.height(12.dp))
    Detail("Distancia", "${Fmt.km(r.distanceM, 2)} km")
    Detail("Salida", "${r.start.label} (${"%.5f".format(java.util.Locale.US, r.start.lat)}, ${"%.5f".format(java.util.Locale.US, r.start.lon)})")
    Detail("Forma", r.shape.label)
    Detail("Superficie", r.surface ?: "Sin dato verificado")
    Detail("Desnivel", r.elevationGainM?.let { "${it.toInt()} m positivos" } ?: "Sin dato fiable")
    Detail("Apta para", routeSports(r).joinToString { it.label })
    if (r.verifiedAttributes.isNotEmpty()) Detail("Datos de la ruta", r.verifiedAttributes.joinToString(" · "))
    Detail("Restricciones verificadas", if (r.incidents.isEmpty()) "Ninguna indicada en la fuente" else r.incidents.joinToString("\n") { it.text })
    Detail("Fuente", "${r.source.name} (${r.source.license})" + if (r.reviewedAt.isNotBlank()) " · revisada el ${r.reviewedAt}" else "")
    r.source.url?.let { url ->
        Text("Ver en OpenStreetMap", style = T.Body.copy(color = C.Blue),
            modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50)) { runCatching { uri.openUri(url) } }.padding(vertical = 12.dp))
    }
    Text("No describimos un recorrido como seguro, iluminado o accesible salvo que la fuente lo indique. Comprueba el estado antes de salir.", style = T.Label)
}


/**
 * Rutas sobre el mapa: el mapa se dibuja a tamaño real y es la escena que muestrean el selector «Deporte» y los
 * controles flotantes (y, por la escena raíz, la barra inferior). Las fichas de la parte baja son superficies de lectura.
 */
@Composable
private fun RoutesMap(title: String, sport: Sport, routes: List<VerifiedRoute>, center: LatLon?, loading: Boolean,
                      onSport: (Sport) -> Unit, onCity: () -> Unit, onList: () -> Unit, onOpen: (VerifiedRoute) -> Unit) {
    val local = rememberBackdrop()
    Box(Modifier.fillMaxSize().background(C.Bg)) {
        Box(Modifier.fillMaxSize().backdropSource(local)) {
            RunMap(routes.map { it.track }, Modifier.fillMaxSize(), markers = routes.map { MapMarker(LatLon(it.start.lat, it.start.lon), it.name) },
                showGaps = false, fallbackCenter = center ?: LatLon(40.4168, -3.7038))
        }
        CompositionLocalProvider(LocalBackdrop provides local) {
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val probe = remember { GlassProbe() }
                    val ink = rememberGlassInk(probe, C.Text)
                    Text(title, style = T.Section.copy(color = ink), maxLines = 1, modifier = Modifier.weight(1f, fill = false).heightIn(min = 48.dp)
                        .liquid(androidx.compose.foundation.shape.RoundedCornerShape(26.dp), C.Surface, onClickLabel = "Cambiar de ciudad", probe = probe, tintBias = -0.06f) { onCity() }
                        .padding(horizontal = 16.dp, vertical = 11.dp))
                    Spacer(Modifier.weight(1f, fill = true))
                    RoundIconButton(Icons.Rounded.ViewList, "Ver la lista", bg = C.Surface) { onList() }
                }
                SportSelector(sport, compact = true, onChange = onSport)
                if (loading) Text("Buscando rutas en OpenStreetMap…", style = T.Label.copy(color = C.Text), modifier = Modifier
                    .liquid(androidx.compose.foundation.shape.RoundedCornerShape(20.dp), C.Surface, role = null, onClick = {}).padding(horizontal = 12.dp, vertical = 8.dp))
            }
        }
        if (routes.isNotEmpty()) androidx.compose.foundation.lazy.LazyRow(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = LocalNavPadding.current + 6.dp),
            contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(routes.size) { i ->
                val r = routes[i]
                Row(Modifier.width(260.dp).liquid(androidx.compose.foundation.shape.RoundedCornerShape(22.dp), C.Surface, glassLook = false) { onOpen(r) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    TrackThumb(r.track, Modifier.size(48.dp)); Spacer(Modifier.width(10.dp))
                    Column { Text(r.name, style = T.BodyStrong, maxLines = 1); Text("${Fmt.km(r.distanceM, 1)} km · ${r.surface}", style = T.Label, maxLines = 1) }
                }
            }
        }
    }
}
