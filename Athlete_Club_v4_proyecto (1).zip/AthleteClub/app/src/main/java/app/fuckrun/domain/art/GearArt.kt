package app.fuckrun.domain.art

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dibujo de cada pieza sobre el esqueleto. Las piezas de una familia comparten construcción y se distinguen por los
 * detalles ([D]): corte, cierres, bolsillos, suela, refuerzos… Todo mate: el cristal es de los controles, no del personaje.
 */
object GearArt {
    fun color(o: Outfit, g: Gear, main: Boolean = true): Long {
        val t = o.tintOf(g)
        return GearCatalog.colors[(if (main) t.main else t.accent).coerceIn(0, GearCatalog.colors.lastIndex)].color
    }
    private fun accent(o: Outfit, g: Gear) = color(o, g, false)
    private fun inkOf(c: Long) = Col.ink(c)

    /** Altura (coordenadas de la cabeza) bajo la que el pelo sigue visible. null = la pieza no tapa el pelo. */
    fun brimY(g: Gear?): Float? = when (g?.kind) {
        K.CAP -> if (g.d.contains(D.SHORT_PEAK)) -13f else -12f
        K.HAT -> -13f
        K.BEANIE -> -7f
        K.HELMET -> -11f
        else -> null
    }

    private fun H(sk: Sk, x: Float, y: Float) = Face.at(sk, P(Face.skull(sk, x), y))
    private fun HF(sk: Sk, x: Float, y: Float) = Face.at(sk, P(Face.fx(sk, x), y))

    // ================================================================== capas traseras

    fun back(d: Drawing, sk: Sk, o: Outfit) {
        val u = sk.up; val r = sk.right
        // Capucha caída a la espalda.
        listOfNotNull(o.gear(Slot.OUTER), o.gear(Slot.FULL)).firstOrNull { it.d.contains(D.HOOD) || it.d.contains(D.HOOD_DETACH) }?.let { g ->
            val c = Col.shade(color(o, g), 0.12f)
            val base = sk.neck + u * 4f
            val hood = Path.smooth(listOf(base - r * 20f, base - r * 26f + u * 18f, base + u * 30f - r * 6f, base + u * 30f + r * 10f, base + r * 22f + u * 16f, base + r * 18f), true)
            d.solid(hood, c, line = 1.3f, depth = 4f)
        }
        o.gear(Slot.OUTER)?.takeIf { it.kind == K.CAPE }?.let { g ->
            val c = Col.shade(color(o, g), 0.14f)
            d.solid(capeShape(sk, g, 4f), c, line = 1.3f, depth = 5f)
        }
        o.gear(Slot.WAIST)?.takeIf { it.kind == K.TIED_SWEATER }?.let { g ->
            val c = Col.shade(color(o, g), 0.1f)
            val w = sk.waist - u * 6f
            d.solid(Path.smooth(listOf(w - r * (sk.waistW + 8f), w + r * ((sk.waistW + 8f) * sk.farK), sk.pelvis - u * 34f + r * (sk.hipW + 10f), sk.pelvis - u * 40f, sk.pelvis - u * 34f - r * (sk.hipW + 12f)), true),
                c, line = 1.2f, depth = 4f)
        }
        val back = o.gear(Slot.BACK) ?: return
        val c = color(o, back); val a = accent(o, back)
        val top = sk.neck + u * 2f
        val side = if (sk.q) -1f else 0f  // en tres cuartos la mochila asoma por detrás (izquierda)
        when (back.kind) {
            K.PACK -> {
                val big = back.d.contains(D.TOP_LID)
                val h = if (big) 104f else 80f; val w = if (big) 32f else 27f
                val c0 = top - u * (h / 2 - (if (big) 12f else 2f)) + r * (side * 14f)
                val body = Path.roundRect(-w, -h / 2, w, h / 2, 14f).map { rot(it, P(0f, 0f), sk.up.angle() + PI.toFloat() / 2) + c0 }
                d.solid(body, c, line = 1.5f, depth = 6f)
                if (big) {
                    val lid = Path.smooth(listOf(c0 + u * (h / 2 + 4f) - r * (w + 2f), c0 + u * (h / 2 + 10f), c0 + u * (h / 2 + 4f) + r * (w + 2f), c0 + u * (h / 2 - 16f) + r * w, c0 + u * (h / 2 - 18f) - r * w), true)
                    d.solid(lid, a, line = 1.3f, depth = 3f)
                    for (s in listOf(-1f, 1f)) d.stroke(Path.line(c0 + u * (h / 2 - 14f) + r * (s * 12f), c0 + u * (h / 2 - 34f) + r * (s * 12f)), Col.ink(a), 2.2f)
                } else d.solid(Path.roundRect(-w * 0.7f, 4f, w * 0.7f, h / 2 - 8f, 8f).map { rot(it, P(0f, 0f), sk.up.angle() + PI.toFloat() / 2) + c0 }, Col.shade(c, 0.12f), line = 1f, depth = 2f)
            }
            K.FRAMEPACK -> {
                val c0 = top - u * 38f + r * (side * 14f)
                val body = Path.roundRect(-34f, -66f, 34f, 66f, 16f).map { rot(it, P(0f, 0f), sk.up.angle() + PI.toFloat() / 2) + c0 }
                val frame = Col.rgb(0x8A8F96)
                for (s in listOf(-1f, 1f)) d.solid(Path.limb(c0 + r * (s * 30f) - u * 64f, c0 + r * (s * 30f) + u * 90f, 4f, 4f, 0f), frame, line = 1f, depth = 1f)
                d.solid(Path.limb(c0 + u * 88f - r * 32f, c0 + u * 88f + r * 32f, 4f, 4f, 0f), frame, line = 1f, depth = 1f)
                d.solid(body, c, line = 1.6f, depth = 7f)
                d.solid(Path.roundRect(-30f, -20f, 30f, 6f, 6f).map { rot(it, P(0f, 0f), sk.up.angle() + PI.toFloat() / 2) + c0 + u * 40f }, a, line = 1f, depth = 2f)
                // Saco de dormir atado abajo.
                d.solid(Path.roundRect(-30f, -12f, 30f, 12f, 12f).map { rot(it, P(0f, 0f), sk.up.angle() + PI.toFloat() / 2) + c0 - u * 70f }, Col.rgb(0x6D7B59), line = 1.2f, depth = 3f)
            }
            K.MAT -> {
                val c0 = top - u * 10f
                val mat = Path.roundRect(-sk.shW - 26f, -11f, sk.shW + 26f, 11f, 11f).map { rot(it, P(0f, 0f), sk.up.angle() + PI.toFloat() / 2 + PI.toFloat() / 2) + c0 }
                val m2 = Path.limb(c0 - r * (sk.shW + 24f), c0 + r * (sk.shW + 24f), 22f, 22f, 0f)
                d.solid(m2, c, line = 1.4f, depth = 5f)
                for (k in 0..4) d.stroke(Path.line(c0 - r * (sk.shW + 16f - k * (sk.shW * 0.5f)) + u * 10f, c0 - r * (sk.shW + 16f - k * (sk.shW * 0.5f)) - u * 10f), Col.shade(c, 0.3f), 0.8f)
                d.solid(Path.ellipse(c0 + r * (sk.shW + 25f), 5f, 11f), Col.light(c, 0.2f), line = 1f, depth = 1f)
                if (mat.cmds.isEmpty()) Unit
            }
            K.ROLLTOP -> {
                val c0 = top - u * 38f + r * (side * 14f)
                d.solid(Path.roundRect(-28f, -44f, 28f, 44f, 10f).map { rot(it, P(0f, 0f), sk.up.angle() + PI.toFloat() / 2) + c0 }, c, line = 1.5f, depth = 6f)
                d.solid(Path.limb(c0 + u * 44f - r * 28f, c0 + u * 44f + r * 28f, 13f, 13f, 0f), Col.shade(c, 0.15f), line = 1.2f, depth = 2f)
                d.solid(Path.limb(c0 + u * 50f, c0 + u * 20f, 5f, 5f, 0f), a, line = 1f, depth = 1f)
            }
            else -> Unit
        }
    }

    private fun capeShape(sk: Sk, g: Gear, e: Float): Path {
        val u = sk.up; val r = sk.right
        val w = sk.shW + 16f + g.b + e
        val hemY = sk.pelvis - u * (28f + g.b)
        return Path.smooth(listOf(sk.neck + u * 6f - r * 10f, sk.neck + u * 6f + r * 10f * sk.farK, sk.sh[1] + r * 14f * sk.farK + u * 2f,
            hemY + r * (w * sk.farK) + u * 4f, hemY + r * (w * 0.5f), hemY, hemY - r * (w * 0.5f), hemY - r * w + u * 4f, sk.sh[0] - r * 14f + u * 2f), true)
    }

    // ================================================================== brazos

    fun armLayers(d: Drawing, sk: Sk, o: Outfit, i: Int) {
        val pts = Figure.armPts(sk, i); val ws = Figure.armWs(sk, i)
        val arm = o.gear(Slot.ARM)
        if (arm != null && arm.kind == K.ARMSLEEVE) {
            val full = Figure.cut(pts, 1f)
            val seg = full.let { listOf(it[0].lerp(it[1], 0.62f)) + it.drop(1) }
            val w = Figure.widthsAlong(seg, pts, ws).map { it + 2f }
            val c = color(o, arm)
            val p = Figure.tube(seg, w, capStart = false, capEnd = false)
            d.solid(p, if (i == 1) Col.shade(c, 0.1f) else c, line = 1.2f, depth = 3f)
            if (arm.d.contains(D.RIBBED)) d.group(clip = p) { for (k in 0..10) { val q = seg[0].lerp(seg.last(), k / 10f); val n = (seg.last() - seg[0]).norm().perp()
                stroke(Path.line(q - n * 9f, q + n * 9f + (seg.last() - seg[0]).norm() * 2f), Col.shade(c, 0.25f), 0.8f) } }
            if (arm.d.contains(D.REFLECT)) for (q in listOf(seg[0], seg.last())) { val n = (seg.last() - seg[0]).norm().perp()
                d.stroke(Path.line(q - n * (w[0] / 2), q + n * (w[0] / 2)), Col.rgb(0xDDE3E8), 3f) }
        }
        // Mangas: primero la camiseta, encima la capa exterior.
        for (g in listOfNotNull(o.gear(Slot.FULL) ?: o.gear(Slot.TOP), o.gear(Slot.OUTER))) {
            if (g.kind == K.VEST || g.kind == K.CAPE) continue
            if (g.d.contains(D.SINGLET)) continue
            val len = if (g.kind == K.FULL) 1f else g.a
            if (len <= 0.01f) continue
            val outer = g.slot == Slot.OUTER
            val e = if (g.d.contains(D.TIGHT)) 1.6f else 3.2f + g.b * 0.6f + (if (outer) 2.4f else 0f)
            val seg = Figure.cut(pts, len.coerceAtMost(1f))
            val w = Figure.widthsAlong(seg, pts, ws).map { it + e }
            var c = if (g.d.contains(D.RAGLAN)) accent(o, g) else color(o, g)
            if (i == 1) c = Col.shade(c, 0.1f)
            val sl = Figure.tube(if (len >= 0.99f) seg.dropLast(1) + seg.last().let { it + (seg.last() - seg[seg.size - 2]).norm() * 1f } else seg,
                w, capStart = true, capEnd = false)
            d.solid(sl, c, line = 1.4f, depth = 4f)
            val end = seg.last(); val dir = (seg.last() - seg[seg.size - 2]).norm(); val n = dir.perp()
            val wEnd = w.last()
            when {
                g.d.contains(D.ROLLED) -> d.solid(Path.limb(end - n * (wEnd / 2 + 1f), end + n * (wEnd / 2 + 1f), 6f, 6f, 0f), Col.light(c, 0.08f), line = 1.1f, depth = 2f)
                len >= 0.99f || g.d.contains(D.CREW) -> d.stroke(Path.line(end - dir * 2f - n * (wEnd / 2), end - dir * 2f + n * (wEnd / 2)), Col.shade(c, 0.25f), 1.1f)
            }
            if (g.d.contains(D.RIBBED_SHOULDERS)) d.group(clip = sl) { for (k in 0..4) { val q = seg[0].lerp(seg[1], 0.06f + k * 0.07f)
                stroke(Path.line(q - n * 12f, q + n * 12f), Col.shade(c, 0.25f), 1f) } }
            if (g.d.contains(D.DIAG_BAND) || (g.kind == K.FULL && g.d.contains(D.DIAG_BAND))) {
                val q0 = seg[0].lerp(seg.last(), 0.1f); d.group(clip = sl) { stroke(Path.line(q0, seg.last()), accent(o, g), 3f) }
            }
            if (g.d.contains(D.HERRINGBONE)) d.group(clip = sl) { for (k in 0..6) { val q = seg[0].lerp(seg.last(), k / 6f); stroke(Path.line(q - n * 3f - dir * 3f, q, q + n * 3f - dir * 3f), Col.shade(c, 0.3f), 0.7f) } }
        }
        if (arm != null && arm.kind == K.ARMBAND && i == 0) {
            val q = pts[0].lerp(pts[1], 0.55f); val dir = (pts[1] - pts[0]).norm(); val n = dir.perp()
            d.solid(Path.limb(q - n * (ws[0] / 2 + 3f), q + n * (ws[0] / 2 + 3f), 9f, 9f, 0f), color(o, arm), line = 1.1f, depth = 2f)
            val ph = Path.roundRect(-6f, -10f, 6f, 10f, 2.5f).map { rot(it, P(0f, 0f), dir.angle() - PI.toFloat() / 2) + q - n * 2f }
            d.solid(ph, Col.rgb(0x22262C), line = 1f, depth = 1f)
            d.fill(Path.roundRect(-4.4f, -8f, 4.4f, 7f, 1.6f).map { rot(it, P(0f, 0f), dir.angle() - PI.toFloat() / 2) + q - n * 2f }, Col.rgb(0x3D5A80))
        }
    }

    /** Lo que va sobre la mano: reloj o pulsera en la muñeca y la manga con abertura para el pulgar. */
    fun afterHand(d: Drawing, sk: Sk, o: Outfit, i: Int) {
        val top = o.gear(Slot.FULL) ?: o.gear(Slot.TOP)
        if (top != null && top.d.contains(D.THUMB) && o.gear(Slot.OUTER)?.let { it.a > 0.9f && it.kind == K.OUTER } != true) {
            val dir = sk.handDir[i]; val n = dir.perp(); val w = sk.wr[i]
            val c = Col.shade(color(o, top), if (i == 1) 0.1f else 0f)
            d.solid(Path.smooth(listOf(w - dir * 2f - n * 6.5f, w + dir * 6f - n * 5.5f, w + dir * 8f, w + dir * 6f + n * 5f, w - dir * 2f + n * 6.5f), true), c, line = 1.1f, depth = 1.5f)
            d.fill(Path.ellipse(w + dir * 5f + n * (if (i == 0) -2.5f else 2.5f), 1.6f, 1.1f), Col.shade(c, 0.5f))
        }
        if (i == 0) o.gear(Slot.WRIST)?.let { wristItem(d, sk, o, it) }
    }

    private fun wristItem(d: Drawing, sk: Sk, o: Outfit, g: Gear) {
        val pts = Figure.armPts(sk, 0)
        val dir = (pts[2] - pts[1]).norm(); val n = dir.perp()
        val q = pts[2] - dir * 5f
        val w = sk.armW * 0.62f + 3f
        val c = color(o, g)
        when (g.kind) {
            K.WRISTBAND -> { val p = Path.limb(q - n * w * 0.62f, q + n * w * 0.62f, 11f, 11f, 0f); d.solid(p, c, line = 1.1f, depth = 2f)
                d.group(clip = p) { for (k in -4..4) stroke(Path.line(q - dir * 6f + n * (k * 2.2f), q + dir * 6f + n * (k * 2.2f)), Col.shade(c, 0.18f), 0.7f) } }
            K.WATCH -> { d.solid(Path.limb(q - n * w * 0.6f, q + n * w * 0.6f, 5f, 5f, 0f), Col.rgb(0x2B2E33), line = 0.9f, depth = 1f)
                val face = Path.roundRect(-4.5f, -3.4f, 4.5f, 3.4f, 1.2f).map { rot(it, P(0f, 0f), n.angle()) + q - n * 1f }
                d.solid(face, accent(o, g), line = 1f, depth = 1f); d.fill(Path.roundRect(-3.2f, -2.2f, 3.2f, 2.2f, 0.8f).map { rot(it, P(0f, 0f), n.angle()) + q - n * 1f }, Col.rgb(0x16191D)) }
            K.BRACELET -> { for (k in 0..5) { val a = q - n * (w * 0.6f) + n * (k * w * 0.24f)
                d.solid(Path.ellipse(a, 2.2f, 1.6f), if (k % 2 == 0) c else accent(o, g), line = 0.6f, depth = 0.5f) } }
            else -> Unit
        }
    }

    fun gloveDetail(d: Drawing, sk: Sk, i: Int, g: Gear, palmC: P, dir: P, n: P) {
        val base = sk.wr[i]
        val c = GearCatalog.colors[GearCatalog.defaultTint(g).main].color
        when {
            g.d.contains(D.FINGERLESS) -> {
                val mitt = Path.smooth(listOf(base - n * 6.5f, palmC - n * 7f, palmC + dir * 5f - n * 6f, palmC + dir * 5f + n * 6f, palmC + n * 7f, base + n * 6.5f), true)
                d.solid(mitt, c, line = 1f, depth = 2f)
                d.group(clip = mitt) { for (k in 0..5) for (j in 0..3) fill(Path.circle(base + dir * (3f + j * 3f) - n * (5f - k * 2f), 0.6f), Col.shade(c, 0.4f)) }
            }
            g.d.contains(D.PALM) -> { d.solid(Path.ellipse(palmC + n * 1.5f, 4.6f, 3.8f), Col.rgb(0x8E7B63), line = 0.8f, depth = 1f)
                d.solid(Path.limb(base - dir * 2f - n * 6.5f, base - dir * 2f + n * 6.5f, 5f, 5f, 0f), Col.shade(c, 0.2f), line = 0.9f, depth = 1f) }
            else -> d.solid(Path.limb(base - dir * 3f - n * 6f, base - dir * 3f + n * 6f, 5f, 5f, 0f), Col.shade(c, 0.15f), line = 0.9f, depth = 1f)
        }
    }

    // ================================================================== piernas

    fun legLayers(d: Drawing, sk: Sk, o: Outfit, i: Int) {
        val pts = Figure.legPts(sk, i); val ws = Figure.legWs(sk, i)
        val shade = i == 1
        fun sh(c: Long) = if (shade) Col.shade(c, 0.1f) else c
        val shinDir = (sk.kn[i] - sk.an[i]).norm()
        // Calcetines.
        o.gear(Slot.SOCKS)?.let { g ->
            val h = g.a; val c = sh(color(o, g))
            val top = sk.an[i] + shinDir * h
            val w0 = ws[2] + 2f; val w1 = Figure.widthsAlong(listOf(top), pts, ws)[0] + 2f
            val p = Figure.tube(listOf(sk.an[i] - shinDir * 4f, top), listOf(w0, w1), capStart = true, capEnd = false)
            d.solid(p, c, line = 1.1f, depth = 2f)
            val n = shinDir.perp()
            when {
                g.d.contains(D.FOLD) -> d.solid(Path.limb(top - n * (w1 / 2 + 1.5f), top + n * (w1 / 2 + 1.5f), 7f, 7f, 0f), Col.light(c, 0.06f), line = 1f, depth = 2f)
                g.d.contains(D.WIDE_CUFF) -> d.solid(Path.limb(top - shinDir * 3f - n * (w1 / 2 + 0.5f), top - shinDir * 3f + n * (w1 / 2 + 0.5f), 7f, 7f, 0f), accent(o, g), line = 0.9f, depth = 1f)
                else -> d.stroke(Path.line(top - shinDir * 2f - n * (w1 / 2), top - shinDir * 2f + n * (w1 / 2)), accent(o, g), 1.6f)
            }
            if (g.d.contains(D.WOOL)) d.group(clip = p) { for (k in 0..5) stroke(Path.line(sk.an[i] + shinDir * (k * 3.5f) - n * 6f, sk.an[i] + shinDir * (k * 3.5f + 1.5f) + n * 6f), Col.shade(c, 0.2f), 0.7f) }
            if (g.d.contains(D.TAB) && sk.q) d.solid(Path.smooth(listOf(sk.an[i] - (sk.toe[i] - sk.an[i]).norm() * 6f + shinDir * 2f, sk.an[i] - (sk.toe[i] - sk.an[i]).norm() * 9f + shinDir * 7f,
                sk.an[i] - (sk.toe[i] - sk.an[i]).norm() * 5f + shinDir * 9f), true), accent(o, g), line = 0.8f, depth = 1f)
        }
        // Parte de abajo (o conjunto).
        val bottom = o.gear(Slot.FULL) ?: o.gear(Slot.BOTTOM)
        if (bottom != null) {
            val len = if (bottom.kind == K.FULL) 1f else bottom.a
            val tight = bottom.d.contains(D.TIGHT)
            val e = if (tight) 1.2f else 3f + bottom.b
            val seg = Figure.cut(pts, len)
            val w = Figure.widthsAlong(seg, pts, ws).map { it + e }.toMutableList()
            if (!tight && len < 0.6f) w[w.size - 1] = w.last() + 3f
            if (len > 0.9f) w[w.size - 1] = w.last() + 2f
            val c = sh(color(o, bottom)); val a = accent(o, bottom)
            val p = Figure.tube(seg, w, capStart = true, capEnd = false)
            d.solid(p, c, line = 1.4f, depth = 4f)
            val end = seg.last(); val dir = (seg.last() - seg[seg.size - 2]).norm(); val n = dir.perp()
            val outer = if (i == 0) 1f else -1f
            val edge = { t: Float -> val q = Figure.cut(seg, t).last(); q + n * (outer * Figure.widthsAlong(listOf(q), seg, w)[0] / 2 * 0.86f) }
            if (bottom.d.contains(D.STRIPE) || bottom.kind == K.FULL && bottom.d.contains(D.DIAG_BAND))
                d.group(clip = p) { stroke(Path.smooth((0..6).map { edge(0.02f + it * 0.163f) }, false), a, 3.2f) }
            if (bottom.d.contains(D.SIDE_PANEL)) d.group(clip = p) { stroke(Path.smooth((0..6).map { edge(0.02f + it * 0.163f) }, false), a, 6.5f) }
            if (bottom.d.contains(D.SPLIT)) { val q = end + n * (outer * w.last() / 2 * 0.8f)
                d.fill(Path.poly(q - dir * 1f, q - dir * 7f - n * (outer * 2f), q - dir * 1f - n * (outer * 4f)), Col.shade(c, 0.45f)) }
            if (bottom.d.contains(D.SIDE_POCKET)) { val q = Figure.cut(seg, if (len > 0.9f) 0.42f else 0.55f).last() + n * (outer * w[0] * 0.25f)
                d.solid(Path.roundRect(-4.5f, -6f, 4.5f, 6f, 1.5f).map { rot(it, P(0f, 0f), dir.angle() - PI.toFloat() / 2) + q }, Col.shade(c, 0.06f), line = 1f, depth = 1f) }
            if (bottom.d.contains(D.ZIP_OFF)) { val q = sk.kn[i] + dir * 4f
                d.group(clip = p) { stroke(Path.line(q - n * 14f, q + n * 14f), Col.shade(c, 0.45f), 1.2f)
                    for (k in -6..6) stroke(Path.line(q + n * (k * 2f) - dir * 1f, q + n * (k * 2f) + dir * 1f), Col.rgb(0x9AA0A6), 0.7f) } }
            if (bottom.d.contains(D.PLEATS)) d.group(clip = p) { stroke(Path.line(seg[0] + n * 2f, seg[0].lerp(seg.last(), 0.45f) + n * 1f), Col.shade(c, 0.3f), 0.9f) }
            if (bottom.kind == K.FULL && bottom.d.contains(D.HERRINGBONE)) d.group(clip = p) { for (k in 0..8) { val q = edge(k / 8f); stroke(Path.line(q - dir * 3f - n * 3f, q, q - dir * 3f + n * 3f), Col.shade(c, 0.3f), 0.7f) } }
            if (len > 0.9f) d.stroke(Path.line(end - dir * 3f - n * (w.last() / 2), end - dir * 3f + n * (w.last() / 2)), Col.shade(c, 0.3f), 0.9f)
        }
        // Polainas y perneras.
        o.gear(Slot.LEGWEAR)?.let { g ->
            val c = sh(color(o, g)); val a = accent(o, g)
            if (g.kind == K.GAITER) {
                val top = sk.an[i] + shinDir * 30f
                val p = Figure.tube(listOf(sk.an[i] - shinDir * 6f, top), listOf(ws[2] + 9f, Figure.widthsAlong(listOf(top), pts, ws)[0] + 6f), capStart = true, capEnd = false)
                d.solid(p, c, line = 1.2f, depth = 3f)
                d.stroke(Path.line(sk.an[i] + shinDir * 2f, top - shinDir * 2f), a, 1.8f)
                d.stroke(Path.line(top - shinDir * 3f - shinDir.perp() * 7f, top - shinDir * 3f + shinDir.perp() * 7f), Col.shade(c, 0.3f), 1.2f)
            } else {
                val from = sk.hip[i].lerp(sk.kn[i], 0.74f)
                val seg = listOf(from, sk.kn[i], sk.an[i] + shinDir * 3f)
                val w = Figure.widthsAlong(seg, pts, ws).map { it + 1.6f }
                val p = Figure.tube(seg, w, capStart = false, capEnd = false)
                d.solid(p, c, line = 1.1f, depth = 3f)
                val band = sk.kn[i].lerp(sk.an[i], 0.36f); val n = (sk.an[i] - sk.kn[i]).norm().perp()
                d.group(clip = p) { stroke(Path.line(band - n * 14f, band + n * 14f), a, 4f) }
            }
        }
        shoe(d, sk, o, i)
    }

    private fun shoe(d: Drawing, sk: Sk, o: Outfit, i: Int) {
        if (o.items[Slot.SHOES.name] == "__none") return
        val g = o.gear(Slot.SHOES) ?: GearCatalog.byId("shoe_flat")!!
        val c0 = color(o, g); val a0 = accent(o, g)
        val c = if (i == 1) Col.shade(c0, 0.1f) else c0
        val soleC = if (g.d.contains(D.WAVY_SOLE) || g.d.contains(D.ROCKER)) a0 else Col.mix(Col.rgb(0xF2EFEA), a0, 0.15f)
        val an = sk.an[i]; val toe = sk.toe[i]
        val soleH = g.a; val collar = g.b
        val front = !sk.q
        if (front) {
            val sd = if (i == 0) -1f else 1f
            val g0 = P(0f, 1f)
            val bottom = an.y + 10f
            val upper = Path.smooth(listOf(an + P(-7f, -collar * 0.4f), an + P(7f, -collar * 0.4f), P(toe.x + sd * 2f + 7f, bottom - soleH - 2f), P(toe.x + sd * 2f, bottom - soleH + 1f),
                P(toe.x + sd * 2f - 8f, bottom - soleH - 2f)), true)
            if (collar > 15f) d.solid(Path.roundRect(an.x - 7.5f, an.y - collar * 0.7f, an.x + 7.5f, an.y + 4f, 3f), c, line = 1.2f, depth = 2f)
            d.solid(upper, c, line = 1.3f, depth = 3f)
            val sole = Path.roundRect(toe.x + sd * 2f - 9.5f, bottom - soleH, toe.x + sd * 2f + 9.5f, bottom, minOf(3f, soleH / 2))
            d.solid(sole, soleC, line = 1.2f, depth = 1.5f)
            if (g.d.contains(D.LUGS)) for (k in 0..4) d.fill(Path.rect(toe.x + sd * 2f - 8f + k * 3.6f, bottom - 1.4f, toe.x + sd * 2f - 6.4f + k * 3.6f, bottom), Col.shade(soleC, 0.5f))
            if (g.d.contains(D.STRAPS_TWO)) for (k in 0..1) d.stroke(Path.line(an + P(-6f, 3f + k * 4f), an + P(6f, 3f + k * 4f)), a0, 2.4f)
            else if (!g.d.contains(D.HOOKS)) for (k in 0..2) d.stroke(Path.line(an + P(-3f, 2f + k * 2.6f), an + P(3f, 2f + k * 2.6f)), Col.mix(c, 0xFFFFFFFF, 0.6f), 0.9f)
            if (g.d.contains(D.HOOKS)) for (k in 0..2) { d.fill(Path.circle(an + P(-4f, -collar * 0.3f + k * 5f), 1f), Col.rgb(0xB8BCC2)); d.fill(Path.circle(an + P(4f, -collar * 0.3f + k * 5f), 1f), Col.rgb(0xB8BCC2)) }
            if (g.d.contains(D.TOE_CAP)) d.fill(Path.ellipse(P(toe.x + sd * 2f, bottom - soleH - 2f), 7f, 3f), Col.shade(c, 0.2f))
            if (g.d.contains(D.SPIKES)) for (k in 0..2) d.fill(Path.poly(P(toe.x + sd * 2f - 6f + k * 6f, bottom), P(toe.x + sd * 2f - 4.5f + k * 6f, bottom + 3f), P(toe.x + sd * 2f - 3f + k * 6f, bottom)), Col.rgb(0x9AA0A6))
            laces(d, sk, o, i, an + P(0f, 4f), P(1f, 0f), g0)
            return
        }
        val f = (toe - an).norm(); var gd = f.perp(); if (gd.y < 0) gd = gd * -1f
        val heelB = an - f * 9f + gd * 10f; val toeB = toe + f * 5f + gd * 4f
        val rocker = if (g.d.contains(D.ROCKER)) 3f else 0f
        val upper = Path.smooth(listOf(an - f * 7f - gd * (collar * 0.55f), an - f * 10f + gd * 2f, heelB - gd * soleH + f * 1f, toeB - gd * soleH - f * 4f,
            toe + f * 6f + gd * (-soleH + 1f), toe + f * 1f - gd * 5f, an.lerp(toe, 0.4f) - gd * 6f, an + f * 5f - gd * (collar * 0.4f + 1f)), true)
        d.solid(upper, c, line = 1.4f, depth = 4f)
        val soleTop = listOf(heelB - gd * soleH, heelB.lerp(toeB, 0.5f) - gd * soleH, toeB - gd * soleH + f * 2f)
        val soleBot = listOf(toeB + f * 1f - gd * rocker, heelB.lerp(toeB, 0.55f), heelB - gd * rocker)
        val sole = Path.smooth(soleTop + soleBot, true)
        d.solid(sole, soleC, line = 1.3f, depth = 2f)
        if (g.d.contains(D.WAVY_SOLE)) d.stroke(Path.smooth((0..8).map { heelB.lerp(toeB, it / 8f) - gd * (soleH * 0.5f + (if (it % 2 == 0) 1.6f else -1.6f)) }, false), Col.light(soleC, 0.4f), 1f)
        if (g.d.contains(D.LUGS)) for (k in 0..6) { val q = heelB.lerp(toeB, k / 6f); d.fill(Path.poly(q - f * 1.5f, q + f * 1.5f, q + gd * 2f), Col.shade(soleC, 0.5f)) }
        if (g.d.contains(D.SPIKES)) {
            for (k in 0..2) { val q = heelB.lerp(toeB, 0.6f + k * 0.15f); d.fill(Path.poly(q - f * 1.6f, q + f * 1.6f, q + gd * 4f), Col.rgb(0x9AA0A6)) }
            d.solid(Path.limb(heelB - gd * 1f, heelB.lerp(toeB, 0.22f) - gd * 1f, 3.2f, 3.2f, 0f), a0, line = 0.8f, depth = 0.5f)
        }
        if (g.d.contains(D.TOE_CAP)) d.solid(Path.smooth(listOf(toe - gd * 4f, toe + f * 6f - gd * (soleH - 1f), toeB - gd * soleH - f * 3f, toe - f * 3f - gd * 2f), true), Col.shade(c, 0.18f), line = 0.9f, depth = 1f)
        if (g.d.contains(D.STRAPS_TWO)) for (k in 0..1) { val q = an.lerp(toe, 0.25f + k * 0.28f); d.stroke(Path.line(q - gd * 6f, q + gd * 3f), a0, 3.2f)
            d.fill(Path.roundRect(q.x - 1.8f, q.y - 1.8f, q.x + 1.8f, q.y + 1.8f, 0.6f), Col.rgb(0xC7CBD0)) }
        if (g.d.contains(D.HOOKS)) for (k in 0..3) d.fill(Path.circle(an + f * 4f - gd * (collar * 0.4f - k * 5f), 1.1f), Col.rgb(0xB8BCC2))
        // Contrafuerte del talón con el color de acento.
        if (!g.d.contains(D.HOOKS)) d.stroke(Path.smooth(listOf(an - f * 8f - gd * (collar * 0.3f), an - f * 10f + gd * 3f, heelB - gd * soleH + f * 4f), false), a0, 2f)
        if (!g.d.contains(D.STRAPS_TWO)) laces(d, sk, o, i, an + f * 4f - gd * 5f, f, gd)
    }

    private fun laces(d: Drawing, sk: Sk, o: Outfit, i: Int, start: P, f: P, gd: P) {
        val lace = o.gear(Slot.LACES)
        val shoe = o.gear(Slot.SHOES)
        val hooks = shoe?.d?.contains(D.HOOKS) == true
        val n = if (hooks) 5 else 3
        val c1 = if (lace != null && lace.d.contains(D.BICOLOR)) color(o, lace) else Col.rgb(0xF4F2EE)
        val c2 = if (lace != null && lace.d.contains(D.BICOLOR)) accent(o, lace) else c1
        if (sk.q) for (k in 0 until n) {
            val q = start + f * (k * 3.6f) - gd * (if (hooks) k * -3f else 0f) + (if (hooks) gd * -(k * 4.5f) - f * (k * 3.6f) else P(0f, 0f))
            d.stroke(Path.line(q - gd * 2.6f, q + gd * 2.6f + f * 2f), if (k % 2 == 0) c1 else c2, 1.4f)
        }
        if (lace != null && lace.d.contains(D.LEAF)) {
            val c = start - gd * 3f
            d.solid(Path.smooth(listOf(c + P(-4f, 1f), c + P(0f, -3.5f), c + P(4.5f, -1f), c + P(0f, 2.5f)), true), color(o, lace), line = 0.8f, depth = 1f)
            d.stroke(Path.line(c + P(-3f, 0.5f), c + P(3.5f, -0.8f)), Col.shade(color(o, lace), 0.4f), 0.6f)
        }
    }

    // ================================================================== pelvis y torso

    fun pelvis(d: Drawing, sk: Sk, o: Outfit) {
        val g = o.gear(Slot.FULL) ?: o.gear(Slot.BOTTOM) ?: return
        val u = sk.up; val r = sk.right
        val tight = g.d.contains(D.TIGHT)
        val e = if (tight) 1.2f else 3f + g.b
        val wb = sk.pelvis + u * 12f
        val c = color(o, g)
        val p = Path.smooth(listOf(wb - r * (sk.hipW + 5f + e), wb + r * ((sk.hipW + 5f + e) * sk.farK), sk.hip[1] + r * ((sk.legW * 0.62f + e) * sk.farK) - u * 6f,
            sk.hip[1].lerp(sk.kn[1], 0.22f) + r * ((sk.legW * 0.4f + e) * sk.farK), sk.pelvis - u * 18f, sk.hip[0].lerp(sk.kn[0], 0.22f) - r * (sk.legW * 0.4f + e),
            sk.hip[0] - r * (sk.legW * 0.62f + e) - u * 6f), true)
        d.solid(p, c, line = 1.4f, depth = 4f)
        d.solid(Path.limb(wb - r * (sk.hipW + 5f + e), wb + r * ((sk.hipW + 5f + e) * sk.farK), 6f, 6f, 0f), if (g.d.contains(D.TIGHT)) c else accent(o, g), line = 1f, depth = 1.5f)
        if (g.d.contains(D.PLEATS)) for (s in listOf(-1f, 1f)) d.stroke(Path.line(wb + r * (s * 8f) - u * 3f, wb + r * (s * 9f) - u * 22f), Col.shade(c, 0.3f), 1f)
        if (g.d.contains(D.BIB_STRAPS) && (o.gear(Slot.TOP)?.d?.contains(D.SINGLET) == true)) Unit
    }

    fun torso(d: Drawing, sk: Sk, o: Outfit) {
        val top = o.gear(Slot.FULL) ?: o.gear(Slot.TOP)
        if (top != null) garment(d, sk, o, top, false)
        o.gear(Slot.WAIST)?.let { waistItem(d, sk, o, it, front = false) }
        o.gear(Slot.OUTER)?.let { g -> if (g.kind == K.CAPE) cape(d, sk, o, g) else garment(d, sk, o, g, true) }
        o.gear(Slot.WAIST)?.let { if (it.kind == K.TIED_SWEATER) waistItem(d, sk, o, it, front = true) }
        backStraps(d, sk, o)
        o.gear(Slot.NECK)?.let { neckItem(d, sk, o, it) }
        o.gear(Slot.CHEST)?.let { chestItem(d, sk, o, it) }
    }

    private fun garment(d: Drawing, sk: Sk, o: Outfit, g: Gear, outer: Boolean) {
        val u = sk.up; val r = sk.right
        val tight = g.d.contains(D.TIGHT)
        val vest = g.kind == K.VEST
        val e = (if (tight) 1f else 2.6f) + g.b + (if (outer) 2.2f else 0f)
        val hem = when {
            g.d.contains(D.BACK_VENT) -> 34f; g.d.contains(D.HOOD_DETACH) -> 28f; outer && g.d.contains(D.SHIRT_COLLAR) -> 14f
            g.d.contains(D.REAR_TAIL) -> 8f; outer -> 10f; tight -> 3f; g.kind == K.FULL -> 5f; else -> 7f
        }
        val neckUp = when { g.d.contains(D.HIGH_NECK) -> 9f; g.d.contains(D.HALF_ZIP) -> 5f; else -> 0f }
        val neckDrop = when { g.d.contains(D.SINGLET) -> 13f; g.d.contains(D.SHIRT_COLLAR) || g.d.contains(D.CORD_COLLAR) -> 12f; vest -> 14f; else -> 7f }
        val body = Figure.torso(sk, e, hem, neckDrop, neckUp, if (g.d.contains(D.SINGLET)) 0.9f else 1f, sleeveless = vest || g.d.contains(D.SINGLET))
        val c = color(o, g); val a = accent(o, g)
        d.solid(body, c, line = 1.5f, depth = 6f)
        val chest = sk.chest; val belly = sk.waist
        d.group(clip = body) {
            if (g.d.contains(D.RAGLAN)) for (s in listOf(0, 1)) {
                val sideR = if (s == 0) r * -1f else r * sk.farK
                fill(Path.poly(sk.neck + sideR * (sk.neckW + 1f) + u * 3f, sk.sh[s] + sideR * 14f + u * 10f, sk.sh[s] - u * 26f + sideR * 4f), a)
            }
            if (g.d.contains(D.CURVED_PANELS)) for (s in listOf(0, 1)) { val sideR = if (s == 0) r * -1f else r * sk.farK
                fill(Path.smooth(listOf(sk.sh[s] + sideR * 8f, sk.sh[s] - u * 30f - sideR * 6f, sk.waist + sideR * (sk.waistW - 4f) - u * 10f, sk.waist + sideR * (sk.waistW + 6f)), true), a) }
            if (g.d.contains(D.DIAG_BAND)) stroke(Path.line(sk.sh[0] + u * 4f, sk.waist + r * (sk.waistW * sk.farK + 8f) - u * 6f), a, 7f)
            if (g.d.contains(D.QUILTED)) for (k in -6..6) { stroke(Path.line(chest + r * (k * 9f) + u * 40f, chest + r * (k * 9f + 60f) - u * 70f), Col.shade(c, 0.22f), 0.9f)
                stroke(Path.line(chest + r * (k * 9f) + u * 40f, chest + r * (k * 9f - 60f) - u * 70f), Col.shade(c, 0.22f), 0.9f) }
            if (g.d.contains(D.PLAID)) for (k in -6..6) { stroke(Path.line(chest + r * (k * 10f) + u * 60f, chest + r * (k * 10f) - u * 90f), Col.of(Col.r(a), Col.g(a), Col.b(a), 140), 2.2f)
                stroke(Path.line(chest - r * 60f - u * (k * 10f), chest + r * 60f - u * (k * 10f)), Col.of(Col.r(a), Col.g(a), Col.b(a), 110), 1.4f) }
            if (g.d.contains(D.FLEECE)) for (k in 0..60) { val x = ((k * 37) % 70) - 35f; val y = ((k * 53) % 110) - 50f
                fill(Path.circle(chest + r * x - u * y, 0.9f), Col.light(c, 0.12f)) }
            if (g.d.contains(D.FLAT_SEAMS)) for (s in listOf(-1f, 1f)) for (k in 0..10) { val q0 = sk.sh[if (s < 0) 0 else 1].lerp(sk.waist + r * (s * sk.waistW * 0.5f), k / 10f) + r * (s * -6f)
                stroke(Path.line(q0, q0 - u * 3f), Col.light(c, 0.35f), 1f) }
            if (g.d.contains(D.HERRINGBONE)) for (k in 0..9) { val q = sk.neck - u * (10f + k * 10f); stroke(Path.line(q - r * 6f + u * 3f, q, q + r * 6f + u * 3f), Col.shade(c, 0.25f), 0.8f) }
            if (g.d.contains(D.OPEN_BACK) && sk.q) for (k in 0..20) fill(Path.circle(sk.sh[0] - u * (12f + (k / 4) * 9f) + r * (4f + (k % 4) * 4f), 0.9f), Col.shade(c, 0.4f))
            if (g.d.contains(D.MESH) && !g.d.contains(D.OPEN_BACK)) Unit
        }
        // Escote o cuello.
        val nk = sk.neck - u * (neckDrop - neckUp)
        when {
            g.d.contains(D.CREW) && !outer -> d.stroke(Path.smooth(listOf(sk.neck - r * (sk.neckW + 1f) + u * 2f, nk + r * (if (sk.q) 3f else 0f), sk.neck + r * ((sk.neckW + 1f) * sk.farK) + u * 2f), false),
                if (g.d.contains(D.RAGLAN)) a else Col.shade(c, 0.2f), 2.8f)
            g.d.contains(D.SINGLET) -> d.stroke(Path.smooth(listOf(sk.neck - r * (sk.neckW + 2f) + u * 2f, nk + r * 2f, sk.neck + r * ((sk.neckW + 2f) * sk.farK) + u * 2f), false), a, 2.4f)
            g.d.contains(D.HIGH_NECK) || g.d.contains(D.HALF_ZIP) -> d.solid(Path.smooth(listOf(sk.neck - r * (sk.neckW + 3f) + u * (neckUp + 3f), sk.neck + r * ((sk.neckW + 3f) * sk.farK) + u * (neckUp + 3f),
                sk.neck + r * ((sk.neckW + 4f) * sk.farK) - u * 3f, sk.neck - u * 5f, sk.neck - r * (sk.neckW + 4f) - u * 3f), true), Col.light(c, 0.04f), line = 1.2f, depth = 2f)
            g.d.contains(D.SHIRT_COLLAR) || g.d.contains(D.CORD_COLLAR) -> {
                val cc = if (g.d.contains(D.CORD_COLLAR)) a else Col.light(c, 0.05f)
                for (s in listOf(0, 1)) { val sideR = if (s == 0) r * -1f else r * sk.farK
                    val col = Path.poly(sk.neck + sideR * (sk.neckW + 2f) + u * 4f, sk.neck + sideR * (sk.neckW + 10f) - u * 6f, nk + sideR * 3f)
                    d.solid(col, cc, line = 1.1f, depth = 2f)
                    if (g.d.contains(D.CORD_COLLAR)) d.group(clip = col) { for (k in 0..6) stroke(Path.line(sk.neck + sideR * (k * 2.4f) + u * 6f, nk + sideR * (k * 2.4f) - u * 2f), Col.shade(cc, 0.3f), 0.7f) }
                }
            }
            vest -> d.stroke(Path.smooth(listOf(sk.neck - r * (sk.neckW + 4f) + u * 2f, nk, sk.neck + r * ((sk.neckW + 4f) * sk.farK) + u * 2f), false), Col.shade(c, 0.3f), 1.6f)
        }
        // Cierres.
        val zipTop = sk.neck + u * (neckUp + 2f) + r * (if (sk.q) 3f else 0f)
        val hemPt = sk.pelvis - u * hem + r * (if (sk.q) 3f else 0f)
        if (g.d.contains(D.FULL_ZIP)) {
            if (g.d.contains(D.SHIRT_COLLAR)) { d.stroke(Path.line(nk, hemPt), Col.shade(c, 0.3f), 1f); for (k in 0..4) d.fill(Path.circle(nk.lerp(hemPt, 0.08f + k * 0.2f) + r * 2f, 1.4f), Col.light(c, 0.4f)) }
            else { d.stroke(Path.line(zipTop, hemPt), Col.shade(c, 0.45f), 1.6f); d.fill(Path.roundRect(zipTop.x - 1.6f, zipTop.y + 1f, zipTop.x + 1.6f, zipTop.y + 6f, 0.8f), Col.rgb(0xB9BEC4)) }
        } else if (g.d.contains(D.HALF_ZIP)) {
            val zEnd = zipTop.lerp(hemPt, 0.38f)
            d.stroke(Path.line(zipTop, zEnd), Col.shade(c, 0.45f), 1.6f); d.fill(Path.roundRect(zipTop.x - 1.6f, zipTop.y + 2f, zipTop.x + 1.6f, zipTop.y + 7f, 0.8f), Col.rgb(0xB9BEC4))
        }
        // Bolsillos y piezas del frente.
        val pk = Col.shade(c, 0.08f)
        if (g.d.contains(D.PATCH_POCKET)) d.solid(Path.roundRect(-6.5f, -7f, 6.5f, 7f, 1.5f).map { it + chest - r * 12f - u * 6f }, pk, line = 1f, depth = 1.5f)
        if (g.d.contains(D.TWO_POCKETS) || g.d.contains(D.MULTI_POCKETS)) for (s in listOf(-1f, 1f)) {
            val q = chest + r * (s * 13f * (if (s > 0) sk.farK else 1f)) - u * 6f
            d.solid(Path.roundRect(-6f, -6f, 6f, 7f, 1.5f).map { it + q }, pk, line = 1f, depth = 1.5f)
            d.solid(Path.roundRect(-6.5f, -7.5f, 6.5f, -3f, 1.2f).map { it + q }, Col.shade(c, 0.15f), line = 0.9f, depth = 1f)
            if (g.d.contains(D.MULTI_POCKETS)) d.solid(Path.roundRect(-7f, -7f, 7f, 8f, 1.5f).map { it + q - u * 30f }, pk, line = 1f, depth = 1.5f)
        }
        if (g.d.contains(D.KANGAROO)) d.solid(Path.smooth(listOf(belly - r * 20f + u * 4f, belly + r * (20f * sk.farK) + u * 4f, belly + r * (24f * sk.farK) - u * 18f, belly - r * 24f - u * 18f), true), Col.shade(c, 0.07f), line = 1.1f, depth = 2f)
        if (g.d.contains(D.BIB_SEWN) || g.d.contains(D.BIB_POCKET)) {
            val q = sk.waist + u * 14f + r * (if (sk.q) 4f else 0f)
            val bib = Path.roundRect(-12f, -9f, 12f, 9f, 1.5f).map { it + q }
            d.solid(bib, if (g.d.contains(D.BIB_POCKET)) Col.of(230, 238, 245, 170) else Col.rgb(0xF5F3EE), line = 1f, depth = 1f, accent = false)
            d.stroke(Path.smooth(listOf(q + P(-6f, -4f), q + P(-3f, -6f), q + P(-1f, -3f), q + P(-6f, 5f), q + P(-1f, 5f)), false), Col.rgb(0x2A2E34), 1.4f)
            d.stroke(Path.smooth(listOf(q + P(3f, -6f), q + P(7f, -6f), q + P(4f, 5f)), false), Col.rgb(0x2A2E34), 1.4f)
        }
        if (g.d.contains(D.BACK_POCKETS) && sk.q) for (k in 0..2) d.solid(Path.roundRect(-5f, -5f, 5f, 5f, 1.2f).map { it + sk.pelvis + u * 8f - r * (sk.hipW + 6f - k * 2f) + u * (k * 0.5f) }, Col.shade(c, 0.12f), line = 0.9f, depth = 1f)
        if (g.d.contains(D.REAR_TAIL) && sk.q) d.solid(Path.smooth(listOf(sk.pelvis - r * (sk.hipW + 6f) - u * 6f, sk.pelvis - r * (sk.hipW + 10f) - u * 22f, sk.pelvis - r * (sk.hipW - 4f) - u * 18f), true), c, line = 1.2f, depth = 2f)
        if (g.d.contains(D.BACK_VENT)) { val w = sk.waist - u * 2f
            d.solid(Path.limb(w - r * (sk.waistW + e + 1f), w + r * ((sk.waistW + e + 1f) * sk.farK), 5f, 5f, 0f), Col.shade(c, 0.12f), line = 1f, depth = 1f)
            d.solid(Path.roundRect(-3.5f, -3.5f, 3.5f, 3.5f, 0.8f).map { it + w + r * 2f }, Col.rgb(0x8C7B60), line = 0.8f, depth = 0.5f)
            if (sk.q) d.stroke(Path.line(sk.pelvis - r * (sk.hipW + 2f), sk.pelvis - r * (sk.hipW + 4f) - u * 32f), Col.shade(c, 0.35f), 1f) }
        if (g.d.contains(D.HOOD_DETACH)) for (k in 0..4) d.fill(Path.circle(sk.neck - r * (8f - k * 4f) + u * 1f, 1f), Col.rgb(0xB9BEC4))
        if (g.d.contains(D.HOOD)) for (s in listOf(-1f, 1f)) d.stroke(Path.line(sk.neck + r * (s * 4f) - u * 2f, sk.neck + r * (s * 5f) - u * 22f), Col.light(a, 0.1f), 1.3f)
        if (vest && g.d.contains(D.MESH)) Unit
    }

    private fun cape(d: Drawing, sk: Sk, o: Outfit, g: Gear) {
        val c = color(o, g); val a = accent(o, g)
        val p = capeShape(sk, g, 0f)
        d.solid(p, c, line = 1.5f, depth = 6f)
        val u = sk.up; val r = sk.right
        if (g.d.contains(D.MAP_YOKE)) {
            val yoke = Path.smooth(listOf(sk.sh[0] - r * 14f + u * 2f, sk.neck + u * 6f, sk.sh[1] + r * 14f * sk.farK + u * 2f, sk.sh[1] + r * 12f * sk.farK - u * 22f, sk.neck - u * 26f, sk.sh[0] - r * 12f - u * 22f), true)
            d.group(clip = p) { solid(yoke, a, line = 1f, depth = 2f)
                group(clip = yoke) { for (k in 0..5) stroke(Path.ellipse(sk.neck - u * 12f + r * (k * 3f - 6f), 10f + k * 6f, 6f + k * 4f), Col.shade(a, 0.35f), 0.8f) } }
        } else d.stroke(Path.smooth(listOf(sk.sh[0] - r * 10f - u * 30f, sk.neck - u * 40f, sk.sh[1] + r * 10f * sk.farK - u * 30f), false), Col.shade(c, 0.25f), 1f)
        // Abertura del poncho por la que asoma el brazo.
        d.stroke(Path.line(sk.neck - u * 6f, sk.neck - u * 24f), Col.shade(c, 0.35f), 1.2f)
        for (s in listOf(-1f, 1f)) d.stroke(Path.line(sk.neck + r * (s * 4f) - u * 2f, sk.neck + r * (s * 5f) - u * 18f), Col.light(a, 0.1f), 1.3f)
    }

    private fun waistItem(d: Drawing, sk: Sk, o: Outfit, g: Gear, front: Boolean) {
        val u = sk.up; val r = sk.right
        val c = color(o, g); val a = accent(o, g)
        val w = sk.waist - u * 8f
        val half = sk.waistW + 6f
        when (g.kind) {
            K.BELT_GELS -> { d.solid(Path.limb(w - r * half, w + r * (half * sk.farK), 7f, 7f, 0f), c, line = 1.1f, depth = 1.5f)
                for (k in 0..2) { val q = w + r * (-14f + k * 12f) + u * 3f
                    d.solid(Path.roundRect(-3.2f, -7f, 3.2f, 5f, 1f).map { it + q }, Col.rgb(0xE8E4DA), line = 0.8f, depth = 0.5f)
                    d.fill(Path.rect(q.x - 3.2f, q.y - 7f, q.x + 3.2f, q.y - 4.5f), a)
                    d.stroke(Path.line(q - r * 4f + u * 0.5f, q + r * 4f + u * 0.5f), Col.shade(c, 0.35f), 1.6f) } }
            K.LUMBAR -> { d.solid(Path.limb(w - r * half, w + r * (half * sk.farK), 5f, 5f, 0f), Col.shade(c, 0.2f), line = 1f, depth = 1f)
                val q = w - r * (half + (if (sk.q) 4f else -2f)) - u * 2f
                d.solid(Path.roundRect(-9f, -9f, 9f, 9f, 4f).map { it + q }, c, line = 1.2f, depth = 2f)
                d.solid(Path.roundRect(-7f, -3f, 7f, 7f, 2.5f).map { it + q }, a, line = 0.9f, depth = 1f)
                d.solid(Path.roundRect(-3f, -2.5f, 3f, 2.5f, 0.8f).map { it + w + r * 4f }, Col.rgb(0x2A2E33), line = 0.6f, depth = 0.4f) }
            K.WAISTBAG -> { d.solid(Path.limb(w - r * half, w + r * (half * sk.farK), 4.5f, 4.5f, 0f), Col.shade(c, 0.25f), line = 0.9f, depth = 1f)
                val q = w + r * (if (sk.q) 6f else 0f) - u * 3f
                d.solid(Path.smooth(listOf(q + P(-15f, -5f), q + P(15f, -5f), q + P(17f, 5f), q + P(0f, 9f), q + P(-17f, 5f)), true), c, line = 1.3f, depth = 2.5f)
                d.solid(Path.roundRect(-9f, 0f, 9f, 6f, 2f).map { it + q }, a, line = 0.9f, depth = 1f)
                d.stroke(Path.line(q + P(-12f, -2f), q + P(12f, -2f)), Col.rgb(0xB9BEC4), 0.9f) }
            K.TIED_SWEATER -> if (front) {
                for (s in listOf(-1f, 1f)) d.solid(Path.limb(w + r * (s * (half + 2f)), w + r * (s * 3f) - u * 6f, 10f, 8f, 0.1f), c, line = 1.2f, depth = 2f)
                val k0 = w - u * 7f + r * 2f
                d.solid(Path.circle(k0, 6f), Col.shade(c, 0.06f), line = 1.1f, depth = 1.5f)
                for (s in listOf(-1f, 1f)) d.solid(Path.limb(k0, k0 - u * 26f + r * (s * 5f), 8f, 7f, 0f), c, line = 1.1f, depth = 2f)
                for (s in listOf(-1f, 1f)) d.stroke(Path.line(k0 - u * 24f + r * (s * 5f - 3.5f), k0 - u * 24f + r * (s * 5f + 3.5f)), a, 2f)
            }
            else -> Unit
        }
        if (g.kind != K.TIED_SWEATER && front) Unit
    }

    private fun backStraps(d: Drawing, sk: Sk, o: Outfit) {
        val g = o.gear(Slot.BACK) ?: return
        val u = sk.up; val r = sk.right
        val c = if (g.kind == K.MAT) color(o, g, false) else Col.shade(color(o, g), 0.25f)
        val k = if (g.kind == K.MAT) 0.6f else 1f
        for (s in 0..1) {
            val side = if (s == 0) r * -1f else r * sk.farK
            val a0 = sk.sh[s] + side * -6f + u * 6f
            val a1 = sk.sh[s] + side * -2f - u * (44f * k)
            d.solid(Path.limb(a0, a1, 7f, 6f, 0f), c, line = 1.1f, depth = 1.5f)
        }
        if (g.kind == K.PACK || g.kind == K.FRAMEPACK) d.solid(Path.limb(sk.chest - r * 12f - u * 4f, sk.chest + r * (12f * sk.farK) - u * 4f, 3f, 3f, 0f), c, line = 0.8f, depth = 0.5f)
        if (g.kind == K.FRAMEPACK) d.solid(Path.limb(sk.waist - u * 10f - r * (sk.waistW + 4f), sk.waist - u * 10f + r * ((sk.waistW + 4f) * sk.farK), 8f, 8f, 0f), c, line = 1f, depth = 1.5f)
    }

    private fun neckItem(d: Drawing, sk: Sk, o: Outfit, g: Gear) {
        val u = sk.up; val r = sk.right
        val c = color(o, g); val a = accent(o, g)
        when (g.kind) {
            K.SCARF -> if (g.d.contains(D.BASIC)) {
                d.solid(Path.limb(sk.neck - r * (sk.neckW + 3f) + u * 2f, sk.neck + r * ((sk.neckW + 3f) * sk.farK) + u * 2f, 8f, 8f, 0.2f), c, line = 1.1f, depth = 2f)
                for (k in 0..4) d.fill(Path.circle(sk.neck - r * (8f - k * 4f) + u * 2f, 1f), Col.light(c, 0.5f))
            } else {
                val tri = Path.smooth(listOf(sk.neck - r * (sk.neckW + 4f) + u * 3f, sk.neck + r * ((sk.neckW + 4f) * sk.farK) + u * 3f, sk.neck + r * 2f - u * 26f), true)
                d.solid(tri, c, line = 1.2f, depth = 3f)
                d.group(clip = tri) { for (k in 0..5) fill(Path.circle(sk.neck - u * (4f + k * 4f) + r * (if (k % 2 == 0) -3f else 4f), 1.3f), a) }
                d.solid(Path.circle(sk.neck + r * ((sk.neckW + 2f) * sk.farK) + u * 1f, 3.6f), Col.shade(c, 0.1f), line = 1f, depth = 1f)
            }
            K.LANYARD -> {
                val pend = sk.chest - u * 8f + r * 2f
                d.stroke(Path.smooth(listOf(sk.neck - r * (sk.neckW + 1f) + u * 3f, sk.chest - r * 6f + u * 10f, pend + u * 5f, sk.chest + r * 8f + u * 10f, sk.neck + r * ((sk.neckW + 1f) * sk.farK) + u * 3f), false), a, 1.8f)
                d.solid(Path.circle(pend, 6.5f), Col.rgb(0xB89A5A), line = 1.1f, depth = 1.5f)
                d.fill(Path.circle(pend, 4.6f), Col.rgb(0xF2EEE4))
                d.fill(Path.poly(pend + P(0f, -4f), pend + P(1.2f, 0f), pend + P(-1.2f, 0f)), Col.rgb(0xC9403E))
                d.fill(Path.poly(pend + P(0f, 4f), pend + P(1.2f, 0f), pend + P(-1.2f, 0f)), Col.rgb(0x3E434C))
            }
            else -> Unit
        }
    }

    private fun chestItem(d: Drawing, sk: Sk, o: Outfit, g: Gear) {
        val u = sk.up; val r = sk.right
        val c = color(o, g); val a = accent(o, g)
        val q = sk.chest - r * 11f - u * 4f
        when (g.kind) {
            K.BIB -> { val b = sk.waist + u * 12f + r * (if (sk.q) 4f else 0f)
                d.solid(Path.roundRect(-14f, -10f, 14f, 10f, 1.5f).map { it + b }, Col.rgb(0xF5F3EE), line = 1f, depth = 1f, accent = false)
                d.fill(Path.rect(b.x - 14f, b.y - 10f, b.x + 14f, b.y - 6.5f), a)
                d.stroke(Path.smooth(listOf(b + P(-7f, -3f), b + P(-3f, -4.5f), b + P(-2f, 0f), b + P(-7f, 5f), b + P(-2f, 5f)), false), Col.rgb(0x2A2E34), 1.5f)
                d.stroke(Path.circle(b + P(5f, 0.5f), 3.6f), Col.rgb(0x2A2E34), 1.5f)
                for (s in listOf(-1f, 1f)) { d.fill(Path.circle(b + P(s * 11f, -8f), 2.1f), c); d.stroke(Path.circle(b + P(s * 11f, -8f), 2.1f), Col.ink(c), 0.7f) } }
            K.BADGE -> when {
                g.d.contains(D.WINGS) -> for (s in listOf(-1f, 1f)) { val wpath = Path.smooth(listOf(q, q + P(s * 9f, -5f), q + P(s * 12f, -1f), q + P(s * 8f, 1f), q + P(s * 10f, 3f), q + P(s * 4f, 3f)), true)
                    d.solid(wpath, c, line = 0.9f, depth = 1f); d.stroke(Path.line(q + P(s * 3f, 0f), q + P(s * 9f, -2f)), a, 0.7f) }
                g.d.contains(D.CONTOURS) -> { val b = Path.ellipse(q, 8f, 6.5f); d.solid(b, c, line = 1f, depth = 1f)
                    d.stroke(Path.ellipse(q, 7.2f, 5.7f), a, 0.9f)
                    for (k in 1..3) d.stroke(Path.smooth(listOf(q + P(-6f + k, 3f - k * 1.6f), q + P(-1f, -1f - k * 1.2f), q + P(5f - k * 0.5f, 2f - k * 1.4f)), false), a, 0.6f) }
                else -> { val b = Path.ellipse(q + P(0f, 1f), 3f, 4.2f); d.solid(b, a, line = 0.8f, depth = 0.6f)
                    for (k in 0..3) d.fill(Path.circle(q + P(-2.4f + k * 1.6f, -4.6f - (if (k == 1 || k == 2) 0.6f else 0f)), 0.9f), a)
                    d.stroke(Path.ellipse(q + P(0f, 0f), 5.6f, 6.6f), Col.rgb(0xC7A54A), 1f) }
            }
            K.POCKET_SQUARE -> { val pk = sk.chest - r * 12f - u * 8f
                d.solid(Path.poly(pk + P(-6f, -4f), pk + P(-3f, -10f), pk + P(0f, -5f), pk + P(3f, -11f), pk + P(6f, -4f)), c, line = 0.9f, depth = 1f)
                for (k in 0..2) d.fill(Path.circle(pk + P(-3f + k * 3f, -6f), 0.8f), a)
                d.solid(Path.roundRect(-7f, -4f, 7f, 6f, 1.2f).map { it + pk }, Col.shade(color(o, o.gear(Slot.OUTER) ?: o.gear(Slot.TOP) ?: g), 0.12f), line = 0.9f, depth = 1f) }
            else -> Unit
        }
    }

    /** Bolsas que cuelgan delante (cadera y bandolera). */
    fun frontOfTorso(d: Drawing, sk: Sk, o: Outfit) {
        val u = sk.up; val r = sk.right
        o.gear(Slot.SHOULDER)?.let { g ->
            val c = color(o, g); val a = accent(o, g)
            val from = sk.sh[1] + r * (-4f * sk.farK) + u * 4f
            val bagC = sk.hip[0] - r * 10f + u * (if (g.d.contains(D.BASIC)) 40f else 8f)
            d.solid(Path.limb(from, bagC + u * 8f, 4f, 4f, 0f), Col.shade(a, 0.1f), line = 0.9f, depth = 1f)
            when {
                g.d.contains(D.BINOCULARS) -> { d.solid(Path.roundRect(-11f, -9f, 11f, 9f, 5f).map { it + bagC }, c, line = 1.2f, depth = 2f)
                    for (s in listOf(-1f, 1f)) d.solid(Path.ellipse(bagC + P(s * 5.5f, 6f), 4.6f, 3.2f), Col.shade(c, 0.2f), line = 0.8f, depth = 0.6f) }
                g.d.contains(D.FLAP) -> { d.solid(Path.roundRect(-16f, -10f, 16f, 12f, 3f).map { it + bagC }, c, line = 1.3f, depth = 2.5f)
                    d.solid(Path.smooth(listOf(bagC + P(-16f, -10f), bagC + P(16f, -10f), bagC + P(15f, 5f), bagC + P(-15f, 5f)), true), Col.shade(c, 0.1f), line = 1f, depth = 1f)
                    d.solid(Path.roundRect(-2.5f, 2f, 2.5f, 7f, 0.8f).map { it + bagC }, Col.rgb(0xB89A5A), line = 0.6f, depth = 0.3f) }
                g.d.contains(D.TRANSLUCENT) -> { d.solid(Path.roundRect(-6f, -16f, 6f, 16f, 5f).map { it + bagC }, c, line = 1.2f, depth = 2f)
                    d.fill(Path.roundRect(-4f, -21f, 4f, -15f, 1.5f).map { it + bagC }, Col.rgb(0x3E434C))
                    d.stroke(Path.line(bagC + P(-6f, 6f), bagC + P(6f, 6f)), a, 2f) }
                else -> { d.solid(Path.roundRect(-12f, -7f, 12f, 7f, 5f).map { it + bagC }, c, line = 1.2f, depth = 2f)
                    d.stroke(Path.line(bagC + P(-9f, -2f), bagC + P(9f, -2f)), Col.rgb(0xB9BEC4), 0.9f) }
            }
        }
        o.gear(Slot.HIP)?.let { g ->
            val c = color(o, g); val a = accent(o, g)
            val clip = sk.waist - u * 12f - r * (sk.waistW + 4f)
            when (g.kind) {
                K.MAPBAG -> { val b = clip - u * 18f - r * 2f
                    d.solid(Path.limb(clip, b + u * 10f, 3f, 3f, 0f), Col.shade(a, 0.1f), line = 0.7f, depth = 0.5f)
                    d.solid(Path.roundRect(-10f, -12f, 10f, 12f, 2f).map { it + b }, c, line = 1.2f, depth = 2f)
                    d.fill(Path.roundRect(-7.5f, -8f, 7.5f, 9f, 1f).map { it + b }, Col.of(230, 238, 240, 170))
                    for (k in 0..3) d.stroke(Path.smooth(listOf(b + P(-6f, -6f + k * 4f), b + P(-1f, -4f + k * 4f), b + P(6f, -7f + k * 4f)), false), Col.rgb(0x6D8F6A), 0.7f) }
                K.CANTEEN -> { val b = clip - u * 16f
                    d.solid(Path.limb(clip, b + u * 9f, 3f, 3f, 0f), Col.shade(a, 0.2f), line = 0.7f, depth = 0.5f)
                    d.solid(Path.ellipse(b, 10f, 12f), c, line = 1.3f, depth = 2.5f)
                    d.stroke(Path.ellipse(b, 7.5f, 9.5f), Col.shade(c, 0.25f), 0.8f)
                    d.solid(Path.roundRect(-3f, -16f, 3f, -10f, 1f).map { it + b }, Col.rgb(0xA9AEB4), line = 0.8f, depth = 0.5f) }
                K.KEYCHAIN -> { val e = clip - u * 22f + r * 2f
                    d.stroke(Path.smooth(listOf(clip, clip - u * 10f + r * 3f, e), false), a, 2.6f)
                    d.stroke(Path.circle(e, 3.2f), Col.rgb(0xB0B5BB), 1.2f)
                    d.solid(Path.poly(e + P(1f, 2f), e + P(4f, 10f), e + P(2f, 11f), e + P(-0.5f, 3f)), Col.rgb(0xC7A54A), line = 0.6f, depth = 0.3f) }
                else -> Unit
            }
        }
        o.gear(Slot.WAIST)?.let { if (it.kind != K.TIED_SWEATER) Unit }
    }

    // ================================================================== cabeza

    fun head(d: Drawing, sk: Sk, o: Outfit) {
        o.gear(Slot.HEAD)?.let { headItem(d, sk, o, it) }
        o.gear(Slot.EYES)?.let { eyesItem(d, sk, o, it) }
    }

    private fun headItem(d: Drawing, sk: Sk, o: Outfit, g: Gear) {
        val c = color(o, g); val a = accent(o, g)
        fun h(x: Float, y: Float) = H(sk, x, y)
        val fwd = if (sk.q) 1f else 0f
        when (g.kind) {
            K.CAP -> {
                val crownTop = if (g.d.contains(D.SHORT_PEAK)) -38f else -42f
                val crown = Path.smooth(listOf(h(-28.5f, -10f), h(-28f, -26f), h(-18f, crownTop + 3f), h(0f, crownTop), h(18f, crownTop + 3f), h(28f, -26f), h(28.5f, -10f), h(0f, -12f)), true)
                // Visera: hacia la derecha en tres cuartos, de frente como una media elipse bajo la copa.
                val peakLen = if (g.d.contains(D.SHORT_PEAK)) 9f else 17f
                val peak = if (sk.q) Path.smooth(listOf(h(4f, -14f), h(26f + peakLen, -12f - (if (g.d.contains(D.SHORT_PEAK)) 5f else 0f)), h(30f + peakLen, -7f), h(14f, -8f)), true)
                    else Path.smooth(listOf(h(-24f, -11f), h(0f, -15f), h(24f, -11f), h(18f, -3f + peakLen * 0.15f), h(0f, -1f + peakLen * 0.2f), h(-18f, -3f + peakLen * 0.15f)), true)
                if (!sk.q) d.solid(peak, if (g.d.contains(D.BASIC)) c else a, line = 1.3f, depth = 2f)
                d.solid(crown, c, line = 1.5f, depth = 5f)
                if (sk.q) d.solid(peak, if (g.d.contains(D.BASIC)) Col.shade(c, 0.08f) else a, line = 1.3f, depth = 2f)
                val seams = if (g.d.contains(D.FIVE_PANEL)) listOf(-17f, 17f) else listOf(-16f, 0f, 16f)
                d.group(clip = crown) { for (x in seams) stroke(Path.smooth(listOf(h(0f, crownTop), h(x * 0.6f, -26f), h(x, -11f)), false), Col.shade(c, 0.3f), 0.9f)
                    if (g.d.contains(D.STRIPE)) for (k in -1..1) stroke(Path.line(h(k * 5f - 2f, crownTop - 2f), h(k * 5f + 2f, -10f)), a, 2.4f)
                    if (g.d.contains(D.CANVAS)) for (k in 0..10) stroke(Path.line(h(-28f + k * 6f, -12f), h(-22f + k * 6f, crownTop)), Col.shade(c, 0.12f), 0.6f) }
                if (g.d.contains(D.FIVE_PANEL)) d.solid(Path.roundRect(-9f, -32f, 9f, -18f, 3f).map { Face.at(sk, P(Face.skull(sk, it.x), it.y)) }, Col.light(c, 0.08f), line = 0.8f, depth = 1f)
                d.fill(Path.circle(h(0f, crownTop + 1f), 2.2f), Col.shade(c, 0.2f))
            }
            K.VISOR -> {
                val band = if (g.d.contains(D.BASIC)) 9f else 5f
                val bandP = Path.smooth(listOf(h(-27.5f, -16f - band / 2), h(0f, -21f - band / 2), h(27.5f, -16f - band / 2), h(27.5f, -16f + band / 2), h(0f, -21f + band / 2), h(-27.5f, -16f + band / 2)), true)
                d.solid(bandP, c, line = 1.2f, depth = 2f)
                if (g.d.contains(D.BASIC)) d.group(clip = bandP) { for (k in 0..14) stroke(Path.line(h(-27f + k * 4f, -22f), h(-27f + k * 4f, -10f)), Col.shade(c, 0.15f), 0.6f) }
                if (g.d.contains(D.CROSS_BAND)) d.stroke(Path.line(h(-26f, -18f), h(-24f, 4f)), a, 3f)
                val peak = if (sk.q) Path.smooth(listOf(h(6f, -17f), h(44f, -14f), h(46f, -9f), h(14f, -12f)), true)
                    else Path.smooth(listOf(h(-22f, -13f), h(0f, -17f), h(22f, -13f), h(16f, -4f), h(0f, -2f), h(-16f, -4f)), true)
                d.solid(peak, a, line = 1.2f, depth = 2f)
            }
            K.HEADBAND -> {
                val band = Path.smooth(listOf(h(-27.5f, -24f), h(0f, -28f), h(27.5f, -24f), h(27.5f, -17f), h(0f, -20f), h(-27.5f, -17f)), true)
                d.solid(band, c, line = 1.2f, depth = 2f)
                d.stroke(Path.smooth(listOf(h(-27f, -21f), h(0f, -24.5f), h(27f, -21f)), false), a, 1.2f)
                if (g.d.contains(D.KNOT)) { val k0 = h(if (sk.q) -26f else 26f, -21f); val s = if (sk.q) -1f else 1f
                    d.solid(Path.circle(k0, 4.2f), Col.shade(c, 0.05f), line = 1f, depth = 1f)
                    d.solid(Path.poly(k0 + P(s * 2f, 1f), k0 + P(s * 13f, 9f), k0 + P(s * 9f, 12f)), c, line = 1f, depth = 1f)
                    d.solid(Path.poly(k0 + P(s * 2f, 2f), k0 + P(s * 6f, 15f), k0 + P(s * 2f, 15f)), Col.shade(c, 0.1f), line = 1f, depth = 1f) }
            }
            K.HAT -> {
                val bucket = g.d.contains(D.BUCKET)
                val brimW = if (bucket) 38f else 47f
                val brim = Path.smooth(listOf(h(-brimW, -11f + (if (bucket) 4f else 1f)), h(-brimW * 0.6f, -18f), h(0f, -20f), h(brimW * 0.6f, -18f), h(brimW, -11f + (if (bucket) 4f else 1f)),
                    h(brimW * 0.6f, -6f + (if (bucket) 3f else 0f)), h(0f, -4f + (if (bucket) 3f else 0f)), h(-brimW * 0.6f, -6f + (if (bucket) 3f else 0f))), true)
                val crown = Path.smooth(listOf(h(-25f, -14f), h(-24f, -32f), h(-14f, -42f), h(0f, -44f), h(14f, -42f), h(24f, -32f), h(25f, -14f)), true)
                d.solid(brim, Col.shade(c, 0.05f), line = 1.4f, depth = 3f)
                d.solid(crown, c, line = 1.5f, depth = 5f)
                if (bucket) { for (k in 1..3) d.stroke(Path.smooth(listOf(h(-brimW + k * 3f, -10f + 3f), h(0f, -8f + k * 0.8f), h(brimW - k * 3f, -10f + 3f)), false), Col.shade(c, 0.3f), 0.6f)
                    for (k in 0..3) d.stroke(Path.smooth(listOf(h(-24f, -18f - k * 6f), h(0f, -20f - k * 6f), h(24f, -18f - k * 6f)), false), Col.shade(c, 0.25f), 0.6f) }
                else d.solid(Path.smooth(listOf(h(-25f, -19f), h(0f, -21f), h(25f, -19f), h(25f, -14f), h(0f, -15f), h(-25f, -14f)), true), a, line = 0.9f, depth = 1f)
                if (g.d.contains(D.CORD)) for (s in listOf(-1f, 1f)) d.stroke(Path.smooth(listOf(h(s * 22f, -9f), h(s * 14f, 18f), HF(sk, 0f, 34f)), false), Col.shade(a, 0.2f), 1f)
            }
            K.BEANIE -> {
                val flaps = g.d.contains(D.EARFLAPS)
                val dome = Path.smooth(listOf(h(-28f, -6f), h(-28f, -26f), h(-17f, -43f), h(0f, -46f), h(17f, -43f), h(28f, -26f), h(28f, -6f), h(0f, -9f)), true)
                d.solid(dome, c, line = 1.5f, depth = 5f)
                d.group(clip = dome) { for (k in -6..6) stroke(Path.line(h(k * 4.5f, -46f), h(k * 4.8f, -6f)), Col.shade(c, 0.18f), 0.8f) }
                d.solid(Path.smooth(listOf(h(-28.6f, -16f), h(0f, -19f), h(28.6f, -16f), h(28.6f, -5f), h(0f, -8f), h(-28.6f, -5f)), true), Col.shade(c, 0.08f), line = 1.2f, depth = 2f)
                if (flaps) for (s in listOf(-1f, 1f)) { if (sk.q && s > 0) continue
                    d.solid(Path.smooth(listOf(h(s * 28f, -8f), h(s * 29f, 8f), h(s * 24f, 18f), h(s * 19f, 8f), h(s * 20f, -6f)), true), a, line = 1.1f, depth = 2f)
                    d.stroke(Path.line(h(s * 24f, 18f), h(s * 22f, 30f)), Col.shade(a, 0.3f), 1.2f) }
                else d.solid(Path.circle(h(0f, -49f), 6f), a, line = 1.1f, depth = 2f)
            }
            K.HELMET -> {
                val compact = g.d.contains(D.COMPACT_VISOR)
                val shell = if (compact) Path.smooth(listOf(h(-30f, -8f), h(-31f, -28f), h(-18f, -46f), h(4f, -49f), h(24f, -42f), h(32f, -24f), h(31f, -8f), h(0f, -13f)), true)
                    else Path.smooth(listOf(h(-33f, -6f), h(-34f, -24f), h(-22f, -46f), h(2f, -52f), h(26f, -44f), h(35f, -24f), h(33f, -6f), h(14f, -12f), h(-14f, -12f)), true)
                for (s in listOf(-1f, 1f)) { if (sk.q && s > 0) continue
                    d.stroke(Path.smooth(listOf(h(s * 24f, -8f), h(s * 21f, 14f), HF(sk, s * 6f, 33f)), false), Col.rgb(0x2C2F35), 1.6f)
                    d.stroke(Path.line(h(s * 28f, -8f), h(s * 21f, 14f)), Col.rgb(0x2C2F35), 1.6f) }
                d.solid(shell, c, line = 1.6f, depth = 6f)
                d.group(clip = shell) {
                    if (g.d.contains(D.CHANNELS)) for (k in -2..2) fill(Path.smooth(listOf(h(k * 9f - 2f, -44f), h(k * 10f, -48f), h(k * 11f + 2f, -26f), h(k * 11f - 1f, -22f)), true), Col.rgb(0x1E2126))
                    else for (k in -1..1) fill(Path.smooth(listOf(h(k * 11f - 3f, -42f), h(k * 11f + 1f, -44f), h(k * 12f + 3f, -30f), h(k * 12f, -29f)), true), Col.rgb(0x1E2126))
                    stroke(Path.smooth(listOf(h(-34f, -12f), h(0f, -16f), h(34f, -12f)), false), a, 3f)
                }
                if (compact) d.solid(if (sk.q) Path.smooth(listOf(h(8f, -14f), h(36f, -14f), h(37f, -9f), h(12f, -10f)), true)
                    else Path.smooth(listOf(h(-22f, -11f), h(0f, -15f), h(22f, -11f), h(18f, -7f), h(-18f, -7f)), true), Col.rgb(0x2C3036), line = 1f, depth = 1f)
            }
            else -> Unit
        }
    }

    private fun eyesItem(d: Drawing, sk: Sk, o: Outfit, g: Gear) {
        val c = color(o, g); val a = accent(o, g)
        val l = HF(sk, -9.4f, 1.5f); val rr = HF(sk, 9.4f, 1.5f)
        if (g.d.contains(D.FOLD)) {
            for ((cc, k) in listOf(l to 1f, rr to (if (sk.q) 0.8f else 1f))) { val p = Path.ellipse(cc, 6.4f * k, 6.4f)
                d.fill(p, Col.of(210, 200, 170, 70)); d.stroke(p, c, 1.6f) }
            d.stroke(Path.line(l + P(6.4f, -1f), rr + P(-6f, -1f)), c, 1.4f)
            d.fill(Path.circle(HF(sk, 0f, 0.5f), 1.4f), a)
            d.stroke(Path.line(l + P(-6.4f, -1f), H(sk, -Face.cheekX(sk, AvatarLook.DEFAULT), 1f)), c, 1.3f)
        } else {
            val lens = Path.smooth(listOf(HF(sk, -19f, -2f), HF(sk, 0f, -4.5f), HF(sk, 19f, -2f), HF(sk, 18f, 5f), HF(sk, 9f, 7.5f), HF(sk, 0f, 3.5f), HF(sk, -9f, 7.5f), HF(sk, -18f, 5f)), true)
            d.fill(lens, Col.of(Col.r(a), Col.g(a), Col.b(a), 200))
            d.group(clip = lens) { fill(Path.rect(-200f, -200f, 400f, HF(sk, 0f, 0.5f).y), Col.of(255, 255, 255, 50)) }
            d.stroke(lens, c, 1.5f)
            d.stroke(Path.smooth(listOf(HF(sk, -19f, -3f), HF(sk, 0f, -6f), HF(sk, 19f, -3f)), false), c, 2.6f)
            d.stroke(Path.line(HF(sk, -19f, -1f), H(sk, -Face.cheekX(sk, AvatarLook.DEFAULT) - 1f, 0f)), c, 1.6f)
        }
    }

    // ================================================================== en la mano

    fun carry(d: Drawing, sk: Sk, o: Outfit, i: Int) {
        val g = o.gear(Slot.CARRY) ?: return
        val c = color(o, g)
        val hand = sk.wr[i] + sk.handDir[i] * 9f
        val ground = Figure.GROUND
        when (g.kind) {
            K.STICK -> if (i == 0) {
                val foot = P(hand.x + 12f, ground)
                val top = hand + (hand - foot).norm() * 16f
                d.solid(Path.limb(top, foot, 5.2f, 4f, 0f), Col.rgb(0x8A5A34), line = 1.1f, depth = 1.5f)
                d.solid(Path.limb(top, hand + (hand - foot).norm() * 4f, 7f, 7f, 0f), Col.rgb(0xC7A17A), line = 1f, depth = 1f)
                for (k in 0..5) d.fill(Path.circle(top.lerp(hand, k / 6f) + P(((k * 7) % 3) - 1f, 0f), 0.6f), Col.rgb(0x8E6B45))
                d.stroke(Path.smooth(listOf(top + P(0f, 4f), top + P(-6f, 12f), hand + P(-2f, 6f)), false), color(o, g, false), 1.3f)
            }
            K.POLES -> {
                val foot = P(hand.x + (if (i == 0) 14f else -8f), ground)
                val top = hand + (hand - foot).norm() * 12f
                val ink = Col.rgb(0x3E434C)
                d.solid(Path.limb(top, top.lerp(foot, 0.35f), 4.4f, 4.4f, 0f), if (i == 1) Col.shade(c, 0.1f) else c, line = 1f, depth = 1f)
                d.solid(Path.limb(top.lerp(foot, 0.35f), top.lerp(foot, 0.68f), 3.6f, 3.6f, 0f), Col.rgb(0xA9AEB4), line = 0.9f, depth = 0.8f)
                d.solid(Path.limb(top.lerp(foot, 0.68f), foot, 3f, 2.4f, 0f), Col.rgb(0xC5C9CE), line = 0.9f, depth = 0.6f)
                for (t in listOf(0.35f, 0.68f)) d.fill(Path.circle(top.lerp(foot, t), 2.8f), ink)
                d.fill(Path.ellipse(foot - P(0f, 9f), 5f, 1.6f), ink)
                d.solid(Path.limb(top, hand + (hand - foot).norm() * 2f, 6.4f, 6.4f, 0f), Col.rgb(0x2B2E33), line = 0.9f, depth = 1f)
            }
            else -> Unit
        }
    }

    // ================================================================== miniaturas

    /** Dibujo de una pieza sola (para fichas y láminas): se construye sobre un maniquí invisible. */
    fun thumbnail(g: Gear, tint: Tint? = null): Drawing {
        val pose = when { g.slot.group == Slot.Group.BIKE -> ArtPose.BIKE; g.kind == K.POLES || g.kind == K.STICK -> ArtPose.HIKE; else -> ArtPose.IDLE }
        val base = Outfit(mapOf(), v = 2)
        val o = (if (tint != null) base.withTint(g, tint) else base).with(g)
        val sk = Figure.skeleton(Scene(AvatarLook.DEFAULT.copy(hair = 0), o, ArtView.THREE_QUARTER, pose))
        val d = Drawing()
        when (g.slot) {
            Slot.TOP, Slot.FULL, Slot.OUTER -> { if (g.kind == K.CAPE) back(d, sk, o); for (i in listOf(1)) armLayers(d, sk, o, i)
                if (g.slot == Slot.FULL) { legLayers(d, sk, o, 1); legLayers(d, sk, o, 0); pelvis(d, sk, o) }
                torso(d, sk, o); armLayers(d, sk, o, 0); afterHand(d, sk, o, 0); if (g.d.contains(D.HOOD) || g.d.contains(D.HOOD_DETACH)) Unit }
            Slot.BOTTOM -> { val bare = o.copy(items = o.items + (Slot.SHOES.name to "__none")); legLayers(d, sk, bare, 1); legLayers(d, sk, bare, 0); pelvis(d, sk, bare) }
            Slot.SOCKS, Slot.SHOES, Slot.LACES, Slot.LEGWEAR -> legLayers(d, sk, o, 0)
            Slot.HEAD, Slot.EYES -> head(d, sk, o)
            Slot.NECK, Slot.CHEST -> torso(d, sk, o)
            Slot.WRIST -> afterHand(d, sk, o, 0)
            Slot.ARM -> armLayers(d, sk, o, 0)
            Slot.HANDS -> Figure.handShape(d, sk, 0, color(o, g), g)
            Slot.WAIST -> { back(d, sk, o); torso(d, sk, o) }
            Slot.HIP, Slot.SHOULDER -> frontOfTorso(d, sk, o)
            Slot.BACK -> { back(d, sk, o); backStraps(d, sk, o) }
            Slot.CARRY -> carry(d, sk, o, 0).also { carry(d, sk, o, 1) }
            else -> sk.bike?.let { Bike.part(d, it, o, g) }
        }
        return d
    }
}
