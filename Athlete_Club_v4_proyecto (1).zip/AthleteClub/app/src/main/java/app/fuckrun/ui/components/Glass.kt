package app.fuckrun.ui.components

import android.graphics.Bitmap
import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import app.fuckrun.ui.theme.C
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/*
 * MATERIAL DE CRISTAL DE ATHLETE CLUB (referencia: «Meet Liquid Glass», WWDC25).
 *
 * Construcción, de atrás hacia delante:
 *  1. Escena: el mapa, las tarjetas y el contenido desplazable se dibujan a tamaño real en una capa de origen
 *     ([Backdrop]). Los controles comparten esa misma capa y la muestrean en sus coordenadas de pantalla; el
 *     resultado se recorta por la silueta del control y lo que queda fuera conserva toda su definición.
 *  2. Centro: desenfoque (RenderEffect, Android 12+) que disuelve calles y letras y deja pasar las manchas grandes de
 *     luz y color. Cada control indica cuánta difusión necesita (el selector cerrado deja ver más fondo; el menú
 *     abierto, más difusión).
 *  3. Borde (Android 13+): shader AGSL que muestrea la escena NÍTIDA con un desplazamiento perpendicular al
 *     contorno en una franja estrecha y se desvanece hacia el centro: una línea que pasa bajo la cápsula se curva en
 *     el canto y se suaviza dentro. El reflejo usa la misma normal: gana luz en el arco orientado a la luz y la pierde
 *     en el opuesto; sobre fondo uniforme solo queda un borde discreto.
 *  4. Volumen y contraste: sombra corta de contacto y tinte que se ajustan a la luminosidad y al detalle que hay detrás
 *     (sondeo de la capa ya difuminada unas tres veces por segundo, nunca en cada fotograma); los cambios se suavizan.
 *  5. Primer plano: iconos y textos se dibujan después, nítidos, con un color de tinta que se adapta al fondo.
 *
 * Versiones reducidas (documentadas en docs/CRISTAL.md): Android 12 sin borde refractado; Android ≤ 11 o
 * «Reducir transparencia», película casi opaca legible. En los tres casos se conserva la misma respuesta táctil.
 */

// ------------------------------------------------------------------------------------------- escena compartida

/** Capa de la escena que muestrean los controles. Se registra en cada fotograma del contenido, en la GPU. */
@Stable
class Backdrop internal constructor(val layer: GraphicsLayer) {
    /** Posición de la capa de origen en la ventana. */
    var origin by mutableStateOf(Offset.Zero)
    internal var ready by mutableStateOf(false)
}

@Composable
fun rememberBackdrop(): Backdrop {
    val l = rememberGraphicsLayer()
    return remember(l) { Backdrop(l) }
}

/**
 * Escena por la que pasan los controles de cristal. LO QUE ESTÁ DENTRO no puede usar esta misma escena (sería
 * recursivo): dentro se proporciona `LocalBackdrop = null` o una escena local (p. ej. el mapa de Rutas).
 */
val LocalBackdrop = compositionLocalOf<Backdrop?> { null }
/** «Reducir transparencia»: más opacidad en el cristal. */
val LocalReduceTransparency = staticCompositionLocalOf { false }
/** Color de tinta para iconos y textos dentro de un control de cristal (se adapta al fondo). */
val LocalGlassInk = compositionLocalOf { Color.Unspecified }

fun Modifier.backdropSource(b: Backdrop): Modifier = this
    .onGloballyPositioned { b.origin = it.positionInRoot() }
    .drawWithContent {
        b.layer.record { this@drawWithContent.drawContent() }
        b.ready = true
        drawLayer(b.layer)
    }

// ------------------------------------------------------------------------------------------- respuesta táctil

/**
 * Estado de presión compartido entre la forma del cristal y el gesto. [k] va de 0 (reposo) a 1 (presionado);
 * [touch] es la posición del dedo en el control.
 */
@Stable
class LiquidPress internal constructor(private val scope: CoroutineScope, private val reduce: Boolean) {
    val anim = Animatable(0f)
    var touch by mutableStateOf(Offset.Unspecified)
    var held by mutableStateOf(false)
        private set

    fun down(at: Offset) {
        touch = at; held = true
        // Desde el primer fotograma: transición de entrada de 85 ms (ajuste inicial de Athlete Club).
        scope.launch { anim.animateTo(1f, tween(if (reduce) 60 else 85, easing = LinearOutSlowInEasing)) }
    }
    fun move(at: Offset) { touch = at }
    /** Al soltar o cancelar: contorno, refracción y luz vuelven juntos desde el estado alcanzado (muelle de ~170 ms). */
    fun up() {
        held = false
        scope.launch { anim.animateTo(0f, if (reduce) tween(120) else spring(dampingRatio = 0.72f, stiffness = 900f)) }
    }
}

@Composable
fun rememberLiquidPress(): LiquidPress {
    val scope = rememberCoroutineScope()
    val reduce = LocalReduceMotion.current
    return remember(scope, reduce) { LiquidPress(scope, reduce) }
}

/**
 * Sigue el dedo sin retrasos (fase inicial del gesto): presión al posar el dedo, brillo que sigue al dedo si se mueve
 * dentro, y retorno al soltar. Si el gesto se convierte en desplazamiento (otro lo consume) se recupera la forma; la
 * acción la dispara `clickable` una sola vez al soltar dentro.
 */
fun Modifier.liquidGesture(p: LiquidPress, enabled: Boolean): Modifier = if (!enabled) this else pointerInput(p) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        p.down(down.position)
        try {
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Final)
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!ch.pressed) break
                if (ch.isConsumed && (ch.position - down.position).getDistance() > viewConfiguration.touchSlop) break
                p.move(ch.position)
            }
        } finally { p.up() }
    }
}

/** Contorno deformado por la presión: el lado tocado cede 1–3 dp hacia fuera y el extremo opuesto queda anclado. */
fun pressedBounds(size: Size, p: LiquidPress?, density: Float, reduce: Boolean): Rect {
    val k = if (reduce || p == null) 0f else p.anim.value
    if (k <= 0.001f) return Rect(0f, 0f, size.width, size.height)
    val fx = if (p!!.touch.isSpecified && size.width > 0f) (p.touch.x / size.width).coerceIn(0f, 1f) else 0.5f
    val d = 2.6f * density * k
    val wl = d * (((1f - fx) * 1.5f - 0.25f).coerceIn(0f, 1f)) * 1.25f
    val wr = d * ((fx * 1.5f - 0.25f).coerceIn(0f, 1f)) * 1.25f
    val dy = size.height * 0.012f * k
    return Rect(-wl, dy, size.width + wr, size.height - dy)
}

// ------------------------------------------------------------------------------------------- material

enum class GlassKind {
    /** Material regular adaptable: barra, botones y menús con texto. */
    REGULAR,
    /** Botón de acción con color (Empezar, Pausar, Terminar…): color propio + contribución visible del fondo. */
    TINTED,
}

/** Medida de lo que hay detrás: luminosidad media (0–1) y detalle (desviación). */
@Stable
class GlassProbe { var lum by mutableFloatStateOf(0.5f); var detail by mutableFloatStateOf(0.1f); var valid by mutableStateOf(false) }

private class GlassLayers(val blur: GraphicsLayer, val edge: GraphicsLayer) { var pos = Offset.Zero }

/**
 * Pinta el material de cristal detrás del contenido del control.
 * @param shapeOf contorno (puede depender del tamaño deformado y de la animación de un menú).
 * @param blur difusión central; [extraTint] intensifica el tinte (menú abierto, presión mantenida…).
 */
fun Modifier.liquidGlass(
    shapeOf: (Rect) -> Shape,
    tint: Color,
    kind: GlassKind = GlassKind.REGULAR,
    press: LiquidPress? = null,
    blur: Dp = 32.dp,
    extraTint: () -> Float = { 0f },
    shadow: () -> Float = { 1f },
    probe: GlassProbe? = null,
    bounds: (Size) -> Rect? = { null },
    hidden: () -> Boolean = { false },
): Modifier = composed {
    val backdrop = LocalBackdrop.current
    val reduceT = LocalReduceTransparency.current
    val reduce = LocalReduceMotion.current
    val blurL = rememberGraphicsLayer(); val edgeL = rememberGraphicsLayer()
    val layers = remember(blurL, edgeL) { GlassLayers(blurL, edgeL) }
    var pos by remember { mutableStateOf(Offset.Zero) }
    val dark = C.isDark
    val live = backdrop != null && !reduceT && Build.VERSION.SDK_INT >= 31
    val shader = remember { if (Build.VERSION.SDK_INT >= 33) GlassShaders.edge() else null }
    // Sondeo de fondo: ~3 veces por segundo, sobre la muestra ya difuminada y pequeña (nunca en cada fotograma).
    if (probe != null && live) LaunchedEffect(backdrop, probe) {
        while (isActive) {
            delay(330)
            runCatching { measure(layers.blur, probe) }
        }
    }
    val lumA by animateFloatAsState(probe?.takeIf { it.valid }?.lum ?: if (dark) 0.15f else 0.9f, tween(320), label = "lum")
    val detA by animateFloatAsState(probe?.takeIf { it.valid }?.detail ?: 0.1f, tween(320), label = "detail")
    this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .drawBehind {
            if (hidden()) return@drawBehind
            val r = bounds(size) ?: pressedBounds(size, press, density, reduce)
            val shape = shapeOf(r)
            val outline = shape.createOutline(r.size, layoutDirection, this)
            val path = Path().apply { addOutline(outline); translate(r.topLeft) }
            // 4a. Sombra corta de contacto: más separación sobre texto denso, más ligera sobre fondo uniforme.
            val sh = (0.10f + 0.16f * detA + (if (lumA > 0.7f) 0.04f else 0f)) * shadow()
            for (i in 1..3) translate(0f, (0.6f + i * 0.6f).dp.toPx()) {
                drawPath(path, Color.Black.copy(alpha = sh / (i + 0.5f)))
            }
            if (live && backdrop!!.ready) {
                val blurPx = blur.toPx()
                val pad = (blurPx * 1.6f).coerceAtLeast(12f)
                val lsz = IntSize((r.width + 2 * pad).toInt().coerceAtLeast(1), (r.height + 2 * pad).toInt().coerceAtLeast(1))
                val off = Offset(pad - r.left - (pos.x - backdrop.origin.x), pad - r.top - (pos.y - backdrop.origin.y))
                // 2. Centro difuminado.
                layers.blur.renderEffect = BlurEffect(blurPx, blurPx, TileMode.Clamp)
                layers.blur.record(lsz) { translate(off.x, off.y) { drawLayer(backdrop.layer) } }
                clipPath(path) { translate(r.left - pad, r.top - pad) { drawLayer(layers.blur) } }
                // 3. Borde refractado (Android 13+).
                if (shader != null && Build.VERSION.SDK_INT >= 33) {
                    val corner = (outline as? Outline.Rounded)?.roundRect?.topLeftCornerRadius?.x ?: (min(r.width, r.height) / 2f)
                    val pt = press?.touch?.takeIf { it.isSpecified } ?: Offset(-9999f, -9999f)
                    layers.edge.renderEffect = GlassShaders.effect(shader, pad, r.size, corner, 9.dp.toPx(), 6.dp.toPx(),
                        Offset(pt.x - r.left + pad, pt.y - r.top + pad), press?.anim?.value ?: 0f, if (dark) 0.22f else 0.32f, dark)
                    layers.edge.record(lsz) { translate(off.x, off.y) { drawLayer(backdrop.layer) } }
                    clipPath(path) { translate(r.left - pad, r.top - pad) { drawLayer(layers.edge) } }
                }
                // 4b. Tinte adaptable: en fondo claro aclara y en oscuro oscurece lo justo para leer; más sobre detalle denso.
                val baseA = when (kind) { GlassKind.REGULAR -> if (dark) 0.34f else 0.46f; GlassKind.TINTED -> 0.72f }
                val a = (baseA + 0.18f * detA + extraTint() + (press?.let { if (it.held) 0.08f * it.anim.value else 0f } ?: 0f)).coerceIn(0f, 0.96f)
                if (kind == GlassKind.REGULAR) {
                    drawPath(path, C.Surface.copy(alpha = a))
                    if (tint != C.Surface && tint.alpha > 0f) drawPath(path, tint)
                } else drawPath(path, tint.copy(alpha = (a * tint.alpha).coerceIn(0f, 1f)))
            } else {
                // Versión reducida: película casi opaca, legible sobre el mapa.
                if (kind == GlassKind.TINTED) drawPath(path, tint)
                else { drawPath(path, C.Surface.copy(alpha = 0.95f)); if (tint != C.Surface && tint.alpha > 0f) drawPath(path, tint) }
            }
            // Filo discreto: solo en el arco que mira a la luz (sin borde blanco permanente).
            if (shader == null || !live) {
                drawPath(path, Brush.linearGradient(listOf(Color.White.copy(alpha = if (dark) 0.22f else 0.6f), Color.Transparent, Color.Transparent),
                    start = r.topLeft, end = r.bottomRight), style = Stroke(1.dp.toPx()))
            } else drawPath(path, Color.White.copy(alpha = if (dark) 0.05f else 0.12f), style = Stroke(0.6.dp.toPx()))
            // Brillo cerca del contacto (también en la versión reducida).
            press?.let { pp ->
                val k = pp.anim.value
                if (k > 0.01f && pp.touch.isSpecified) clipPath(path) {
                    drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = (if (dark) 0.18f else 0.28f) * k), Color.Transparent), center = pp.touch,
                        radius = max(r.height, 24.dp.toPx()) * 1.1f), radius = max(r.height, 24.dp.toPx()) * 1.1f, center = pp.touch)
                }
            }
        }
}

/** Color de tinta adecuado para lo que hay detrás del cristal (se anima al cambiar de fondo claro a oscuro). */
@Composable
fun rememberGlassInk(probe: GlassProbe?, fallback: Color): Color {
    val dark = C.isDark
    val target = when {
        probe == null || !probe.valid -> fallback
        probe.lum > 0.62f -> Color(0xFF0E1116)
        probe.lum < 0.38f -> Color(0xFFF5F6F8)
        else -> if (dark) Color(0xFFF5F6F8) else Color(0xFF0E1116)
    }
    val c by animateColorAsState(target, tween(280), label = "ink")
    return c
}

private suspend fun measure(layer: GraphicsLayer, probe: GlassProbe) {
    if (layer.size.width <= 0 || layer.size.height <= 0) return
    val img = layer.toImageBitmap().asAndroidBitmap()
    val bmp = if (img.config == Bitmap.Config.HARDWARE) img.copy(Bitmap.Config.ARGB_8888, false) else img
    val w = bmp.width; val h = bmp.height
    var n = 0; var sum = 0.0; var sum2 = 0.0
    val cols = 12; val rows = 5
    for (yy in 1..rows) for (xx in 1..cols) {
        val c = bmp.getPixel((w * xx / (cols + 1)).coerceIn(0, w - 1), (h * yy / (rows + 1)).coerceIn(0, h - 1))
        val l = (0.2126 * ((c shr 16) and 0xFF) + 0.7152 * ((c shr 8) and 0xFF) + 0.0722 * (c and 0xFF)) / 255.0
        sum += l; sum2 += l * l; n++
    }
    if (bmp !== img) bmp.recycle()
    val mean = sum / n
    probe.lum = mean.toFloat()
    probe.detail = sqrt(max(0.0, sum2 / n - mean * mean)).toFloat().coerceIn(0f, 0.5f) * 2f
    probe.valid = true
}

@RequiresApi(33)
internal object GlassShaders {
    /** Borde: desplazamiento perpendicular al contorno en una franja estrecha + reflejo con la misma curvatura. */
    private const val EDGE = """
        uniform shader content;
        uniform float2 origin;
        uniform float2 size;
        uniform float radius;
        uniform float band;
        uniform float strength;
        uniform float2 press;
        uniform float pressK;
        uniform float rim;
        uniform float dark;
        float sd(float2 p, float2 b, float r) {
            float2 q = abs(p) - b + r;
            return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
        }
        half4 main(float2 xy) {
            float2 b = size * 0.5;
            float2 p = xy - (origin + b);
            float r = min(radius, min(b.x, b.y));
            float d = sd(p, b, r);
            if (d > 1.0) { return half4(0.0); }
            float e = 0.8;
            float2 n = float2(sd(p + float2(e, 0.0), b, r) - sd(p - float2(e, 0.0), b, r),
                              sd(p + float2(0.0, e), b, r) - sd(p - float2(0.0, e), b, r));
            n = n / max(length(n), 1e-4);
            float t = clamp(-d / band, 0.0, 1.0);
            float bend = 1.0 - t;
            bend = bend * bend * (3.0 - 2.0 * bend);
            // La escena nítida se toma desplazada hacia fuera: el trazo se curva en el canto.
            half4 col = content.eval(xy + n * strength * bend);
            // Luz: arco orientado arriba-izquierda gana luz; el opuesto la pierde.
            float2 L = normalize(float2(-0.55, -0.83));
            float facing = dot(n, L);
            float edge = (1.0 - t) * (1.0 - t) * (1.0 - t);
            float pd = length(xy - press);
            float glow = pressK * exp(-pd * pd / 3200.0) * edge;
            float lit = max(facing, 0.0) * edge * rim + glow * 0.8;
            float shade = max(-facing, 0.0) * edge * rim * (0.35 + 0.25 * dark);
            float a = smoothstep(0.0, 1.0, 1.0 - t);
            half3 rgb = col.rgb + half3(lit) - half3(shade);
            return half4(rgb * a, col.a * a);
        }
    """

    fun edge() = RuntimeShader(EDGE)

    fun effect(s: RuntimeShader, pad: Float, size: Size, radius: Float, band: Float, strength: Float, press: Offset, pressK: Float, rim: Float, dark: Boolean): RenderEffect {
        s.setFloatUniform("origin", pad, pad)
        s.setFloatUniform("size", size.width, size.height)
        s.setFloatUniform("radius", radius)
        s.setFloatUniform("band", band)
        s.setFloatUniform("strength", strength)
        s.setFloatUniform("press", press.x, press.y)
        s.setFloatUniform("pressK", pressK)
        s.setFloatUniform("rim", rim)
        s.setFloatUniform("dark", if (dark) 1f else 0f)
        return android.graphics.RenderEffect.createRuntimeShaderEffect(s, "content").asComposeRenderEffect()
    }
}
