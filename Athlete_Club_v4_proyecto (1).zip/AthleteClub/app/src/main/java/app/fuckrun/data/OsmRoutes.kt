package app.fuckrun.data

import android.content.Context
import app.fuckrun.BuildConfig
import app.fuckrun.domain.RouteCandidate
import app.fuckrun.domain.RouteSelect
import app.fuckrun.domain.RouteShape
import app.fuckrun.domain.Sport
import app.fuckrun.domain.metrics.RunMetrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Rutas reales por ciudad a partir de OpenStreetMap (Overpass API, datos © colaboradores de OpenStreetMap, ODbL).
 *
 * Qué se considera una ruta: una relación `type=route` señalizada. Modalidad por la etiqueta `route=*`
 * (ver docs/RUTAS.md): bicicleta → `bicycle`, `mtb`; senderismo → `hiking`, `foot`; caminata → `foot`, `walking`,
 * `hiking` corto; correr → `running`, `fitness_trail`, `foot` y `hiking` corto. Nunca se supone que una ruta a pie admite bicicleta.
 *
 * De la ciudad: la ruta EMPIEZA dentro del término municipal (comprobado con el contorno administrativo de OSM).
 * Una ruta que solo atraviesa el municipio no se le atribuye. Las de alrededores se ofrecen aparte, con su municipio y distancia.
 *
 * Sin conexión: se usa la última selección guardada de esa ciudad y deporte.
 */
class OsmRoutes(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "osm-routes").apply { mkdirs() }
    private val knownFile = File(dir, "known.json")
    private val known = ConcurrentHashMap<String, VerifiedRoute>()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    init {
        runCatching {
            if (knownFile.exists()) json.decodeFromString(ListSerializer(VerifiedRoute.serializer()), knownFile.readText()).forEach { known[it.id] = it }
        }
    }

    fun byId(id: String?): VerifiedRoute? = id?.let { known[it] }
    fun all(): List<VerifiedRoute> = known.values.toList()

    @Serializable
    data class CityCache(val key: String, val ids: List<String>, val total: Int, val fetchedAt: Long,
                         val centerLat: Double? = null, val centerLon: Double? = null)

    data class NearbyRoute(val route: VerifiedRoute, val municipality: String?, val distanceKm: Double)

    data class CityResult(
        val routes: List<VerifiedRoute>,          // hasta 5, distintas y estables
        val totalInCity: Int,                     // rutas aptas encontradas en el municipio (antes de elegir 5)
        val fetchedAt: Long?,
        val fromCache: Boolean,
        val error: String?,
        val center: LatLon?,
    )

    private fun key(m: Municipality, s: Sport) = "${m.cpro}|${MunicipalityIndex.norm(m.name)}|${s.name}"
    private fun cacheFile(k: String) = File(dir, "city_" + k.replace(Regex("[^A-Za-z0-9]"), "_") + ".json")

    /**
     * true si las búsquedas guardadas de Sendero indican que el municipio no tiene catálogo de rutas verificadas
     * (ninguna ruta apta). Entonces SEN-23 y SEN-24 se consiguen con 4 y 8 semanas activas.
     */
    fun hikeCatalogKnownEmpty(): Boolean = runCatching {
        val files = dir.listFiles { f -> f.name.startsWith("city_") && f.name.endsWith("_HIKE.json") }.orEmpty()
        val totals = files.mapNotNull { f -> runCatching { json.decodeFromString(CityCache.serializer(), f.readText()).total }.getOrNull() }
        totals.isNotEmpty() && totals.all { it == 0 }
    }.getOrDefault(false)

    /** Última selección guardada (sin red). */
    fun cached(m: Municipality, s: Sport): CityResult? = runCatching {
        val c = json.decodeFromString(CityCache.serializer(), cacheFile(key(m, s)).readText())
        CityResult(c.ids.mapNotNull { known[it] }, c.total, c.fetchedAt, true, null,
            if (c.centerLat != null && c.centerLon != null) LatLon(c.centerLat, c.centerLon) else null)
    }.getOrNull()

    /**
     * Rutas de la ciudad aptas para el deporte. `filter` se aplica ANTES de elegir las cinco.
     * Con la misma ciudad, deporte y filtros devuelve siempre las mismas cinco.
     */
    suspend fun forCity(m: Municipality, sport: Sport, filter: (VerifiedRoute) -> Boolean = { true }, refresh: Boolean = false): CityResult =
        withContext(Dispatchers.IO) {
            val k = key(m, sport)
            val cache = cached(m, sport)
            val raw: Pair<List<VerifiedRoute>, LatLon?> = try {
                if (!refresh && cache != null && System.currentTimeMillis() - (cache.fetchedAt ?: 0) < 7L * 24 * 3600_000 && cityAll[k] != null) {
                    cityAll[k]!! to cache.center
                } else fetchCity(m, sport).also { cityAll[k] = it.first }
            } catch (e: Exception) {
                val c = cache ?: return@withContext CityResult(emptyList(), 0, null, false, errorText(e), null)
                return@withContext c.copy(error = errorText(e))
            }
            val candidates = raw.first.filter(filter)
            val picked = RouteSelect.pick(candidates.map { it.candidate() }).mapNotNull { c -> candidates.firstOrNull { it.id == c.id } }
            picked.forEach { known[it.id] = it }
            persistKnown()
            val now = System.currentTimeMillis()
            runCatching {
                cacheFile(k).writeText(json.encodeToString(CityCache.serializer(),
                    CityCache(k, picked.map { it.id }, candidates.size, now, raw.second?.lat, raw.second?.lon)))
            }
            CityResult(picked, RouteSelect.dedupe(candidates.map { it.candidate() }).size, now, false, null, raw.second)
        }

    /** Todas las rutas de la ciudad y deporte descargadas en esta sesión (para refiltrar sin red). */
    private val cityAll = ConcurrentHashMap<String, List<VerifiedRoute>>()

    /** Rutas aptas que empiezan FUERA del municipio, a menos de `radiusKm` de su centro, con su municipio y distancia. */
    suspend fun nearby(m: Municipality, sport: Sport, center: LatLon, radiusKm: Int = 15, exclude: Set<String>): List<NearbyRoute> =
        withContext(Dispatchers.IO) {
            val q = """
                [out:json][timeout:60];
                rel(around:${radiusKm * 1000},${center.lat},${center.lon})["type"="route"]["route"~"${routeRegex(sport)}"];
                out tags geom meta;
            """.trimIndent()
            val routes = parseRoutes(overpass(q), sport).filter { it.id !in exclude && !it.id.let { id -> known[id]?.municipality == m.name } }
            val sel = RouteSelect.pick(routes.map { it.candidate() }, 5).mapNotNull { c -> routes.firstOrNull { it.id == c.id } }
            val places = runCatching { municipalitiesAt(sel.map { LatLon(it.start.lat, it.start.lon) }) }.getOrDefault(sel.map { null })
            sel.mapIndexed { i, r ->
                val muni = places.getOrNull(i)
                val withMuni = r.copy(municipality = muni ?: "Alrededores de ${m.name}", province = "")
                known[r.id] = withMuni
                NearbyRoute(withMuni, muni, RunMetrics.haversine(center.lat, center.lon, r.start.lat, r.start.lon) / 1000.0)
            }.filter { it.municipality == null || MunicipalityIndex.norm(it.municipality) != MunicipalityIndex.norm(m.name) }
                .also { persistKnown() }
        }

    // ---------- Overpass ----------

    private fun alternatives(name: String) = name.split("/").map { it.trim() }.filter { it.isNotEmpty() }
        .joinToString("|") { it.replace(Regex("[\\\\^$.|?*+()\\[\\]{}\"]"), "") }

    private fun routeRegex(s: Sport) = when (s) {
        Sport.BIKE -> "^(bicycle|mtb)$"
        Sport.RUN -> "^(running|fitness_trail|foot|hiking)$"
        Sport.HIKE -> "^(hiking|foot)$"
        Sport.WALK -> "^(foot|walking|hiking)$"
    }

    private suspend fun fetchCity(m: Municipality, sport: Sport): Pair<List<VerifiedRoute>, LatLon?> {
        val mun = alternatives(m.name); val prov = alternatives(m.province)
        val q = """
            [out:json][timeout:90];
            area["ISO3166-1"="ES"]["admin_level"="2"]->.es;
            rel(area.es)["boundary"="administrative"]["admin_level"="6"]["name"~"($prov)",i]->.p;
            .p map_to_area->.pa;
            rel(area.pa)["boundary"="administrative"]["admin_level"="8"]["name"~"^($mun)$",i]->.m;
            .m map_to_area->.ma;
            rel(area.ma)["type"="route"]["route"~"${routeRegex(sport)}"]->.r;
            .m out geom tags;
            .r out tags geom meta;
        """.trimIndent()
        val root = overpass(q)
        val elements = root["elements"]?.jsonArray ?: JsonArray(emptyList())
        val munis = elements.filter { it.jsonObject.str("type") == "relation" && it.jsonObject["tags"]?.jsonObject?.str("admin_level") == "8" }
        if (munis.isEmpty()) throw IllegalStateException("No encontramos «${m.name}» en OpenStreetMap")
        val muni = munis.first().jsonObject
        val boundary = boundarySegments(muni)
        val center = boundaryCenter(boundary)
        val routes = parseRoutes(root, sport).filter { r -> boundary.isEmpty() || inside(r.start.lat, r.start.lon, boundary) }
            .map { it.copy(municipality = m.name, province = m.province, cpro = m.cpro) }
        return routes to center
    }

    /** Municipio (admin_level 8) en el que cae cada punto, en una sola consulta. */
    private fun municipalitiesAt(points: List<LatLon>): List<String?> {
        if (points.isEmpty()) return emptyList()
        val q = buildString {
            append("[out:json][timeout:60];\n")
            points.forEachIndexed { i, p ->
                append("is_in(${p.lat},${p.lon})->.a$i;\narea.a$i[\"admin_level\"=\"8\"];\nout tags;\nmake marker n=$i;\nout;\n")
            }
        }
        val els = overpass(q)["elements"]?.jsonArray ?: return points.map { null }
        val res = MutableList<String?>(points.size) { null }
        var pending: String? = null
        for (e in els) {
            val o = e.jsonObject
            if (o.str("type") == "marker") { val n = o["tags"]?.jsonObject?.str("n")?.toIntOrNull(); if (n != null && n < res.size) res[n] = pending; pending = null }
            else pending = o["tags"]?.jsonObject?.str("name") ?: pending
        }
        return res
    }

    private fun overpass(query: String): JsonObject {
        val c = URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15_000; c.readTimeout = 90_000
            c.setRequestProperty("User-Agent", "AthleteClub/${BuildConfig.VERSION_NAME} (Android)")
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            c.outputStream.use { it.write(("data=" + URLEncoder.encode(query, "UTF-8")).toByteArray()) }
            if (c.responseCode != 200) throw IllegalStateException("El servicio de rutas no responde (${c.responseCode})")
            return json.parseToJsonElement(c.inputStream.bufferedReader().readText()).jsonObject
        } finally { c.disconnect() }
    }

    private fun errorText(e: Exception) = when (e) {
        is java.net.UnknownHostException, is java.net.SocketTimeoutException, is java.io.IOException -> "Sin conexión con el servicio de rutas"
        else -> e.message ?: "No se han podido cargar las rutas"
    }

    // ---------- Conversión ----------

    private fun JsonObject.str(k: String) = this[k]?.jsonPrimitive?.contentOrNull

    private fun parseRoutes(root: JsonObject, sport: Sport): List<VerifiedRoute> {
        val els = root["elements"]?.jsonArray ?: return emptyList()
        return els.mapNotNull { e ->
            val o = e.jsonObject
            val tags = o["tags"]?.jsonObject ?: return@mapNotNull null
            if (o.str("type") != "relation" || tags.str("type") != "route") return@mapNotNull null
            val routeTag = tags.str("route") ?: return@mapNotNull null
            val track = assemble(o["members"]?.jsonArray ?: JsonArray(emptyList()))
            if (track.size < 2) return@mapNotNull null
            val dist = track.zipWithNext { a, b -> RunMetrics.haversine(a.lat, a.lon, b.lat, b.lon) }.sum()
            val sports = sportsFor(routeTag, dist, tags.str("sac_scale"))
            if (sport.name !in sports) return@mapNotNull null
            val first = track.first(); val last = track.last()
            val loop = tags.str("roundtrip") == "yes" || RunMetrics.haversine(first.lat, first.lon, last.lat, last.lon) < 300
            val ascent = tags.str("ascent")?.filter { it.isDigit() || it == '.' }?.toDoubleOrNull()
            val restrictions = buildList {
                tags.str("access")?.takeIf { it != "yes" }?.let { add("Acceso: $it") }
                tags.str("bicycle")?.takeIf { it == "no" }?.let { add("No apta para bicicleta") }
                tags.str("foot")?.takeIf { it == "no" }?.let { add("No apta a pie") }
                tags.str("seasonal")?.let { add("Estacional: $it") }
                tags.str("opening_hours")?.let { add("Horario: $it") }
            }
            val date = o.str("timestamp")?.take(10) ?: ""
            val id = "osm:${o["id"]?.jsonPrimitive?.longOrNull ?: return@mapNotNull null}"
            VerifiedRoute(
                id = id, name = tags.str("name") ?: tags.str("ref")?.let { "Ruta $it" } ?: "Ruta sin nombre",
                municipality = "", province = "", cpro = "",
                shape = if (loop) RouteShape.LOOP else RouteShape.LINEAR, distanceM = dist,
                surface = tags.str("surface")?.let { surfaceLabel(it) }, elevationGainM = ascent,
                start = RouteStart(first.lat, first.lon, tags.str("from") ?: "Inicio del trazado"),
                track = simplify(track, 400),
                source = RouteSource("OpenStreetMap", "ODbL", "https://www.openstreetmap.org/relation/${id.removePrefix("osm:")}"),
                reviewedAt = date,
                incidents = restrictions.map { RouteIncident(it, date) },
                verifiedAttributes = listOfNotNull(tags.str("network")?.let { "Red: ${networkLabel(it)}" }, "Modalidad OSM: ${routeLabel(routeTag)}"),
                sports = sports,
            )
        }
    }

    private fun sportsFor(route: String, distM: Double, sac: String?): List<String> {
        val easy = sac == null || sac == "hiking"
        return when (route) {
            "bicycle", "mtb" -> listOf("BIKE")
            "running", "fitness_trail" -> listOf("RUN", "WALK")
            "foot", "walking" -> listOf("RUN", "WALK", "HIKE")
            "hiking" -> buildList { add("HIKE"); if (easy && distM <= 15_000) add("WALK"); if (easy && distM <= 30_000) add("RUN") }
            else -> emptyList()
        }
    }

    private fun routeLabel(r: String) = when (r) { "bicycle" -> "ruta ciclista"; "mtb" -> "ruta de BTT"; "hiking" -> "senderismo"
        "foot" -> "ruta a pie"; "walking" -> "paseo"; "running" -> "carrera"; "fitness_trail" -> "circuito deportivo"; else -> r }
    private fun networkLabel(n: String) = when (n) { "iwn" -> "internacional"; "nwn", "ncn" -> "nacional"; "rwn", "rcn" -> "regional"; "lwn", "lcn" -> "local"; else -> n }
    private fun surfaceLabel(s: String) = when (s) { "asphalt", "paved" -> "Asfalto"; "unpaved", "dirt", "earth", "ground" -> "Tierra"
        "gravel", "fine_gravel", "compacted" -> "Grava compactada"; "grass" -> "Hierba"; "sand" -> "Arena"; "paving_stones", "sett" -> "Adoquín"; else -> s }

    /** Une las vías de la relación en un trazado, dando la vuelta a cada tramo si hace falta para que empalme. */
    private fun assemble(members: JsonArray): List<LatLon> {
        val ways = members.mapNotNull { m ->
            val o = m.jsonObject
            if (o.str("type") != "way" || o.str("role") in setOf("platform", "stop", "guidepost")) return@mapNotNull null
            o["geometry"]?.jsonArray?.mapNotNull { p ->
                val g = p as? JsonObject ?: return@mapNotNull null
                val lat = g["lat"]?.jsonPrimitive?.doubleOrNull; val lon = g["lon"]?.jsonPrimitive?.doubleOrNull
                if (lat != null && lon != null) LatLon(lat, lon) else null
            }?.takeIf { it.size >= 2 }
        }
        if (ways.isEmpty()) return emptyList()
        val out = mutableListOf<LatLon>()
        for (w in ways) {
            if (out.isEmpty()) { out += w; continue }
            val tail = out.last()
            val dHead = RunMetrics.haversine(tail.lat, tail.lon, w.first().lat, w.first().lon)
            val dTail = RunMetrics.haversine(tail.lat, tail.lon, w.last().lat, w.last().lon)
            if (out.size == ways.first().size) {
                // Al empalmar el segundo tramo puede que el primero estuviera al revés.
                val h = out.first()
                val dh1 = RunMetrics.haversine(h.lat, h.lon, w.first().lat, w.first().lon)
                val dh2 = RunMetrics.haversine(h.lat, h.lon, w.last().lat, w.last().lon)
                if (minOf(dh1, dh2) < minOf(dHead, dTail)) out.reverse()
            }
            val t = out.last()
            val f = if (RunMetrics.haversine(t.lat, t.lon, w.first().lat, w.first().lon) <= RunMetrics.haversine(t.lat, t.lon, w.last().lat, w.last().lon)) w else w.reversed()
            out += if (out.last() == f.first()) f.drop(1) else f
        }
        return out
    }

    private fun simplify(pts: List<LatLon>, max: Int): List<LatLon> {
        if (pts.size <= max) return pts
        val step = pts.size.toDouble() / max
        return (0 until max).map { pts[(it * step).toInt()] } + pts.last()
    }

    /** Segmentos del contorno (exterior e interior). Basta con ellos para el test par-impar, sin montar anillos. */
    private fun boundarySegments(rel: JsonObject): List<Pair<LatLon, LatLon>> {
        val segs = mutableListOf<Pair<LatLon, LatLon>>()
        rel["members"]?.jsonArray?.forEach { m ->
            val o = m.jsonObject
            if (o.str("type") != "way" || o.str("role") !in setOf("outer", "inner")) return@forEach
            val g = o["geometry"]?.jsonArray?.mapNotNull { p ->
                val q = p as? JsonObject ?: return@mapNotNull null
                val lat = q["lat"]?.jsonPrimitive?.doubleOrNull; val lon = q["lon"]?.jsonPrimitive?.doubleOrNull
                if (lat != null && lon != null) LatLon(lat, lon) else null
            } ?: return@forEach
            g.zipWithNext().forEach { segs += it }
        }
        return segs
    }

    private fun boundaryCenter(segs: List<Pair<LatLon, LatLon>>): LatLon? {
        if (segs.isEmpty()) return null
        return LatLon((segs.minOf { it.first.lat } + segs.maxOf { it.first.lat }) / 2, (segs.minOf { it.first.lon } + segs.maxOf { it.first.lon }) / 2)
    }

    private fun inside(lat: Double, lon: Double, segs: List<Pair<LatLon, LatLon>>): Boolean {
        var c = false
        for ((a, b) in segs) {
            if ((a.lat > lat) != (b.lat > lat)) {
                val x = a.lon + (lat - a.lat) * (b.lon - a.lon) / (b.lat - a.lat)
                if (lon < x) c = !c
            }
        }
        return c
    }

    private fun persistKnown() {
        runCatching {
            val list = known.values.sortedByDescending { it.reviewedAt }.take(400)
            knownFile.writeText(json.encodeToString(ListSerializer(VerifiedRoute.serializer()), list))
        }
    }

    /** Las favoritas se guardan siempre, aunque salgan del conjunto de las 400 más recientes. */
    fun remember(r: VerifiedRoute) { known[r.id] = r; persistKnown() }
}

fun VerifiedRoute.candidate() = RouteCandidate(id, name, distanceM, surface, elevationGainM, start.lat, start.lon,
    track.lastOrNull()?.lat ?: start.lat, track.lastOrNull()?.lon ?: start.lon)
