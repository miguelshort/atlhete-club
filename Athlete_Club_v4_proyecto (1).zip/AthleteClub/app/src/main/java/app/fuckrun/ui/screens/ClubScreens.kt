package app.fuckrun.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.LatLon
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.shared.*
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.Level
import app.fuckrun.domain.Sport
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.TilesOverlay
import java.time.*

private fun whenText(ms: Long): String {
    val dt = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    return "${Fmt.dateLong(dt.toLocalDate())} · ${"%02d:%02d".format(dt.hour, dt.minute)}"
}

private fun phaseColor(p: String) = when (p) { "Cancelada" -> C.Red; "Próxima" -> C.Green; "Completa" -> C.Blue; else -> C.Control }

@Composable
fun ClubScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val state by g.shared.state.collectAsStateWithLifecycle(SharedState.NotConfigured)
    val online by g.shared.online.collectAsStateWithLifecycle(false)
    val sessions by remember { g.shared.mySessions() }.collectAsStateWithLifecycle(emptyList())
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val scope = rememberCoroutineScope()
    var name by remember(settings.sharedDisplayName) { mutableStateOf(settings.sharedDisplayName) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    ScreenScaffold("Club") {
        item { Text("Organiza salidas con otras personas. Sin feed, sin rankings ni chat: solo los datos del encuentro.", style = T.Label, modifier = Modifier.padding(horizontal = 4.dp)) }
        when (val st = state) {
            SharedState.NotConfigured -> item {
                FCard {
                    Text("Servicio compartido no configurado", style = T.Section)
                    Spacer(Modifier.height(6.dp))
                    Text("Esta versión no tiene conectado el servicio de sincronización, así que no puede crear ni recibir sesiones conjuntas. " +
                        "Tus carreras, estadísticas y rutinas funcionan igual, sin cuenta y sin conexión.", style = T.Body.copy(color = C.TextSec))
                }
            }
            SharedState.SignedOut -> {
                item {
                    FCard {
                        Text("Activa tu perfil compartido", style = T.Section)
                        Spacer(Modifier.height(6.dp))
                        Text("Solo se necesita para sesiones conjuntas. Se comparte únicamente el nombre que elijas y tus confirmaciones de asistencia. " +
                            "Nunca tus actividades, rutas, tiempos ni ubicación.", style = T.Body.copy(color = C.TextSec))
                        Spacer(Modifier.height(12.dp))
                        Field(name, "Nombre visible para el organizador", singleLine = true) { name = it.take(40) }
                        Spacer(Modifier.height(12.dp))
                        if (!online) Notice("Sin conexión. Conéctate para activar el perfil.", color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.WifiOff)
                        error?.let { Notice(it, color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.ErrorOutline) }
                        Spacer(Modifier.height(8.dp))
                        PillButton(if (busy) "Activando…" else "Activar", color = C.Green, enabled = online && name.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth()) {
                            busy = true; error = null
                            scope.launch {
                                runCatching { g.shared.signIn(); g.profile.update { it.copy(sharedDisplayName = name.trim()) } }
                                    .onFailure { error = it.message }
                                busy = false
                            }
                        }
                    }
                }
            }
            is SharedState.Ready -> {
                if (!online) item { Notice("Sin conexión. Puedes consultar lo último recibido, pero no se enviará nada hasta reconectar.", color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.WifiOff) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PillButton("Crear salida", color = C.Text, textColor = C.Bg, icon = Icons.Rounded.Add, modifier = Modifier.weight(1f), enabled = online) { nav.navigate(Routes.CLUB_CREATE) }
                        PillButton("Unirme con código", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f), enabled = online) { nav.navigate(Routes.clubJoin()) }
                    }
                }
                if (sessions.isEmpty()) item { Text("Todavía no has creado ni aceptado ninguna sesión.", style = T.Label, modifier = Modifier.padding(4.dp)) }
                listOf("Próxima", "Completa", "Finalizada", "Cancelada").forEach { phase ->
                    val list = sessions.filter { it.phase() == phase }
                    if (list.isNotEmpty()) {
                        item { SectionTitle(when (phase) { "Próxima" -> "Próximas"; "Completa" -> "Completas"; "Finalizada" -> "Finalizadas"; else -> "Canceladas" }) }
                        list.forEach { s -> item(key = s.id) { SessionCard(s, st.uid) { nav.navigate(Routes.clubSession(s.id)) } } }
                    }
                }
            }
        }
    }
}

@Composable
private fun SessionCard(s: SharedSession, uid: String, onClick: () -> Unit) {
    FCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) { SportBadge(Sport.of(s.sport), 32.dp); Spacer(Modifier.width(8.dp))
            Tag(s.phase(), phaseColor(s.phase()), if (s.phase() == "Finalizada") C.Text else C.OnColor)
            if (s.organizerUid == uid) { Spacer(Modifier.width(6.dp)); Tag("Organizas") } }
        Spacer(Modifier.height(8.dp))
        Text(s.name, style = T.Section)
        Text(whenText(s.startAt), style = T.Label)
        Text(listOfNotNull(s.meetingLabel.ifBlank { null }, s.city.ifBlank { null }).joinToString(" · "), style = T.Body.copy(color = C.TextSec))
        Text("${s.attendeeCount}${s.maxAttendees?.let { " / $it" } ?: ""} asistentes confirmados", style = T.Label)
    }
}

@Composable
fun ClubSessionScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val s by remember(id) { g.shared.session(id) }.collectAsStateWithLifecycle(null)
    val going by remember(id) { g.shared.myAttendance(id) }.collectAsStateWithLifecycle(false)
    val online by g.shared.online.collectAsStateWithLifecycle(false)
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val session = s ?: run { ScreenScaffold("Sesión") { item { Text(if (online) "Cargando…" else "Sin conexión.", style = T.Label) } }; return }
    val isOrganizer = session.organizerUid == g.shared.currentUid()
    val attendees by remember(isOrganizer, id) { if (isOrganizer) g.shared.attendees(id) else kotlinx.coroutines.flow.flowOf(emptyList()) }.collectAsStateWithLifecycle(emptyList())

    fun act(block: suspend () -> Unit) { busy = true; error = null; scope.launch { runCatching { block() }.onFailure { error = it.message }; busy = false } }
    val profileSettings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val hints = profileSettings.hintsSeen

    ScreenScaffold("Sesión") {
        item {
            Row { Tag(session.phase(), phaseColor(session.phase()), if (session.phase() == "Finalizada") C.Text else C.OnColor); Spacer(Modifier.width(6.dp)); Tag("Solo con invitación") }
            Spacer(Modifier.height(8.dp))
            Text(session.name, style = T.ScreenTitle)
            Text(whenText(session.startAt), style = T.Body.copy(color = C.TextSec))
        }
        if (session.lastChangeNote.isNotBlank()) item { Notice("Aviso del organizador: ${session.lastChangeNote}", icon = Icons.Rounded.Campaign) }
        if (!online) item { Notice("Sin conexión: los cambios no se enviarán hasta reconectar.", color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.WifiOff) }
        error?.let { e -> item { Notice(e, color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.ErrorOutline) } }
        item { RunMap(emptyList(), Modifier.fillMaxWidth().height(200.dp), markers = listOf(MapMarker(LatLon(session.meetingLat, session.meetingLon), "Punto de encuentro"))) }
        item {
            FCard {
                Detail("Deporte", Sport.of(session.sport).label)
                Detail("Punto de encuentro", session.meetingLabel.ifBlank { "Marcado en el mapa" })
                Detail("Organiza", listOf(session.organizerName, session.club).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "—" })
                Detail("Ciudad", listOf(session.city, session.province).filter { it.isNotBlank() }.joinToString(", "))
                Detail("Previsto", listOfNotNull(session.plannedKm?.let { "${Fmt.km(it * 1000, 1)} km" }, session.plannedMinutes?.let { "$it min" }).joinToString(" · ").ifBlank { "Sin indicar" })
                if (session.paceHint.isNotBlank()) Detail("Ritmo orientativo", session.paceHint)
                if (session.level.isNotBlank()) Detail("Nivel recomendado", session.level)
                session.routeId?.let { rid -> g.routes.byId(rid)?.let { Detail("Ruta", it.name) } }
                Detail("Plazas", session.maxAttendees?.let { "${session.attendeeCount} de $it" } ?: "${session.attendeeCount} confirmados, sin límite")
                if (session.instructions.isNotBlank()) Detail("Instrucciones", session.instructions)
            }
        }
        if (isOrganizer) {
            item { SectionTitle("Invitación") }
            if ("invite" !in hints) item { Hint("Comparte el enlace o dicta el código. Quien lo reciba solo verá los datos de este encuentro, nunca tu historial.") {
                scope.launch { g.profile.update { it.copy(hintsSeen = it.hintsSeen + "invite") } } } }
            item {
                FCard {
                    Text("Código", style = T.Label)
                    Text(session.inviteCode, style = T.HomeFigure)
                    Spacer(Modifier.height(10.dp))
                    PillButton("Compartir invitación", color = C.Text, icon = Icons.Rounded.Share) {
                        // Enlace nuevo athleteclub://; los enlaces fuckrun:// antiguos siguen funcionando (manifiesto).
                        val text = "Te invito a «${session.name}» (${Sport.of(session.sport).label}, ${whenText(session.startAt)}) en Athlete Club. " +
                            "Código: ${session.inviteCode} · athleteclub://join/${session.inviteCode}"
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartir"))
                    }
                }
            }
            item { SectionTitle("Asistentes") }
            item {
                FCard {
                    if (attendees.isEmpty()) Text("Nadie ha confirmado todavía.", style = T.Label)
                    attendees.sortedByDescending { it.going }.forEach { a ->
                        ListRow(a.name.ifBlank { "Sin nombre" }, if (a.going) "Confirmado" else "Ha cancelado", leading = if (a.going) Icons.Rounded.CheckCircle else Icons.Rounded.Cancel,
                            leadingTint = if (a.going) C.Green else C.TextSec)
                    }
                    Text("Solo ves asistentes y confirmaciones. No tienes acceso a su historial ni a sus datos deportivos.", style = T.Label)
                }
            }
            if (session.status == SessionStatus.SCHEDULED) item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Editar", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Edit, modifier = Modifier.weight(1f), enabled = online) { nav.navigate(Routes.clubEdit(id)) }
                    PillButton("Cancelar sesión", color = C.Control, textColor = C.Red, modifier = Modifier.weight(1f), enabled = online && !busy) {
                        sheet.show {
                            var note by remember { mutableStateOf("") }
                            Text("Cancelar la sesión", style = T.Section)
                            Spacer(Modifier.height(8.dp))
                            Field(note, "Motivo para los asistentes (opcional)") { note = it }
                            Spacer(Modifier.height(12.dp))
                            PillButton("Cancelar sesión", color = C.Red, modifier = Modifier.fillMaxWidth()) { sheet.hide(); act { g.shared.cancel(session, note) } }
                        }
                    }
                }
            }
        } else if (session.status == SessionStatus.SCHEDULED && session.phase() != "Finalizada") item {
            if (going) PillButton("Ya no voy", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth(), enabled = online && !busy) { act { g.shared.leave(id) } }
            else PillButton(if (session.isFull) "Sesión completa" else "Confirmar asistencia", color = C.Green, modifier = Modifier.fillMaxWidth(),
                enabled = online && !busy && !session.isFull) { act { g.shared.join(id, settings.sharedDisplayName) } }
        }
        if (session.status == SessionStatus.SCHEDULED) item {
            PillButton("Empezar mi registro", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {
                nav.navigate(Routes.prerun(RunKind.SHARED, shared = session.id, sharedName = session.name))
            }
            Text("Cada participante registra su propia actividad, que queda en su historial privado. No se comparte ubicación en directo, tiempos ni recorrido.", style = T.Label, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun ClubJoinScreen(nav: NavController, code0: String) {
    val g = FuckrunApp.graph
    val scope = rememberCoroutineScope()
    val state by g.shared.state.collectAsStateWithLifecycle(SharedState.NotConfigured)
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    var code by remember { mutableStateOf(code0.uppercase()) }
    var found by remember { mutableStateOf<SharedSession?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    ScreenScaffold("Unirme con código") {
        if (state !is SharedState.Ready) item { Notice("Primero activa tu perfil compartido en Club.", icon = Icons.Rounded.Info) }
        item { Field(code, "Código de 6 caracteres", singleLine = true) { code = it.uppercase().filter(Char::isLetterOrDigit).take(6) } }
        error?.let { e -> item { Notice(e, color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.ErrorOutline) } }
        item {
            PillButton(if (busy) "Buscando…" else "Buscar", color = C.Text, modifier = Modifier.fillMaxWidth(), enabled = code.length == 6 && !busy && state is SharedState.Ready) {
                busy = true; error = null; found = null
                scope.launch { runCatching { found = g.shared.findByCode(code) }.onFailure { error = it.message }; busy = false }
            }
        }
        found?.let { s ->
            item { SessionCard(s, "") {} }
            item {
                PillButton(if (s.isFull) "Sesión completa" else "Confirmar asistencia", color = C.Green, modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && !s.isFull && s.status == SessionStatus.SCHEDULED) {
                    busy = true; error = null
                    scope.launch {
                        runCatching { g.shared.join(s.id, settings.sharedDisplayName) }
                            .onSuccess { nav.navigate(Routes.clubSession(s.id)) { popUpTo(Routes.CLUB) } }
                            .onFailure { error = it.message }
                        busy = false
                    }
                }
            }
        }
    }
}

@Composable
fun ClubEditScreen(nav: NavController, id: String?) {
    val g = FuckrunApp.graph
    val scope = rememberCoroutineScope()
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val online by g.shared.online.collectAsStateWithLifecycle(false)
    val existing by produceState<SharedSession?>(null, id) { if (id != null) value = g.shared.session(id).first() }
    if (id != null && existing == null) { ScreenScaffold("Editar salida") { item { Text("Cargando…", style = T.Label) } }; return }
    val e = existing
    val a = settings.answers

    var name by remember(e) { mutableStateOf(e?.name ?: "") }
    var club by remember(e) { mutableStateOf(e?.club ?: "") }
    var city by remember(e, a.municipality) { mutableStateOf(e?.city ?: a.municipality ?: "") }
    var province by remember(e, a.province) { mutableStateOf(e?.province ?: a.province ?: "") }
    var point by remember(e) { mutableStateOf(e?.let { LatLon(it.meetingLat, it.meetingLon) }) }
    var label by remember(e) { mutableStateOf(e?.meetingLabel ?: "") }
    val start0 = e?.startAt?.let { Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDateTime() } ?: LocalDate.now().plusDays(1).atTime(19, 0)
    var day by remember(e) { mutableStateOf(start0.toLocalDate()) }
    var time by remember(e) { mutableStateOf(start0.toLocalTime()) }
    var km by remember(e) { mutableStateOf(e?.plannedKm?.toString() ?: "") }
    var minutes by remember(e) { mutableStateOf(e?.plannedMinutes?.toString() ?: "") }
    var pace by remember(e) { mutableStateOf(e?.paceHint ?: "") }
    var level by remember(e) { mutableStateOf(e?.level ?: "Todos los niveles") }
    var routeId by remember(e) { mutableStateOf(e?.routeId) }
    var max by remember(e) { mutableStateOf(e?.maxAttendees?.toString() ?: "") }
    var instructions by remember(e) { mutableStateOf(e?.instructions ?: "") }
    var sport by remember(e) { mutableStateOf(Sport.of(e?.sport ?: settings.lastFreeSport.name)) }
    val favIds by remember { g.db.favorites().all() }.collectAsStateWithLifecycle(emptyList())
    var changeNote by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val valid = name.isNotBlank() && point != null && city.isNotBlank() && (id == null || changeNote.isNotBlank())

    ScreenScaffold(if (id == null) "Crear salida" else "Editar salida") {
        item { Notice("Crear una salida significa organizar un encuentro deportivo. No tramita permisos municipales, seguros ni autorizaciones para una competición oficial.") }
        item { L("Deporte"); SportSelector(sport) { sport = it } }
        item { L("Nombre"); Field(name, "Salida del jueves", singleLine = true) { name = it.take(60) } }
        item { L("Organizador o run club"); Field(club, "Opcional", singleLine = true) { club = it.take(60) } }
        item { L("Ciudad"); Field(city, "Municipio", singleLine = true) { city = it.take(60) }; if (province.isNotBlank()) Text(province, style = T.Label) }
        item {
            L("Punto de encuentro (toca el mapa)")
            MeetingPointPicker(point, Modifier.fillMaxWidth().height(240.dp)) { point = it }
            Spacer(Modifier.height(8.dp))
            Field(label, "Descripción del punto (p. ej., puerta norte del parque)", singleLine = true) { label = it.take(80) }
        }
        item {
            L("Fecha")
            ChoiceChips((0..30).map { LocalDate.now().plusDays(it.toLong()) }.take(15), { "${Fmt.dayShort(it.dayOfWeek)} ${it.dayOfMonth}/${it.monthValue}" }, { it == day }) { day = it }
            Spacer(Modifier.height(8.dp)); L("Hora")
            ChoiceChips((12..44).map { LocalTime.of(it / 2, (it % 2) * 30) }, { "%02d:%02d".format(it.hour, it.minute) }, { it == time }) { time = it }
        }
        item {
            L("Distancia (km) o duración (min) previstas")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Field(km, "km", singleLine = true) { km = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(5) } }
                Box(Modifier.weight(1f)) { Field(minutes, "min", singleLine = true) { minutes = it.filter(Char::isDigit).take(3) } }
            }
        }
        item { L("Ritmo orientativo (opcional)"); Field(pace, "p. ej., conversacional, 6:00–6:30 min/km", singleLine = true) { pace = it.take(60) } }
        item { L("Nivel recomendado"); ChoiceChips(listOf("Todos los niveles") + Level.entries.map { it.label }, { it }, { it == level }) { level = it } }
        val favRoutes = (favIds.mapNotNull { g.routes.byId(it.routeId) } + listOfNotNull(g.routes.byId(routeId))).distinctBy { it.id }.filter { sport in routeSports(it) }
        if (favRoutes.isNotEmpty()) item {
            L("Ruta (opcional)")
            ChoiceChips(listOf<String?>(null) + favRoutes.map { it.id }, { rid -> rid?.let { g.routes.byId(it)?.name } ?: "Ninguna" }, { it == routeId }) { routeId = it }
        }
        item { L("Máximo de asistentes (opcional)"); Field(max, "Sin límite", singleLine = true) { max = it.filter(Char::isDigit).take(3) } }
        item { L("Instrucciones prácticas"); Field(instructions, "Qué llevar, dónde dejar cosas, a quién buscar…") { instructions = it.take(500) } }
        item { L("Visibilidad"); Text("Solo con invitación (enlace o código).", style = T.Body) }
        if (id != null) item { L("Qué ha cambiado (se avisará a los asistentes)"); Field(changeNote, "p. ej., cambiamos la hora a las 19:30", singleLine = true) { changeNote = it.take(120) } }
        if (!online) item { Notice("Sin conexión: no se puede enviar. No se ha creado ni modificado nada.", color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.WifiOff) }
        error?.let { er -> item { Notice(er, color = C.Red.copy(alpha = 0.2f), icon = Icons.Rounded.ErrorOutline) } }
        item {
            PillButton(if (busy) "Enviando…" else if (id == null) "Crear y generar invitación" else "Guardar cambios", color = C.Green,
                modifier = Modifier.fillMaxWidth(), enabled = valid && online && !busy) {
                busy = true; error = null
                val p = point!!
                val s = (e ?: SharedSession()).copy(
                    name = name.trim(), club = club.trim(), city = city.trim(), province = province, meetingLat = p.lat, meetingLon = p.lon,
                    meetingLabel = label.trim(), startAt = day.atTime(time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
                    plannedKm = km.replace(',', '.').toDoubleOrNull(), plannedMinutes = minutes.toIntOrNull(), paceHint = pace.trim(),
                    level = level, routeId = routeId, maxAttendees = max.toIntOrNull()?.takeIf { it > 0 }, instructions = instructions.trim(),
                    organizerName = settings.sharedDisplayName, sport = sport.name,
                )
                scope.launch {
                    runCatching {
                        if (id == null) { val created = g.shared.create(s); nav.navigate(Routes.clubSession(created.id)) { popUpTo(Routes.CLUB) } }
                        else { g.shared.update(s, changeNote.trim()); nav.popBackStack() }
                    }.onFailure { error = it.message }
                    busy = false
                }
            }
        }
    }
}

@Composable private fun L(t: String) = Text(t, style = T.BodyStrong, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))

/** Selector de punto de encuentro: un toque en el mapa coloca el marcador. */
@Composable
private fun MeetingPointPicker(point: LatLon?, modifier: Modifier, onPick: (LatLon) -> Unit) {
    val start = point ?: LatLon(40.4168, -3.7038)
    val dark = C.isDark
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(C.Surface)) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
            MapView(ctx).apply {
                setTileSource(appTileSource())
                setMultiTouchControls(true)
                zoomController.setVisibility(org.osmdroid.views.CustomZoomButtonsController.Visibility.NEVER)
                if (dark) overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)
                controller.setZoom(if (point == null) 6.0 else 16.0)
                controller.setCenter(GeoPoint(start.lat, start.lon))
            }
        }, update = { map ->
            map.overlayManager.tilesOverlay.setColorFilter(if (dark) TilesOverlay.INVERT_COLORS else null)
            map.overlays.clear()
            map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean { onPick(LatLon(p.latitude, p.longitude)); return true }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            point?.let { map.overlays.add(Marker(map).apply { position = GeoPoint(it.lat, it.lon); title = "Punto de encuentro" }) }
            map.invalidate()
        })
        Text(app.fuckrun.BuildConfig.MAP_ATTRIBUTION, style = T.Label, modifier = Modifier.align(androidx.compose.ui.Alignment.BottomEnd).padding(8.dp))
    }
}
