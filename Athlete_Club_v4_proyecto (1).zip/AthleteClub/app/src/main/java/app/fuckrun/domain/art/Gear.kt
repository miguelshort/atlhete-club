package app.fuckrun.domain.art

import app.fuckrun.domain.Sport
import kotlinx.serialization.Serializable

/** Huecos de equipación. Una pieza por hueco; FULL (conjunto) ocupa camiseta y parte de abajo. */
enum class Slot(val label: String, val group: Group) {
    TOP("Camiseta", Group.CLOTHES), OUTER("Capa exterior", Group.CLOTHES), FULL("Conjunto", Group.CLOTHES), BOTTOM("Parte de abajo", Group.CLOTHES),
    SOCKS("Calcetines", Group.CLOTHES), SHOES("Zapatillas", Group.CLOTHES), LACES("Cordones", Group.CLOTHES), LEGWEAR("Piernas", Group.CLOTHES),
    HEAD("Cabeza", Group.ACC), EYES("Gafas deportivas", Group.ACC), NECK("Cuello", Group.ACC), CHEST("Pecho", Group.ACC), WRIST("Muñeca", Group.ACC),
    ARM("Brazo", Group.ACC), HANDS("Manos", Group.ACC), WAIST("Cintura", Group.ACC), HIP("Cadera", Group.ACC), BACK("Espalda", Group.ACC),
    SHOULDER("Bandolera", Group.ACC), CARRY("En la mano", Group.ACC),
    BIKE_FRAME("Cuadro", Group.BIKE), BIKE_CAGE("Bidón del tubo diagonal", Group.BIKE), BIKE_CAGE_SEAT("Portabidón del tubo de sillín", Group.BIKE),
    BIKE_SADDLEBAG("Bolsa de sillín", Group.BIKE), BIKE_FRAMEBAG("Bolsa de cuadro", Group.BIKE), BIKE_BARBAG("Bolsa de manillar", Group.BIKE),
    BIKE_TAPE("Cinta de manillar", Group.BIKE), BIKE_REAR("Alforjas", Group.BIKE);

    enum class Group { CLOTHES, ACC, BIKE }
}

sealed interface GearPrice {
    data object Free : GearPrice
    data class Points(val amount: Int) : GearPrice
    data class Achievement(val achievementId: String) : GearPrice
}

/** Familia de dibujo. Las piezas de una familia se distinguen por corte, construcción o función ([D] y parámetros). */
enum class K { TOP, OUTER, VEST, CAPE, FULL, BOTTOM, SHOE, SOCK, LACE, GAITER, LEGWARMER, CAP, VISOR, HEADBAND, HAT, BEANIE, HELMET,
    SPORT_GLASSES, SCARF, LANYARD, BIB, BADGE, POCKET_SQUARE, WRISTBAND, WATCH, BRACELET, ARMBAND, ARMSLEEVE, GLOVE, BELT_GELS, LUMBAR,
    WAISTBAG, TIED_SWEATER, MAPBAG, CANTEEN, KEYCHAIN, PACK, FRAMEPACK, MAT, ROLLTOP, CROSSBODY, STICK, POLES,
    FRAME, BOTTLE, CAGE_DOUBLE, SADDLEBAG, FRAMEBAG, BARBAG, BARTAPE, PANNIERS }

/** Detalles de construcción. */
enum class D { CREW, RAGLAN, SINGLET, BIB_SEWN, THUMB, FLAT_SEAMS, HALF_ZIP, FULL_ZIP, HIGH_NECK, HOOD, HOOD_DETACH, SHIRT_COLLAR, CORD_COLLAR,
    BACK_POCKETS, RIBBED_SHOULDERS, PATCH_POCKET, TWO_POCKETS, KANGAROO, CURVED_PANELS, DIAG_BAND, QUILTED, PLAID, REAR_TAIL, OPEN_BACK,
    ROLLED, BACK_VENT, MAP_YOKE, FLEECE, MULTI_POCKETS, BIB_POCKET, HERRINGBONE, REFLECT, STRIPE, SPLIT, SIDE_POCKET, ZIP_OFF, BIB_STRAPS,
    SIDE_PANEL, PLEATS, TIGHT, SPIKES, WAVY_SOLE, HOOKS, STRAPS_TWO, ROCKER, TOE_CAP, LUGS, FOLD, WIDE_CUFF, TAB, WOOL, BICOLOR, LEAF,
    FIVE_PANEL, SIX_PANEL, CANVAS, SHORT_PEAK, OPEN_CROWN, CROSS_BAND, KNOT, WIDE_BRIM, CORD, BUCKET, EARFLAPS, CHANNELS, COMPACT_VISOR, BASIC,
    WINGS, CONTOURS, FOOTPRINT, TERRY, RECT, BRAIDED, PHONE, RIBBED, FINGERLESS, PALM, MESH, TOP_LID, LOW_STAYS, RACK, TRANSLUCENT, BUCKLE, FLAP, BINOCULARS }

data class Gear(
    val id: String, val name: String, val slot: Slot, val sport: Sport?, val price: GearPrice, val kind: K,
    val d: Set<D> = emptySet(),
    /** Parámetros de forma (largo de manga, largo de pierna, altura de caña…), según la familia. */
    val a: Float = 0f, val b: Float = 0f,
)

@Serializable data class Tint(val main: Int, val accent: Int)

/**
 * Conjunto equipado: hueco → pieza, y colores elegidos por pieza. Las pruebas del probador no se guardan hasta «Equipar».
 * Los campos antiguos (v3) se conservan solo para leer perfiles anteriores y traducirlos.
 */
@Serializable
data class Outfit(
    val items: Map<String, String> = emptyMap(),
    val tints: Map<String, Tint> = emptyMap(),
    val v: Int = 0,
    val top: String? = null, val bottom: String? = null, val longLegs: Boolean? = null, val shoes: String? = null,
    val accessories: Map<String, String>? = null, val topColor: Int? = null, val bottomColor: Int? = null,
) {
    fun migrated(): Outfit {
        if (v >= 2) return this
        val m = mutableMapOf<String, String>()
        m[Slot.TOP.name] = if (top == "top_bicolor") "tee_raglan" else "tee_crew"
        val long = longLegs == true
        m[Slot.BOTTOM.name] = when (bottom) { "bottom_stripe" -> if (long) "stripe_long" else "stripe_short"; else -> if (long) "straight_long" else "straight_short" }
        m[Slot.SHOES.name] = if (shoes == "shoes_relief") "shoe_trail" else "shoe_flat"
        accessories.orEmpty().values.forEach { id -> GearCatalog.byId(GearCatalog.translate(id))?.let { g -> m[g.slot.name] = g.id } }
        val t = mutableMapOf<String, Tint>()
        topColor?.let { t[m[Slot.TOP.name]!!] = Tint(it.coerceIn(0, GearCatalog.colors.lastIndex), 7) }
        bottomColor?.let { t[m[Slot.BOTTOM.name]!!] = Tint(it.coerceIn(0, GearCatalog.colors.lastIndex), 0) }
        return Outfit(m, t, v = 2)
    }

    fun gear(slot: Slot): Gear? = items[slot.name]?.let { GearCatalog.byId(it) }
    fun isWearing(id: String) = id in items.values
    fun tintOf(g: Gear) = tints[g.id] ?: GearCatalog.defaultTint(g)

    /** Equipa una pieza en su hueco. Un conjunto completo sustituye camiseta y parte de abajo, y al revés. */
    fun with(g: Gear): Outfit {
        val m = items.toMutableMap()
        when (g.slot) {
            Slot.FULL -> { m.remove(Slot.TOP.name); m.remove(Slot.BOTTOM.name) }
            Slot.TOP, Slot.BOTTOM -> {
                if (m.containsKey(Slot.FULL.name)) {
                    m.remove(Slot.FULL.name)
                    if (g.slot == Slot.TOP) m[Slot.BOTTOM.name] = "straight_long" else m[Slot.TOP.name] = "tee_crew"
                }
            }
            else -> Unit
        }
        m[g.slot.name] = g.id
        return copy(items = m)
    }

    /** Quitar: las prendas básicas vuelven a la inicial (el avatar nunca queda sin ropa); los accesorios se retiran. */
    fun without(slot: Slot): Outfit {
        val m = items.toMutableMap()
        when (slot) {
            Slot.TOP -> m[slot.name] = "tee_crew"
            Slot.BOTTOM -> m[slot.name] = "straight_short"
            Slot.SHOES -> m[slot.name] = "shoe_flat"
            Slot.FULL -> { m.remove(slot.name); m[Slot.TOP.name] = "tee_crew"; m[Slot.BOTTOM.name] = "straight_long" }
            else -> m.remove(slot.name)
        }
        return copy(items = m)
    }

    fun withTint(g: Gear, t: Tint) = copy(tints = tints + (g.id to t))

    companion object {
        val DEFAULT = Outfit(mapOf(Slot.TOP.name to "tee_crew", Slot.BOTTOM.name to "straight_short", Slot.SHOES.name to "shoe_flat"), v = 2)
    }
}

object GearCatalog {
    /** Colores de prenda con nombre accesible. */
    val colors = listOf(
        Swatch("Blanco roto", Col.rgb(0xEEEBE4)), Swatch("Grafito", Col.rgb(0x3E434C)), Swatch("Negro", Col.rgb(0x1C1E22)),
        Swatch("Marino", Col.rgb(0x26344F)), Swatch("Azul", Col.rgb(0x3F78D8)), Swatch("Celeste", Col.rgb(0x8FC2E8)),
        Swatch("Coral", Col.rgb(0xF07858)), Swatch("Rojo", Col.rgb(0xC9403E)), Swatch("Mostaza", Col.rgb(0xC9A03A)),
        Swatch("Ámbar", Col.rgb(0xF0B440)), Swatch("Verde bosque", Col.rgb(0x2F7D57)), Swatch("Salvia", Col.rgb(0x9DB39A)),
        Swatch("Lavanda", Col.rgb(0xA79BD3)), Swatch("Arena", Col.rgb(0xCDB892)), Swatch("Caqui", Col.rgb(0x7D7A52)), Swatch("Teja", Col.rgb(0xA4553A)),
    )

    private fun free(id: String, name: String, slot: Slot, kind: K, d: Set<D>, a: Float = 0f, b: Float = 0f) = Gear(id, name, slot, null, GearPrice.Free, kind, d, a, b)
    private fun shop(id: String, name: String, slot: Slot, sport: Sport, pts: Int, kind: K, d: Set<D> = emptySet(), a: Float = 0f, b: Float = 0f) =
        Gear(id, name, slot, sport, GearPrice.Points(pts), kind, d, a, b)
    private fun ach(id: String, name: String, slot: Slot, kind: K, d: Set<D> = emptySet(), a: Float = 0f, b: Float = 0f) =
        Gear(id, name, slot, sportOf(id), GearPrice.Achievement(id), kind, d, a, b)
    private fun sportOf(id: String) = when (id.take(3)) { "COR" -> Sport.RUN; "SEN" -> Sport.HIKE; "BIC" -> Sport.BIKE; else -> Sport.WALK }

    /** Vestuario inicial gratuito. a = largo de manga (0–1) o de pierna (0–1); b = holgura. */
    val free = listOf(
        free("tee_crew", "Camiseta lisa de cuello redondo", Slot.TOP, K.TOP, setOf(D.CREW), a = 0.42f),
        free("tee_raglan", "Camiseta bicolor de manga raglán", Slot.TOP, K.TOP, setOf(D.CREW, D.RAGLAN), a = 0.45f),
        free("straight_short", "Calzonas rectas", Slot.BOTTOM, K.BOTTOM, emptySet(), a = 0.36f),
        free("straight_long", "Pantalón largo recto", Slot.BOTTOM, K.BOTTOM, emptySet(), a = 1f),
        free("stripe_short", "Calzonas con banda lateral", Slot.BOTTOM, K.BOTTOM, setOf(D.STRIPE), a = 0.36f),
        free("stripe_long", "Pantalón largo con banda lateral", Slot.BOTTOM, K.BOTTOM, setOf(D.STRIPE), a = 1f),
        free("shoe_flat", "Zapatillas ligeras de suela plana", Slot.SHOES, K.SHOE, emptySet(), a = 3.5f, b = 7f),
        free("shoe_trail", "Zapatillas de suela con tacos", Slot.SHOES, K.SHOE, setOf(D.LUGS), a = 6f, b = 10f),
    )

    /** Tienda: artículos básicos que se compran con puntos. */
    val shop = listOf(
        shop("visor_run", "Visera de running", Slot.HEAD, Sport.RUN, 30, K.VISOR, setOf(D.BASIC)),
        shop("beanie_run", "Gorro térmico", Slot.HEAD, Sport.RUN, 45, K.BEANIE, setOf(D.BASIC)),
        shop("scarf_hike", "Pañuelo de montaña", Slot.NECK, Sport.HIKE, 25, K.SCARF, setOf(D.BASIC)),
        shop("backpack_hike", "Mochila sencilla de senderismo", Slot.BACK, Sport.HIKE, 60, K.PACK, setOf(D.BASIC)),
        shop("gloves_bike", "Guantes de ciclismo", Slot.HANDS, Sport.BIKE, 40, K.GLOVE, setOf(D.BASIC)),
        shop("helmet_bike", "Casco de paseo", Slot.HEAD, Sport.BIKE, 50, K.HELMET, setOf(D.BASIC)),
        shop("cap_walk", "Gorra de paseo", Slot.HEAD, Sport.WALK, 30, K.CAP, setOf(D.BASIC, D.SIX_PANEL)),
        shop("sling_walk", "Bandolera", Slot.SHOULDER, Sport.WALK, 35, K.CROSSBODY, setOf(D.BASIC)),
    )

    /** Las 96 recompensas de logro (identificador = el del logro). */
    val achievements = listOf(
        // Correr
        ach("COR-01", "Cordones bicolores de pista", Slot.LACES, K.LACE, setOf(D.BICOLOR)),
        ach("COR-02", "Calcetines de talón alto", Slot.SOCKS, K.SOCK, setOf(D.TAB), a = 16f),
        ach("COR-03", "Calzonas de competición con abertura lateral", Slot.BOTTOM, K.BOTTOM, setOf(D.SPLIT), a = 0.28f),
        ach("COR-04", "Camiseta de tirantes con dorsal cosido", Slot.TOP, K.TOP, setOf(D.SINGLET, D.BIB_SEWN), a = 0f),
        ach("COR-05", "Muñequera de rizo", Slot.WRIST, K.WRISTBAND, setOf(D.TERRY)),
        ach("COR-06", "Gorra flexible de cinco paneles", Slot.HEAD, K.CAP, setOf(D.FIVE_PANEL)),
        ach("COR-07", "Camiseta de manga larga con abertura para el pulgar", Slot.TOP, K.TOP, setOf(D.CREW, D.THUMB), a = 1f),
        ach("COR-08", "Cortavientos plegable de media cremallera", Slot.OUTER, K.OUTER, setOf(D.HALF_ZIP, D.HIGH_NECK), a = 1f, b = 2.5f),
        ach("COR-09", "Portadorsal con dos broches", Slot.CHEST, K.BIB, setOf(D.BUCKLE)),
        ach("COR-10", "Zapatillas de pista con placa de talón", Slot.SHOES, K.SHOE, setOf(D.SPIKES), a = 2.5f, b = 6f),
        ach("COR-11", "Chaleco ligero con bolsillo para dorsal", Slot.OUTER, K.VEST, setOf(D.FULL_ZIP, D.BIB_POCKET), b = 1.5f),
        ach("COR-12", "Brazalete para el móvil", Slot.ARM, K.ARMBAND, setOf(D.PHONE)),
        ach("COR-13", "Mallas cortas con bolsillo lateral", Slot.BOTTOM, K.BOTTOM, setOf(D.TIGHT, D.SIDE_POCKET), a = 0.5f),
        ach("COR-14", "Reloj de esfera rectangular", Slot.WRIST, K.WATCH, setOf(D.RECT)),
        ach("COR-15", "Manguitos de punto estriado", Slot.ARM, K.ARMSLEEVE, setOf(D.RIBBED)),
        ach("COR-16", "Sudadera de calentamiento con cuello alto", Slot.OUTER, K.OUTER, setOf(D.HIGH_NECK, D.KANGAROO), a = 1f, b = 3f),
        ach("COR-17", "Cinturón para geles con tres trabillas", Slot.WAIST, K.BELT_GELS),
        ach("COR-18", "Chaqueta de pista con paneles curvos", Slot.OUTER, K.OUTER, setOf(D.FULL_ZIP, D.CURVED_PANELS, D.HIGH_NECK), a = 1f, b = 2f),
        ach("COR-19", "Parche alado para el pecho", Slot.CHEST, K.BADGE, setOf(D.WINGS)),
        ach("COR-20", "Zapatillas de fondo con mediasuela ondulada", Slot.SHOES, K.SHOE, setOf(D.WAVY_SOLE), a = 7.5f, b = 8f),
        ach("COR-21", "Visera de copa abierta y banda cruzada", Slot.HEAD, K.VISOR, setOf(D.OPEN_CROWN, D.CROSS_BAND)),
        ach("COR-22", "Camiseta de resistencia con costuras planas", Slot.TOP, K.TOP, setOf(D.CREW, D.FLAT_SEAMS), a = 0.35f),
        ach("COR-23", "Cinta de running con nudo lateral", Slot.HEAD, K.HEADBAND, setOf(D.KNOT)),
        ach("COR-24", "Conjunto de pista con banda diagonal", Slot.FULL, K.FULL, setOf(D.DIAG_BAND, D.FULL_ZIP), a = 1f),
        // Sendero
        ach("SEN-01", "Pañuelo triangular de cuello", Slot.NECK, K.SCARF),
        ach("SEN-02", "Calcetines de lana con vuelta", Slot.SOCKS, K.SOCK, setOf(D.WOOL, D.FOLD), a = 22f),
        ach("SEN-03", "Sobrecamisa de montaña con dos bolsillos", Slot.OUTER, K.OUTER, setOf(D.SHIRT_COLLAR, D.TWO_POCKETS, D.FULL_ZIP), a = 1f, b = 3f),
        ach("SEN-04", "Mochila de travesía con tapa superior", Slot.BACK, K.PACK, setOf(D.TOP_LID)),
        ach("SEN-05", "Bolsa lateral para el mapa", Slot.HIP, K.MAPBAG),
        ach("SEN-06", "Sombrero de ala flexible con cordón", Slot.HEAD, K.HAT, setOf(D.WIDE_BRIM, D.CORD)),
        ach("SEN-07", "Pantalón desmontable con cremalleras", Slot.BOTTOM, K.BOTTOM, setOf(D.ZIP_OFF, D.SIDE_POCKET), a = 1f, b = 2.5f),
        ach("SEN-08", "Anorak de montaña con bolsillo canguro", Slot.OUTER, K.OUTER, setOf(D.HOOD, D.KANGAROO, D.HALF_ZIP), a = 1f, b = 4f),
        ach("SEN-09", "Polainas cortas con cierre frontal", Slot.LEGWEAR, K.GAITER),
        ach("SEN-10", "Botas de media caña con lazada de ganchos", Slot.SHOES, K.SHOE, setOf(D.HOOKS, D.LUGS), a = 7f, b = 24f),
        ach("SEN-11", "Bastón de madera con empuñadura de corcho", Slot.CARRY, K.STICK),
        ach("SEN-12", "Brújula colgada de cinta", Slot.NECK, K.LANYARD),
        ach("SEN-13", "Forro polar de pelo corto", Slot.OUTER, K.OUTER, setOf(D.FLEECE, D.FULL_ZIP, D.HIGH_NECK), a = 1f, b = 3f),
        ach("SEN-14", "Poncho de travesía con capucha", Slot.OUTER, K.CAPE, setOf(D.HOOD), b = 6f),
        ach("SEN-15", "Gorro de montaña con orejeras", Slot.HEAD, K.BEANIE, setOf(D.EARFLAPS)),
        ach("SEN-16", "Guantes de travesía con refuerzo de palma", Slot.HANDS, K.GLOVE, setOf(D.PALM)),
        ach("SEN-17", "Funda de prismáticos al hombro", Slot.SHOULDER, K.CROSSBODY, setOf(D.BINOCULARS)),
        ach("SEN-18", "Chaleco multibolsillos de exploración", Slot.OUTER, K.VEST, setOf(D.MULTI_POCKETS, D.FULL_ZIP), b = 2.5f),
        ach("SEN-19", "Cantimplora metálica con funda", Slot.HIP, K.CANTEEN),
        ach("SEN-20", "Bastones telescópicos de pareja", Slot.CARRY, K.POLES),
        ach("SEN-21", "Esterilla enrollada con correas propias", Slot.BACK, K.MAT),
        ach("SEN-22", "Mochila de expedición con bastidor", Slot.BACK, K.FRAMEPACK),
        ach("SEN-23", "Insignia bordada de curvas de nivel", Slot.CHEST, K.BADGE, setOf(D.CONTOURS)),
        ach("SEN-24", "Capa de lluvia con canesú de mapa", Slot.OUTER, K.CAPE, setOf(D.MAP_YOKE, D.HOOD), b = 9f),
        // Bicicleta
        ach("BIC-01", "Calcetines de ciclismo de puño ancho", Slot.SOCKS, K.SOCK, setOf(D.WIDE_CUFF), a = 18f),
        ach("BIC-02", "Gorra ciclista de visera corta", Slot.HEAD, K.CAP, setOf(D.SHORT_PEAK, D.STRIPE)),
        ach("BIC-03", "Maillot de cremallera corta con tres bolsillos", Slot.TOP, K.TOP, setOf(D.HALF_ZIP, D.BACK_POCKETS, D.TIGHT), a = 0.45f),
        ach("BIC-04", "Culote de tirantes con panel lateral", Slot.BOTTOM, K.BOTTOM, setOf(D.BIB_STRAPS, D.SIDE_PANEL, D.TIGHT), a = 0.5f),
        ach("BIC-05", "Botellín con franja a contraluz", Slot.BIKE_CAGE, K.BOTTLE, setOf(D.TRANSLUCENT)),
        ach("BIC-06", "Guantes sin dedos de rejilla", Slot.HANDS, K.GLOVE, setOf(D.FINGERLESS, D.MESH)),
        ach("BIC-07", "Casco de carretera con canales longitudinales", Slot.HEAD, K.HELMET, setOf(D.CHANNELS)),
        ach("BIC-08", "Maillot de manga larga con hombros acanalados", Slot.TOP, K.TOP, setOf(D.HALF_ZIP, D.RIBBED_SHOULDERS, D.TIGHT), a = 1f),
        ach("BIC-09", "Bolsa de sillín con hebilla", Slot.BIKE_SADDLEBAG, K.SADDLEBAG, setOf(D.BUCKLE)),
        ach("BIC-10", "Zapatillas de suela rígida con dos cierres", Slot.SHOES, K.SHOE, setOf(D.STRAPS_TWO), a = 3f, b = 9f),
        ach("BIC-11", "Cuadro de bici de ruta con tirantes bajos", Slot.BIKE_FRAME, K.FRAME, setOf(D.LOW_STAYS)),
        ach("BIC-12", "Cinta de manillar a espiga", Slot.BIKE_TAPE, K.BARTAPE, setOf(D.HERRINGBONE)),
        ach("BIC-13", "Perneras con banda en la pantorrilla", Slot.LEGWEAR, K.LEGWARMER, setOf(D.STRIPE)),
        ach("BIC-14", "Chaleco cortavientos de espalda abierta", Slot.OUTER, K.VEST, setOf(D.OPEN_BACK, D.FULL_ZIP, D.MESH), b = 1f),
        ach("BIC-15", "Manguitos ciclistas de borde reflectante", Slot.ARM, K.ARMSLEEVE, setOf(D.REFLECT)),
        ach("BIC-16", "Chaqueta ciclista con faldón trasero", Slot.OUTER, K.OUTER, setOf(D.REAR_TAIL, D.FULL_ZIP, D.HIGH_NECK), a = 1f, b = 1.5f),
        ach("BIC-17", "Bolsa de cuadro triangular", Slot.BIKE_FRAMEBAG, K.FRAMEBAG),
        ach("BIC-18", "Bolsa de manillar cilíndrica", Slot.BIKE_BARBAG, K.BARBAG),
        ach("BIC-19", "Portabidón doble para el cuadro", Slot.BIKE_CAGE_SEAT, K.CAGE_DOUBLE),
        ach("BIC-20", "Alforjas traseras de lona", Slot.BIKE_REAR, K.PANNIERS, setOf(D.CANVAS)),
        ach("BIC-21", "Riñonera lumbar de ciclismo con bolsillos dobles", Slot.WAIST, K.LUMBAR),
        ach("BIC-22", "Cuadro de cicloturismo con portaequipajes", Slot.BIKE_FRAME, K.FRAME, setOf(D.RACK)),
        ach("BIC-23", "Gafas de ciclismo de pantalla envolvente", Slot.EYES, K.SPORT_GLASSES),
        ach("BIC-24", "Casco de perfil compacto con visera integrada", Slot.HEAD, K.HELMET, setOf(D.COMPACT_VISOR)),
        // Caminata
        ach("CAM-01", "Pasador de cordones con forma de hoja", Slot.LACES, K.LACE, setOf(D.LEAF)),
        ach("CAM-02", "Calcetines tobilleros con lengüeta", Slot.SOCKS, K.SOCK, setOf(D.TAB), a = 6f),
        ach("CAM-03", "Camiseta de paseo con bolsillo de parche", Slot.TOP, K.TOP, setOf(D.CREW, D.PATCH_POCKET), a = 0.4f, b = 1.5f),
        ach("CAM-04", "Chaqueta ligera con cuello de pana", Slot.OUTER, K.OUTER, setOf(D.CORD_COLLAR, D.FULL_ZIP, D.TWO_POCKETS), a = 1f, b = 3f),
        ach("CAM-05", "Pulsera textil trenzada", Slot.WRIST, K.BRACELET, setOf(D.BRAIDED)),
        ach("CAM-06", "Gorra de lona de seis paneles", Slot.HEAD, K.CAP, setOf(D.SIX_PANEL, D.CANVAS)),
        ach("CAM-07", "Zapatillas urbanas con puntera reforzada", Slot.SHOES, K.SHOE, setOf(D.TOE_CAP), a = 5f, b = 9f),
        ach("CAM-08", "Abrigo ligero con capucha desmontable", Slot.OUTER, K.OUTER, setOf(D.HOOD_DETACH, D.FULL_ZIP, D.TWO_POCKETS), a = 1f, b = 4f),
        ach("CAM-09", "Pañuelo de bolsillo ilustrado", Slot.CHEST, K.POCKET_SQUARE),
        ach("CAM-10", "Bolsa bandolera con solapa", Slot.SHOULDER, K.CROSSBODY, setOf(D.FLAP)),
        ach("CAM-11", "Pantalón de paseo con pinzas", Slot.BOTTOM, K.BOTTOM, setOf(D.PLEATS), a = 0.92f, b = 2.5f),
        ach("CAM-12", "Llavero de cinta para la cintura", Slot.HIP, K.KEYCHAIN),
        ach("CAM-13", "Jersey de punto atado a la cintura", Slot.WAIST, K.TIED_SWEATER),
        ach("CAM-14", "Sobrecamisa de sarga de manga remangada", Slot.OUTER, K.OUTER, setOf(D.SHIRT_COLLAR, D.ROLLED, D.PATCH_POCKET, D.FULL_ZIP), a = 0.62f, b = 3f),
        ach("CAM-15", "Sombrero de pescador con pespuntes", Slot.HEAD, K.HAT, setOf(D.BUCKET)),
        ach("CAM-16", "Mochila urbana enrollable", Slot.BACK, K.ROLLTOP),
        ach("CAM-17", "Funda de botella con asa larga", Slot.SHOULDER, K.CROSSBODY, setOf(D.TRANSLUCENT)),
        ach("CAM-18", "Chaleco acolchado de cuadros", Slot.OUTER, K.VEST, setOf(D.QUILTED, D.PLAID, D.FULL_ZIP), b = 3f),
        ach("CAM-19", "Pin esmaltado de una huella", Slot.CHEST, K.BADGE, setOf(D.FOOTPRINT)),
        ach("CAM-20", "Zapatillas de marcha con balancín", Slot.SHOES, K.SHOE, setOf(D.ROCKER), a = 8f, b = 9f),
        ach("CAM-21", "Riñonera de paseo con bolsillo frontal", Slot.WAIST, K.WAISTBAG),
        ach("CAM-22", "Gabardina corta con abertura trasera", Slot.OUTER, K.OUTER, setOf(D.SHIRT_COLLAR, D.BACK_VENT, D.FULL_ZIP), a = 1f, b = 4f),
        ach("CAM-23", "Gafas plegables de montura redonda", Slot.EYES, K.SPORT_GLASSES, setOf(D.FOLD)),
        ach("CAM-24", "Conjunto de marcha con costuras en espiga", Slot.FULL, K.FULL, setOf(D.HERRINGBONE, D.HALF_ZIP), a = 1f),
    )

    /** Bici base del probador (sin cuadro equipado). */
    val baseFrame = Gear("frame_base", "Bici base", Slot.BIKE_FRAME, Sport.BIKE, GearPrice.Free, K.FRAME)

    val all = free + shop + achievements
    private val index = (all + baseFrame).associateBy { it.id }
    fun byId(id: String?) = id?.let { index[translate(it)] }

    /** Identificadores de la versión anterior → actuales (inventario, sincronización y conjuntos guardados). */
    val renamed = mapOf("glasses_bike" to "BIC-23", "headband_run" to "COR-23", "bottle_hike" to "SEN-19", "waistbag_walk" to "CAM-21",
        "top_plain" to "tee_crew", "top_bicolor" to "tee_raglan", "bottom_straight" to "straight_short", "bottom_stripe" to "stripe_short",
        "shoes_smooth" to "shoe_flat", "shoes_relief" to "shoe_trail")
    fun translate(id: String) = renamed[id] ?: id

    fun defaultTint(g: Gear): Tint {
        val h = g.id.hashCode().let { if (it < 0) -it else it }
        val main = when (g.sport) { Sport.RUN -> listOf(6, 2, 4, 0); Sport.HIKE -> listOf(10, 14, 15, 13); Sport.BIKE -> listOf(4, 3, 1, 5)
            Sport.WALK -> listOf(9, 13, 11, 12); null -> listOf(4, 1, 0, 3) }[h % 4]
        val accent = listOf(0, 2, 9, 6, 5)[(h / 4) % 5].let { if (it == main) 0 else it }
        return when (g.id) {
            "tee_crew" -> Tint(4, 0); "tee_raglan" -> Tint(0, 6); "straight_short", "straight_long" -> Tint(1, 0)
            "stripe_short", "stripe_long" -> Tint(3, 0); "shoe_flat" -> Tint(0, 6); "shoe_trail" -> Tint(1, 9)
            else -> Tint(main, accent)
        }
    }
}
