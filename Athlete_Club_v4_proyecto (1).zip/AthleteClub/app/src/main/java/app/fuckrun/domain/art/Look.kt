package app.fuckrun.domain.art

import kotlinx.serialization.Serializable

/**
 * Identidad del avatar. Todo es gratuito y está disponible desde el inicio; cualquier rostro combina con cualquier
 * cuerpo y prenda. Los índices son estables (se guardan y sincronizan): para añadir opciones, añadir al final.
 */
@Serializable
data class AvatarLook(
    val skin: Int = 2,
    val face: Int = 1,
    val eyes: Int = 0,
    val iris: Int = 1,
    val brows: Int = 2,
    val nose: Int = 1,
    val mouth: Int = 0,
    /** 0 = sin pecas, 1 = muchas. */
    val freckles: Float = 0f,
    val facialHair: Int = 0,
    /** Gafas de diario: 0 ninguna, 1 redondas, 2 rectangulares, 3 de ojo de gato. */
    val glasses: Int = 0,
    /** 0 = sin pelo, 1…24 peinados. */
    val hair: Int = 4,
    val hairColor: Int = 2,
    /** 0 delgada, 1 media, 2 atlética, 3 ancha. */
    val build: Int = 1,
    /** 0 baja, 1 media, 2 alta (relativa). */
    val height: Int = 1,
    /** Versión del formato del aspecto. 0 = aspecto de la v3 (2,5D), que se traduce al cargar. */
    val v: Int = 0,
) {
    /** Traduce el aspecto de la versión anterior (5 peinados, 3 caras) al catálogo actual sin perder la intención. */
    fun migrated(): AvatarLook = if (v >= 2) this else copy(
        hair = when (hair) { 0 -> 1; 1 -> 4; 2 -> 11; 3 -> 19; 4 -> 21; else -> 4 },
        face = when (face) { 0 -> 0; 1 -> 1; 2 -> 2; else -> 1 },
        skin = skin.coerceIn(0, Looks.skins.lastIndex), hairColor = hairColor.coerceIn(0, Looks.hairColors.lastIndex), v = 2,
    )

    companion object { val DEFAULT = AvatarLook(v = 2) }
}

data class Swatch(val name: String, val color: Long, val note: String = "")
data class Option(val name: String)

object Looks {
    /** 12 tonos de piel, con matiz cálido, neutro o frío. */
    val skins = listOf(
        Swatch("Porcelana", Col.rgb(0xF5E2D9), "frío"), Swatch("Marfil", Col.rgb(0xEFD5BD), "neutro"),
        Swatch("Melocotón", Col.rgb(0xF0C49D), "cálido"), Swatch("Rosa tostado", Col.rgb(0xE1AE98), "frío"),
        Swatch("Arena", Col.rgb(0xD9AF8A), "neutro"), Swatch("Miel", Col.rgb(0xD29A66), "cálido"),
        Swatch("Oliva", Col.rgb(0xBF9867), "neutro"), Swatch("Canela", Col.rgb(0xB0744A), "cálido"),
        Swatch("Almendra", Col.rgb(0x98674A), "frío"), Swatch("Caoba", Col.rgb(0x86503A), "cálido"),
        Swatch("Cacao", Col.rgb(0x6A4232), "neutro"), Swatch("Ébano", Col.rgb(0x4B2F25), "frío"),
    )
    val faces = listOf(Option("Redondo"), Option("Ovalado"), Option("Cuadrado"), Option("Corazón"), Option("Alargado"), Option("Diamante"))
    val eyes = listOf(Option("Almendrados"), Option("Redondos"), Option("Encapotados"), Option("Rasgados hacia arriba"), Option("Caídos"), Option("Sin pliegue"))
    val irises = listOf(
        Swatch("Marrón oscuro", Col.rgb(0x3A2419)), Swatch("Marrón", Col.rgb(0x6B4226)), Swatch("Avellana", Col.rgb(0x8C6A3A)),
        Swatch("Ámbar", Col.rgb(0xB07A2A)), Swatch("Verde", Col.rgb(0x5E7F4E)), Swatch("Gris", Col.rgb(0x7D8790)),
        Swatch("Azul", Col.rgb(0x4F7DB5)), Swatch("Azul grisáceo", Col.rgb(0x6C8597)),
    )
    val brows = listOf(Option("Rectas"), Option("Arqueadas"), Option("Suaves"), Option("Pobladas"), Option("Finas"), Option("Angulosas"))
    val noses = listOf(Option("Botón"), Option("Recta"), Option("Aguileña"), Option("Ancha"), Option("Respingona"))
    val mouths = listOf(Option("Carnosa"), Option("Fina"), Option("Ancha"), Option("Pequeña"), Option("Arco marcado"), Option("Media sonrisa"))
    val facialHair = listOf(Option("Afeitado"), Option("Barba de tres días"), Option("Bigote"), Option("Perilla"), Option("Barba corta"),
        Option("Barba poblada"), Option("Barba de collar"))
    val glasses = listOf(Option("Sin gafas"), Option("Redondas"), Option("Rectangulares"), Option("Ojo de gato"))
    val hairColors = listOf(
        Swatch("Negro", Col.rgb(0x1F1A18)), Swatch("Castaño oscuro", Col.rgb(0x3B2A20)), Swatch("Castaño", Col.rgb(0x5E3E29)),
        Swatch("Castaño claro", Col.rgb(0x8A6141)), Swatch("Rubio oscuro", Col.rgb(0xA8804F)), Swatch("Rubio", Col.rgb(0xD0AC6A)),
        Swatch("Rubio platino", Col.rgb(0xE6D9BC)), Swatch("Pelirrojo", Col.rgb(0xA24A2A)), Swatch("Cobre", Col.rgb(0xC26A36)),
        Swatch("Canoso", Col.rgb(0x9C9996)), Swatch("Blanco", Col.rgb(0xE8E5E0)), Swatch("Azul noche", Col.rgb(0x34507F)),
    )
    val builds = listOf(Option("Delgada"), Option("Media"), Option("Atlética"), Option("Ancha"))
    val heights = listOf(Option("Baja"), Option("Media"), Option("Alta"))

    /** 24 peinados de silueta propia (más «Sin pelo», índice 0). */
    val hairStyles = listOf(
        HairStyle("Sin pelo", bald = true),
        HairStyle("Rapado al cero", tex = Tex.BUZZ, cover = 0.6f),
        HairStyle("Degradado corto", cover = 3.5f, sides = 0.25f, fringe = Fringe.SHORT),
        HairStyle("Cresta corta", cover = 1.5f, sides = 0.1f, fringe = Fringe.CREST),
        HairStyle("Corte a tijera", cover = 4.5f, sides = 1f, fringe = Fringe.SIDE_SHORT),
        HairStyle("Raya al lado", cover = 5.5f, sides = 1f, fringe = Fringe.SIDE_LONG, length = 0.28f),
        HairStyle("Tupé", cover = 4f, sides = 0.55f, fringe = Fringe.QUIFF),
        HairStyle("Flequillo recto", cover = 5.5f, sides = 1f, fringe = Fringe.STRAIGHT, length = 0.4f),
        HairStyle("Flequillo cortina", cover = 5f, sides = 1f, fringe = Fringe.CURTAIN, length = 0.85f),
        HairStyle("Media melena lisa", cover = 5f, sides = 1f, fringe = Fringe.PART, length = 0.62f, volume = 0.08f),
        HairStyle("Melena larga lisa", cover = 5f, sides = 1f, fringe = Fringe.PART, length = 1.45f, volume = 0.1f),
        HairStyle("Ondas medias", tex = Tex.WAVY, cover = 6f, sides = 1f, fringe = Fringe.SIDE_LONG, length = 0.8f, volume = 0.28f),
        HairStyle("Ondas largas", tex = Tex.WAVY, cover = 6f, sides = 1f, fringe = Fringe.PART, length = 1.35f, volume = 0.32f),
        HairStyle("Rizos cortos", tex = Tex.CURLY, cover = 7.5f, sides = 0.8f, fringe = Fringe.CURLS, length = 0.25f),
        HairStyle("Rizos largos", tex = Tex.CURLY, cover = 8f, sides = 1f, fringe = Fringe.CURLS, length = 1.1f, volume = 0.48f),
        HairStyle("Afro", tex = Tex.COILY, cover = 18f, sides = 1f, tie = Tie.AFRO, volume = 1f),
        HairStyle("Afro alto", tex = Tex.COILY, cover = 22f, sides = 0.2f, tie = Tie.HIGH_TOP),
        HairStyle("Dos trenzas", cover = 4f, sides = 1f, fringe = Fringe.PART, tie = Tie.BRAIDS_TWO),
        HairStyle("Trenzas de raíz", cover = 2.5f, sides = 1f, tie = Tie.CORNROWS),
        HairStyle("Coleta alta", cover = 4f, sides = 1f, tie = Tie.PONY_HIGH),
        HairStyle("Coleta baja", cover = 4.5f, sides = 1f, fringe = Fringe.PART, tie = Tie.PONY_LOW),
        HairStyle("Moño alto", cover = 4f, sides = 1f, tie = Tie.BUN_HIGH),
        HairStyle("Moño bajo", cover = 4.5f, sides = 1f, fringe = Fringe.SIDE_SHORT, tie = Tie.BUN_LOW),
        HairStyle("Medio recogido", tex = Tex.WAVY, cover = 5f, sides = 1f, tie = Tie.HALF_UP, length = 1.0f, volume = 0.18f),
        HairStyle("Trenza larga", cover = 4f, sides = 1f, fringe = Fringe.SIDE_SHORT, tie = Tie.BRAID_ONE),
    )
}

enum class Tex { STRAIGHT, WAVY, CURLY, COILY, BUZZ }
enum class Fringe { NONE, SHORT, CREST, SIDE_SHORT, SIDE_LONG, QUIFF, STRAIGHT, CURTAIN, PART, CURLS }
enum class Tie { NONE, PONY_HIGH, PONY_LOW, BUN_HIGH, BUN_LOW, BRAIDS_TWO, BRAID_ONE, HALF_UP, CORNROWS, AFRO, HIGH_TOP }

data class HairStyle(
    val name: String,
    val tex: Tex = Tex.STRAIGHT,
    /** Grosor sobre el cráneo. */
    val cover: Float = 4f,
    /** 0 = laterales rapados (degradado), 1 = laterales con el mismo largo. */
    val sides: Float = 1f,
    val fringe: Fringe = Fringe.NONE,
    val tie: Tie = Tie.NONE,
    /** 0 = sin melena, 0,5 ≈ mandíbula, 1 ≈ hombros, 1,5 ≈ media espalda. */
    val length: Float = 0f,
    val volume: Float = 0f,
    val bald: Boolean = false,
)
