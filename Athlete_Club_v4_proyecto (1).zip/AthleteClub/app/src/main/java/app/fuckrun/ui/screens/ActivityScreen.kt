package app.fuckrun.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.goSection
import app.fuckrun.data.*
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.db.RunSource
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.NO_DATA
import app.fuckrun.domain.SessionType
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun ActivityScreen(nav: NavController, runId: Long, summaryMode: Boolean) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    var reload by remember { mutableIntStateOf(0) }
    val detail by produceState<RunDetail?>(null, runId, reload) { value = g.runs.detail(runId) }
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    var note by remember { mutableStateOf<String?>(null) }

    val d = detail ?: return
    val r = d.run
    val st = d.stats
    val isManual = r.source == RunSource.MANUAL
    val unsaved = r.status == RunStatus.ENDED_UNSAVED
    val noteText = note ?: r.note
    val dt = Instant.ofEpochMilli(r.startedAtWall).atZone(ZoneId.systemDefault())
    val linked = planned.firstOrNull { it.linkedRunId == r.id }

    fun goHome() { nav.goSection(Routes.HOME) }
    fun askDiscard() = sheet.confirm("¿Descartar la sesión?", "Se borrará esta sesión y su recorrido. No se puede deshacer.", "Descartar", C.Red) {
        scope.launch { g.runs.discard(r.id); goHome() }
    }
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    BackHandler(enabled = unsaved) { sheet.dialog {
        Text("Actividad sin guardar", style = T.Section)
        Spacer(Modifier.height(14.dp))
        PillButton("Guardar actividad", color = C.Green, icon = Icons.Rounded.Check, modifier = Modifier.fillMaxWidth()) { sheet.hide(); scope.launch { g.runs.save(r.id, noteText); goHome() } }
        Spacer(Modifier.height(10.dp))
        PillButton("Descartar", color = C.Control, textColor = C.Red, modifier = Modifier.fillMaxWidth()) { askDiscard() }
    } }
    val sport = r.sportEnum

    ScreenScaffold(if (unsaved) "Resumen" else "Actividad") {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SportBadge(sport, 52.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(sport.label, style = T.Section)
                    Text("${Fmt.dateLong(dt.toLocalDate())} · ${"%02d:%02d".format(dt.hour, dt.minute)}", style = T.Label)
                }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag(if (isManual) "Introducida a mano" else "Medida con GPS")
                Tag(when (r.kind) { RunKind.ROUTINE -> "Rutina"; RunKind.ROUTE -> "Ruta"; RunKind.SHARED -> "Encuentro del club"; else -> "Libre" })
                Tag("Privada")
            }
        }
        if (unsaved) {
            if ("discard" !in settings.hintsSeen) item {
                Hint("«Guardar actividad» la añade a tu historial. «Descartar» la borra; te lo confirmaremos antes.") {
                    scope.launch { g.profile.update { it.copy(hintsSeen = it.hintsSeen + "discard") } }
                }
            }
            item {
                PillButton("Guardar actividad", color = C.Green, icon = Icons.Rounded.Check, big = true, modifier = Modifier.fillMaxWidth()) {
                    scope.launch { g.runs.save(r.id, noteText); goHome() }
                }
            }
            item {
                PillButton("Descartar", color = C.Control, textColor = C.Red, icon = Icons.Rounded.DeleteOutline, modifier = Modifier.fillMaxWidth()) { askDiscard() }
            }
        }
        if (!isManual) item {
            RunMap(st.segments.map { s -> s.map { LatLon(it.lat, it.lon) } }, Modifier.fillMaxWidth().height(240.dp))
            if (st.acceptedPoints < 2) Text("No hay suficientes puntos GPS para dibujar el recorrido.", style = T.Label)
        }
        item {
            FCard {
                Stat("Distancia", if (isManual) Fmt.km(r.distanceM) else if (st.acceptedPoints >= 2) Fmt.km(st.distanceM) else NO_DATA, "km", big = true)
                Spacer(Modifier.height(12.dp))
                val rows = buildList {
                    if (!isManual) add("Tiempo transcurrido" to Fmt.duration(st.elapsedMs))
                    add("Tiempo activo" to Fmt.duration(if (isManual) r.activeMs else st.activeMs))
                    add("Ritmo medio" to "${Fmt.pace(if (isManual) app.fuckrun.domain.metrics.RunMetrics.paceFromSpeed(r.avgSpeedMps) else st.avgPaceSecPerKm)} min/km")
                    add("Velocidad media" to "${Fmt.kmh(if (isManual) r.avgSpeedMps else st.avgSpeedMps)} km/h")
                    if (!isManual) {
                        add("Velocidad máxima" to "${Fmt.kmh(st.maxSpeedMps)} km/h")
                        add("Mínima en movimiento" to "${Fmt.kmh(st.minMovingSpeedMps)} km/h")
                        add("Desnivel positivo" to (st.elevationGainM?.let { "%.0f m".format(it) } ?: NO_DATA))
                    }
                }
                rows.chunked(2).forEach { pair ->
                    Row(Modifier.padding(vertical = 6.dp)) { pair.forEach { (k, v) -> Stat(k, v, modifier = Modifier.weight(1f)) }; if (pair.size == 1) Spacer(Modifier.weight(1f)) }
                }
                if (isManual) Text("Actividad manual: sin ruta GPS ni velocidades máxima o mínima.", style = T.Label)
            }
        }
        // Puntos y récords: lo que dará al guardar (resumen) o lo que dio (historial).
        item { RewardsCard(r, unsaved, nav) }
        if (r.lostMs > 0 || r.gapCount > 0) item {
            Notice(buildString {
                append("Registro incompleto. ")
                if (r.lostMs > 0) append("Se perdieron ${Fmt.durationShort(r.lostMs)} por cierre de la app o reinicio (no cuentan como tiempo activo). ")
                if (r.gapCount > 0) append("Hubo ${r.gapCount} tramo(s) sin señal; en el mapa aparecen con línea discontinua y su distancia no se ha sumado.")
            }, icon = Icons.Rounded.Warning)
        }
        if (st.splits.isNotEmpty()) {
            item { SectionTitle("Parciales por kilómetro") }
            item {
                FCard {
                    st.splits.forEach { sp ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Text(if (sp.partial) "Últimos ${sp.partialMeters.toInt()} m" else "Km ${sp.km}", style = T.Body, modifier = Modifier.weight(1f))
                            Text(Fmt.duration(sp.durationMs), style = T.SmallNumber)
                            Text(if (sp.partial) "" else "  ${Fmt.pace(sp.durationMs / 1000.0)} min/km", style = T.Label)
                        }
                    }
                    Text("Calculados con el tiempo en movimiento registrado; los huecos sin señal no se incluyen.", style = T.Label)
                }
            }
        }
        item { SectionTitle("Asociada a") }
        item {
            FCard {
                if (r.sharedSessionName != null) ListRow("Encuentro: ${r.sharedSessionName}", "Tus datos no se han compartido con el grupo", leading = Icons.Rounded.Groups)
                if (linked != null) ListRow("Rutina: ${linked.name}", Fmt.dateLong(LocalDate.ofEpochDay(linked.epochDay)), leading = Icons.Rounded.EventAvailable)
                val runDay = dt.toLocalDate().toEpochDay()
                val candidates = planned.filter { it.linkedRunId == null && it.type != SessionType.REST.name && it.epochDay in (runDay - 3)..(runDay + 3) }
                ListRow(if (linked == null) "Vincular con una sesión planificada" else "Cambiar vinculación", leading = Icons.Rounded.Link) {
                    if (candidates.isEmpty()) sheet.show { Text("No hay sesiones planificadas pendientes cerca de esta fecha.", style = T.Body) }
                    else sheet.pick("Elige la sesión que has hecho", candidates, { "${it.name} · ${Fmt.dateLong(LocalDate.ofEpochDay(it.epochDay))}" }, null) { p ->
                        scope.launch { g.routines.link(p.id, r.id); reload++ }
                    }
                }
                if (linked != null) ListRow("Quitar vinculación", leading = Icons.Rounded.LinkOff) { scope.launch { g.routines.update(linked.copy(linkedRunId = null)); reload++ } }
            }
        }
        item { SectionTitle("Nota privada") }
        item {
            Field(noteText, "Solo tú puedes verla") { note = it }
            if (!unsaved && note != null && note != r.note) {
                Spacer(Modifier.height(8.dp))
                PillButton("Guardar nota", color = C.Text, textColor = C.Bg) { scope.launch { g.runs.edit(r.copy(note = note!!)); reload++; note = null } }
            }
        }
        if (!unsaved) {
            item { SectionTitle("Exportar y borrar") }
            if ("export" !in settings.hintsSeen) item {
                Hint("GPX sirve para abrir el recorrido en otras apps; JSON guarda todos los datos de esta actividad.") {
                    scope.launch { g.profile.update { it.copy(hintsSeen = it.hintsSeen + "export") } }
                }
            }
            item {
                FCard {
                    if (!isManual) ListRow("Exportar recorrido (GPX)", leading = Icons.Rounded.Route) {
                        privacyWarning(sheet) {
                            scope.launch { Exporter.share(ctx, "athlete-club-${sport.name.lowercase()}-${r.id}.gpx", "application/gpx+xml", Exporter.gpx(r, g.runs.points(r.id))) }
                        }
                    }
                    ListRow("Exportar datos (JSON)", leading = Icons.Rounded.DataObject) {
                        privacyWarning(sheet) {
                            scope.launch {
                                val all = Exporter.ExportAll(exportedAt = System.currentTimeMillis(), settings = null,
                                    runs = listOf(Exporter.exportRun(r, g.runs.points(r.id))), planned = emptyList())
                                Exporter.share(ctx, "athlete-club-${r.id}.json", "application/json", Exporter.json(all))
                            }
                        }
                    }
                    ListRow("Eliminar actividad", leading = Icons.Rounded.DeleteOutline, leadingTint = C.Red) {
                        sheet.confirm("¿Eliminar actividad?", "Se borrará de tu historial y se desvinculará de la rutina. No se puede deshacer.", "Eliminar", C.Red) {
                            scope.launch { g.runs.discard(r.id); nav.popBackStack() }
                        }
                    }
                }
            }
        }
    }
}

fun privacyWarning(sheet: SheetController, onContinue: () -> Unit) = sheet.confirm(
    "Antes de compartir",
    "Un GPX revela tu recorrido: puede mostrar ubicaciones personales, como tu casa o tu trabajo, y las horas a las que pasas por ellas. Compártelo solo con quien quieras.",
    "Entendido, continuar", C.Blue, onConfirm = onContinue,
)


@Composable
private fun RewardsCard(r: app.fuckrun.data.db.RunEntity, unsaved: Boolean, nav: NavController) {
    val g = FuckrunApp.graph
    val scope = rememberCoroutineScope()
    val preview by produceState<app.fuckrun.domain.SessionResult?>(null, r.id, unsaved) { if (unsaved) value = g.rewards.preview(r) }
    val entries by remember(r.syncId) { g.rewards.entriesForRun(r.syncId) }.collectAsStateWithLifecycle(emptyList())
    val unlockedItems by remember(r.syncId) { g.rewards.unlockedByRun(r.syncId) }.collectAsStateWithLifecycle(emptyList())
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    FCard {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Icon(Icons.Rounded.Stars, null, tint = C.Amber)
            Text(if (unsaved) "  Al guardar" else "  Puntos y logros", style = T.BodyStrong)
        }
        Spacer(Modifier.height(6.dp))
        if (unsaved) {
            val p = preview
            when {
                p == null -> Text(if (r.source == RunSource.MANUAL) "Las actividades manuales quedan en tu historial, pero no suman puntos, marcas ni logros." else "Calculando…", style = T.Label)
                !p.valid -> Text(if (r.source == RunSource.MANUAL) "Las actividades manuales quedan en tu historial, pero no suman puntos, marcas ni logros."
                    else "Suma puntos y logros a partir de 5 minutos activos de una actividad medida.", style = T.Label)
                else -> {
                    Text("+${app.fuckrun.domain.Rewards.POINTS_SESSION} por completar la sesión", style = T.Body)
                    RecordLines(p.changes)
                    p.unlocked.mapNotNull { app.fuckrun.domain.art.GearCatalog.byId(it) }.forEach { gr ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                            GearThumb(gr, Modifier.size(40.dp)); Text("  Desbloquearás: ${gr.name}", style = T.Body.copy(color = C.Green))
                        }
                    }
                }
            }
        } else {
            if (entries.isEmpty()) Text("Esta actividad no ha sumado puntos.", style = T.Label)
            else entries.forEach { e ->
                Text("${if (e.amount >= 0) "+" else ""}${e.amount} · ${e.reason}" + if (e.syncedAt == 0L && g.accountUid != null) " (pendiente de copia)" else "", style = T.Body)
            }
            val ev by produceState<app.fuckrun.domain.SessionResult?>(null, r.syncId, entries.size) { value = runCatching { g.rewards.refresh().sessions[r.syncId] }.getOrNull() }
            ev?.let { RecordLines(it.changes) }
        }
    }
    // Piezas ganadas: se muestran directamente sobre el personaje con una breve celebración que se puede omitir.
    val won = unlockedItems.mapNotNull { app.fuckrun.domain.art.GearCatalog.byId(it.itemId) }
    if (!unsaved && won.isNotEmpty()) UnlockCelebration(settings.avatarLook, settings.avatarOutfit, won,
        onEquip = { gr -> scope.launch { g.profile.update { it.copy(outfit = it.avatarOutfit.with(gr)) } } },
        onWardrobe = { nav.navigate(Routes.wardrobe("goals")) })
}

@Composable
private fun RecordLines(changes: List<app.fuckrun.domain.RecordChange>) {
    changes.forEach { c ->
        val u = { v: Double -> app.fuckrun.domain.Rewards.display(c.cat, v.toLong()) }
        if (c.isReference) Text("${c.cat.label}: primera referencia (${u(c.current)})", style = T.Label)
        else {
            Text("+${app.fuckrun.domain.Rewards.POINTS_RECORD} · ${c.cat.label}: ${u(c.previous!!)} → ${u(c.current)}", style = T.Body)
            Text(c.cat.criterion, style = T.Label)
        }
    }
}

@Composable
private fun UnlockCelebration(look: app.fuckrun.domain.art.AvatarLook, outfit: app.fuckrun.domain.art.Outfit, won: List<app.fuckrun.domain.art.Gear>,
                              onEquip: (app.fuckrun.domain.art.Gear) -> Unit, onWardrobe: () -> Unit) {
    val reduce = LocalReduceMotion.current
    val scope = rememberCoroutineScope()
    var i by remember { mutableStateOf(0) }
    val gr = won[i.coerceIn(0, won.lastIndex)]
    val k = remember(gr.id) { androidx.compose.animation.core.Animatable(if (reduce) 1f else 0f) }
    LaunchedEffect(gr.id) { if (!reduce) k.animateTo(1f, androidx.compose.animation.core.tween(1400)) }
    val pose = if (gr.slot.group == app.fuckrun.domain.art.Slot.Group.BIKE) app.fuckrun.domain.art.ArtPose.BIKE else app.fuckrun.domain.art.ArtPose.IDLE
    FCard(color = C.Green.copy(alpha = 0.10f)) {
        Text(if (won.size > 1) "¡Nuevas piezas! (${i + 1} de ${won.size})" else "¡Nueva pieza!", style = T.Section)
        Text(gr.name, style = T.Body)
        Box(Modifier.fillMaxWidth().height(260.dp)) {
            Avatar(look, outfit.with(gr), Modifier.fillMaxSize().graphicsLayer { val s = 0.9f + 0.1f * k.value; scaleX = s; scaleY = s }, pose = pose, animated = !reduce)
            if (k.value < 1f) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val n = 14
                for (j in 0 until n) {
                    val a = j * 2 * Math.PI / n; val rr = size.minDimension * (0.15f + 0.4f * k.value)
                    val c = androidx.compose.ui.geometry.Offset(size.width / 2 + (Math.cos(a) * rr).toFloat(), size.height * 0.45f + (Math.sin(a) * rr).toFloat())
                    drawCircle(if (j % 2 == 0) C.Amber else C.Green, radius = 4.dp.toPx() * (1f - k.value), center = c)
                }
            }
            if (k.value < 1f) Text("Omitir", style = T.Body.copy(color = C.Blue), modifier = Modifier.align(Alignment.TopEnd).heightIn(min = 48.dp)
                .liquid(androidx.compose.foundation.shape.RoundedCornerShape(50), glassLook = false, onClickLabel = "Omitir la celebración") { scope.launch { k.snapTo(1f) } }
                .padding(12.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!outfit.isWearing(gr.id)) PillButton("Equipar", color = C.Green, icon = Icons.Rounded.Check, modifier = Modifier.weight(1f)) { onEquip(gr) }
            PillButton("Probar en el vestidor", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f), onClick = onWardrobe)
        }
        if (won.size > 1) Text("Siguiente pieza", style = T.Body.copy(color = C.Blue), modifier = Modifier.heightIn(min = 48.dp)
            .liquid(androidx.compose.foundation.shape.RoundedCornerShape(50), glassLook = false) { i = (i + 1) % won.size }.padding(12.dp))
    }
}
