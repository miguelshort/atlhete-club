package app.fuckrun.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.MusicProvider
import app.fuckrun.data.db.RunEntity
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Sport
import app.fuckrun.topLevel
import app.fuckrun.tracking.SignalQuality
import app.fuckrun.tracking.StartFailure
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch

/**
 * «Cómo se usa»: aparece la primera vez que se abre la instalación y se puede repetir desde Perfil → Cómo se usa.
 * Cada lámina muestra los controles REALES de esta versión (los mismos componentes que usa la app, en el tema actual),
 * con el control resaltado y una frase que dice qué tocar y qué pasará. Los ejemplos son inertes: no se pueden pulsar,
 * no inician el GPS ni crean actividades.
 */
@Composable
fun TutorialScreen(nav: NavController, replay: Boolean) {
    val app = FuckrunApp.instance
    val scope = rememberCoroutineScope()
    TutorialContent {
        scope.launch {
            app.device.setTutorialSeen(true)
            if (nav.previousBackStackEntry != null) nav.popBackStack() else nav.navigate(Routes.HOME) { popUpTo(0) }
        }
    }
}

/** Contenido del tutorial (también lo usa la primera apertura, que después continúa al destino elegido). */
@Composable
fun TutorialContent(onFinish: () -> Unit) {
    var page by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(0) }
    val slides = slides()
    fun finish() = onFinish()
    BackHandler(enabled = page > 0) { page-- }

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Cómo se usa", style = T.BodyStrong, modifier = Modifier.weight(1f))
            if (page < slides.lastIndex) Text("Saltar", style = T.Body.copy(color = C.Blue),
                modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50)) { finish() }.padding(horizontal = 14.dp, vertical = 12.dp))
        }
        // Indicador de avance
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp).semantics { contentDescription = "Paso ${page + 1} de ${slides.size}" },
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            slides.indices.forEach { i -> Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(if (i <= page) C.Blue else C.Control)) }
        }
        AnimatedContent(page, modifier = Modifier.weight(1f), transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "lamina") { p ->
            val s = slides[p]
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(s.title, style = T.ScreenTitle)
                s.preview()
                Text(s.text, style = T.Body.copy(fontSize = 18.sp), modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            }
        }
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (page > 0) PillButton("Atrás", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) { page-- }
            if (page < slides.lastIndex) PillButton("Siguiente", color = C.Text, textColor = C.Bg, modifier = Modifier.weight(1f)) { page++ }
            else PillButton("Empezar a usar Athlete Club", color = C.Green, modifier = Modifier.weight(2f)) { finish() }
        }
    }
}


private class Slide(val title: String, val text: String, val preview: @Composable () -> Unit)

private fun slides() = listOf<Slide>(
    Slide("Bienvenida e Inicio", "Elige un deporte para preparar tu salida o toca Solo quiero entrar en la aplicación.") {
        Frame {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("Buenas tardes. ¿Sacamos la bici esta tarde?", style = T.Section, modifier = Modifier.weight(1f))
                Avatar(app.fuckrun.domain.art.AvatarLook.DEFAULT, app.fuckrun.domain.art.Outfit.DEFAULT, Modifier.size(width = 64.dp, height = 92.dp), animated = false, portrait = true)
            }
            Spacer(Modifier.height(12.dp))
            Highlight(RoundedCornerShape(30.dp), "Elegir deporte") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(C.GlassFallback).padding(8.dp)) {
                    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Sport.BIKE.icon, null, tint = Sport.BIKE.color); Text("  Elegir deporte", style = T.BodyStrong, modifier = Modifier.weight(1f))
                        Icon(Icons.Rounded.ExpandLess, null, tint = Sport.BIKE.color)
                    }
                    Sport.entries.forEach { MenuRow(it.label, it.icon, it.color, selected = it == Sport.BIKE) {} }
                }
            }
            Spacer(Modifier.height(8.dp))
            Highlight(RoundedCornerShape(20.dp), "Solo quiero entrar") { Text("Solo quiero entrar en la aplicación", style = T.Body.copy(color = C.Blue), modifier = Modifier.padding(12.dp)) }
        }
        Frame {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BrandName(); Spacer(Modifier.weight(1f))
                Highlight(CircleShape, "Avatar") { Avatar(app.fuckrun.domain.art.AvatarLook.DEFAULT, app.fuckrun.domain.art.Outfit.DEFAULT, Modifier.size(48.dp), animated = false, portrait = true) }
            }
            Spacer(Modifier.height(12.dp))
            Highlight(RoundedCornerShape(34.dp), "Barra") { FloatingNavBar(topLevel, "home", onSelect = {}, modifier = Modifier) }
            Text("La barra inferior te lleva a Rutas, Club, Rutinas y Progreso. Tu avatar abre el vestidor.", style = T.Label, modifier = Modifier.padding(top = 8.dp))
        }
    },
    Slide("Elegir deporte", "Toca el deporte y elige Correr, Sendero, Bicicleta o Caminata.") {
        Frame {
            Highlight(RoundedCornerShape(26.dp), "Selector de deporte") { SportSelector(Sport.HIKE) {} }
            Spacer(Modifier.height(8.dp))
            MenuPreview {
                MenuTitle("Deporte")
                Sport.entries.forEach { MenuRow(it.label, it.icon, it.color, selected = it == Sport.HIKE) {} }
            }
        }
    },
    Slide("Preparar la salida", "Elige tu música y vuelve aquí. Toca Empezar cuando estés listo.") {
        Frame {
            Highlight(RoundedCornerShape(22.dp), "Música") { MusicRow(MusicProvider.SPOTIFY, onChoose = {}, onOpen = {}) }
            Spacer(Modifier.height(10.dp))
            Highlight(RoundedCornerShape(22.dp), "GPS") { GpsRow(StartFailure.PERMISSION, SignalQuality.NONE, null, highlight = false) {} }
            Text("Permite la ubicación para dibujar tu recorrido.", style = T.Label, modifier = Modifier.padding(start = 6.dp, top = 4.dp))
        }
        Frame {
            Highlight(RoundedCornerShape(36.dp), "Empezar") {
                PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true, modifier = Modifier.fillMaxWidth()) {}
            }
        }
    },
    Slide("Registrar y guardar", "Pausa cuando pares. Para guardar, toca Terminar y después Guardar actividad.") {
        Frame {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Highlight(RoundedCornerShape(50), "Minimizar") {
                    Row(Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(50)).background(C.Control).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.KeyboardArrowDown, null, tint = C.Text); Text(" Minimizar", style = T.BodyStrong)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Highlight(CircleShape, "Bloquear") { RoundIconButton(Icons.Rounded.Lock, "Bloquear controles", Modifier.size(56.dp)) {} }
                PillButton("Pausar", color = C.Red, icon = Icons.Rounded.Pause, big = true, modifier = Modifier.weight(1f)) {}
                Box(Modifier.weight(1f)) { Highlight(RoundedCornerShape(36.dp), "Terminar") { PillButton("Terminar", color = C.Blue, icon = Icons.Rounded.Stop, big = true, modifier = Modifier.fillMaxWidth()) {} } }
            }
        }
        Frame {
            Highlight(RoundedCornerShape(36.dp), "Guardar actividad") {
                PillButton("Guardar actividad", color = C.Green, icon = Icons.Rounded.Check, big = true, modifier = Modifier.fillMaxWidth()) {}
            }
            Spacer(Modifier.height(8.dp))
            PillButton("Descartar", color = C.Control, textColor = C.Red, icon = Icons.Rounded.DeleteOutline, modifier = Modifier.fillMaxWidth()) {}
        }
        Frame {
            Text("Si minimizas, vuelves desde Inicio:", style = T.Label); Spacer(Modifier.height(8.dp))
            Highlight(RoundedCornerShape(36.dp), "Volver a la actividad") {
                PillButton("Volver a la actividad", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {}
            }
        }
    },
    Slide("Rutas", "Elige tu ciudad, explora sus recorridos y guarda tus favoritos con la estrella.") {
        Frame {
            Text("Rutas en Sevilla", style = T.Section)
            Text("5 rutas para correr", style = T.Label)
            Spacer(Modifier.height(8.dp))
            val sample = listOf("Parque del Alamillo" to "5,2 km · Tierra", "Ribera del Guadalquivir" to "8,4 km · Asfalto", "Vuelta al Parque de María Luisa" to "3,1 km · Circular",
                "Camino de los Molinos" to "11,7 km · Grava compactada", "Paseo de la Cartuja" to "6,0 km · Lineal")
            sample.forEachIndexed { i, (n, d) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(18.dp)).background(C.Card).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    TrackThumb(sampleTrack(i), Modifier.size(44.dp)); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text(n, style = T.Body); Text(d, style = T.Label) }
                    if (i == 0) Highlight(CircleShape, "Favorita") { Icon(Icons.Rounded.Star, "Favorita", tint = C.Amber, modifier = Modifier.padding(6.dp)) }
                    else Icon(Icons.Rounded.StarBorder, null, tint = C.TextSec)
                }
            }
        }
        Frame {
            Text("3 rutas en tu ciudad", style = T.BodyStrong)
            Text("Cobertura parcial: puedes ampliar la búsqueda.", style = T.Label)
            Spacer(Modifier.height(8.dp))
            Highlight(RoundedCornerShape(30.dp), "Alrededores") {
                PillButton("Ampliar a los alrededores (15 km)", color = C.Control, textColor = C.Text, icon = Icons.Rounded.TravelExplore, modifier = Modifier.fillMaxWidth()) {}
            }
        }
    },
    Slide("Club", "Organiza una salida o únete con una invitación. Tu recorrido sigue siendo privado.") {
        Frame {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { Highlight(RoundedCornerShape(30.dp), "Crear salida") { PillButton("Crear salida", color = C.Text, textColor = C.Bg, icon = Icons.Rounded.Add, modifier = Modifier.fillMaxWidth()) {} } }
                Box(Modifier.weight(1f)) { Highlight(RoundedCornerShape(30.dp), "Unirme con código") { PillButton("Unirme con código", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) {} } }
            }
        }
    },
    Slide("Rutinas", "Toca una fecha para ver tus sesiones de ese día. Usa las flechas para cambiar de semana.") {
        Frame {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Highlight(CircleShape, "Semana anterior") { Icon(Icons.Rounded.ChevronLeft, null, tint = C.Text, modifier = Modifier.padding(8.dp)) }
                Text("Noviembre 2026", style = T.BodyStrong, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Highlight(CircleShape, "Semana siguiente") { Icon(Icons.Rounded.ChevronRight, null, tint = C.Text, modifier = Modifier.padding(8.dp)) }
            }
            Row(Modifier.fillMaxWidth()) {
                listOf(23, 24, 25, 26, 27, 28, 29).forEachIndexed { i, d ->
                    val sel = d == 25; val today = d == 24
                    Column(Modifier.weight(1f).padding(2.dp).clip(RoundedCornerShape(12.dp)).background(if (sel) C.Blue else C.Card)
                        .then(if (today) Modifier.border(1.5.dp, C.Blue, RoundedCornerShape(12.dp)) else Modifier).padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("LMXJVSD"[i].toString(), style = T.Label.copy(color = if (sel) C.OnColor else C.TextSec))
                        Text("$d", style = T.Body.copy(color = if (sel) C.OnColor else C.Text))
                        Box(Modifier.size(6.dp).clip(CircleShape).background(when (d) { 23 -> C.Green; 25 -> C.OnColor; 27 -> C.Grey; else -> androidx.compose.ui.graphics.Color.Transparent }))
                    }
                }
            }
        }
        Frame {
            Text("Miércoles, 25 de noviembre", style = T.Section)
            Spacer(Modifier.height(8.dp))
            Highlight(RoundedCornerShape(24.dp), "Sesión del día") {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Card).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    SportBadge(Sport.HIKE, 40.dp); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text("Sendero llano", style = T.BodyStrong); Text("Sendero · Pendiente · 45 min · Suave", style = T.Label) }
                }
            }
            Spacer(Modifier.height(8.dp))
            PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {}
        }
    },
    Slide("Progreso", "Filtra por deporte y periodo. Toca una sesión para ver el mapa y tus tiempos.") {
        Frame {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Highlight(RoundedCornerShape(50), "Periodo") {
                    Row(Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(50)).background(C.Control).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Semana", style = T.BodyStrong); Icon(Icons.Rounded.ExpandMore, null, tint = C.Text)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            MenuPreview {
                MenuTitle("Periodo")
                MenuRow("Semana", Icons.Rounded.DateRange, selected = true) {}
                MenuRow("Mes", Icons.Rounded.DateRange) {}
                MenuRow("Año", Icons.Rounded.DateRange) {}
            }
            Spacer(Modifier.height(10.dp))
            Highlight(RoundedCornerShape(28.dp), "Actividad guardada") {
                RunRow(RunEntity(startedAtWall = System.currentTimeMillis(), status = RunStatus.FINISHED, distanceM = 5230.0, activeMs = 1_820_000, sport = Sport.RUN.name)) {}
            }
        }
    },
    Slide("Perfil y copia", "Inicia sesión para recuperar tus actividades si cambias de móvil. En Apariencia eliges el tema.") {
        Frame {
            FCard {
                Highlight(RoundedCornerShape(20.dp), "Cuenta") { ListRow("Cuenta", "Iniciar sesión o crear cuenta", leading = Icons.Rounded.AccountCircle) {} }
                ListRow("Sincronizado", "Última copia confirmada: hoy", leading = Icons.Rounded.CloudDone, leadingTint = C.Green, trailing = null)
                Highlight(RoundedCornerShape(20.dp), "Apariencia") { ListRow("Apariencia", "Automático", leading = Icons.Rounded.BrightnessAuto) {} }
            }
        }
    },
    Slide("Avatar y Tienda", "Toca tu avatar para abrir el vestidor. Tus actividades dan puntos para la Tienda y tus metas desbloquean piezas en Logros.") {
        Frame {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Highlight(RoundedCornerShape(24.dp), "Avatar") {
                    Avatar(app.fuckrun.domain.art.AvatarLook.DEFAULT.copy(hair = 19, hairColor = 7), app.fuckrun.domain.art.Outfit.DEFAULT.with(app.fuckrun.domain.art.GearCatalog.byId("COR-23")!!).with(app.fuckrun.domain.art.GearCatalog.byId("tee_raglan")!!),
                        Modifier.size(width = 120.dp, height = 220.dp), animated = false)
                }
                Spacer(Modifier.width(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Vestidor", style = T.Section)
                    PillButton("Equipar", color = C.Green, icon = Icons.Rounded.Check) {}
                    Text("Probar no cambia tu ropa hasta que pulses Equipar.", style = T.Label)
                }
            }
        }
        Frame {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Stars, null, tint = C.Amber); Text("  +10 por completar la sesión · +5 por récord", style = T.Body)
            }
            Spacer(Modifier.height(8.dp))
            Highlight(RoundedCornerShape(24.dp), "Recompensa") {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Card).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Face, null, tint = Sport.RUN.color); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text("Cinta de running", style = T.BodyStrong); Text("Conseguido al mejorar tu ritmo en 1 km", style = T.Label) }
                    Text("Equipar", style = T.Label.copy(color = C.OnColor), modifier = Modifier.clip(RoundedCornerShape(50)).background(C.Green).padding(horizontal = 12.dp, vertical = 10.dp))
                }
            }
        }
    },
)

private fun sampleTrack(i: Int): List<app.fuckrun.data.LatLon> = (0..24).map { k ->
    val a = k / 24.0 * Math.PI * 2
    app.fuckrun.data.LatLon(37.39 + 0.004 * kotlin.math.sin(a * (1 + i % 2)) * (1 + 0.2 * i), -5.98 + 0.006 * kotlin.math.cos(a) + 0.0005 * i * k / 24.0)
}

/** Marco de «captura»: contenido real de la app, inerte (absorbe los toques) y adaptado al tema. */
@Composable
private fun Frame(content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(C.Surface).border(1.dp, C.Border, RoundedCornerShape(28.dp))) {
        // Estado de desenfoque propio y vacío: el vidrio de la barra de ejemplo no lee la capa de la pantalla real.
        CompositionLocalProvider(LocalBackdrop provides null) {
            Column(Modifier.fillMaxWidth().padding(14.dp).clearAndSetSemantics { contentDescription = "Ejemplo de la pantalla" }, content = content)
        }
        Box(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { } })
    }
}

/** Recorte resaltado del control que hay que tocar. */
@Composable
private fun Highlight(shape: androidx.compose.ui.graphics.Shape, label: String, content: @Composable () -> Unit) {
    Box(Modifier.border(3.dp, C.Blue, shape).padding(4.dp).semantics { contentDescription = "Resaltado: $label" }) { content() }
}

/** Menú abierto tal y como se despliega en la app (mismo material de vidrio). */
@Composable
private fun MenuPreview(content: @Composable ColumnScope.() -> Unit) {
    // Dentro de la propia capa de contenido no se aplica desenfoque (evita que el vidrio se lea a sí mismo):
    // se usa la película translúcida de respaldo del mismo material.
    val shape = RoundedCornerShape(28.dp)
    Column(Modifier.fillMaxWidth(0.92f).clip(shape).background(C.GlassFallback)
        .border(1.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(C.EdgeTop, C.EdgeBottom)), shape).padding(8.dp), content = content)
}
