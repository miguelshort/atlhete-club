package app.fuckrun.data

import androidx.room.withTransaction
import app.fuckrun.data.db.*
import app.fuckrun.domain.*
import app.fuckrun.domain.art.Gear
import app.fuckrun.domain.art.GearCatalog
import app.fuckrun.domain.art.GearPrice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import java.time.ZoneId

/**
 * Economía del club: puntos, marcas personales, logros, compras e inventario.
 *  - Puntos: «act:<actividad>» (10) y «rec:<actividad>:<categoría>» (5). Una actividad se evalúa una sola vez: los
 *    puntos ya pagados nunca se vuelven a acreditar, aunque después cambie el historial.
 *  - Logros: el progreso se recalcula SIEMPRE con el historial vigente (en orden de fecha, desempate estable). Al
 *    alcanzar un umbral se conceden a la vez todas las piezas recién elegibles; lo conseguido no se retira si luego se
 *    elimina una actividad.
 *  - Compras: transacción con identificador «buy:<artículo>», sin saldo negativo ni cargos dobles.
 */
class RewardsRepository(private val db: AppDatabase) {
    private val dao = db.rewards()
    private val mutex = Mutex()
    var onChange: () -> Unit = {}
    /** Si el municipio elegido tiene catálogo de rutas de Sendero (si no, SEN-23/24 usan semanas activas). */
    var routesAvailable: () -> Boolean = { true }

    val balance: Flow<Int> = dao.balance()
    val pendingPoints: Flow<Int> = dao.pendingPoints()
    val pendingItems: Flow<Int> = dao.pendingItems()
    val owned: Flow<Set<String>> = dao.inventory().map { l -> l.map { GearCatalog.translate(it.itemId) }.toSet() }
    fun entriesForRun(syncId: String) = dao.entriesForRun(syncId)
    /** Piezas que concedió esta actividad (para mostrarlas sobre el personaje en el resumen). */
    fun unlockedByRun(syncId: String) = dao.unlockedByRun(syncId)

    private val _replay = MutableStateFlow<Rewards.Replay?>(null)
    /** Progreso estadístico vigente (Logros), recalculado tras cada cambio. */
    val replay = _replay.asStateFlow()

    private suspend fun facts(): List<SessionFacts> {
        val planned = db.routines().allPlannedOnce().filter { it.linkedRunId != null }
        val zone = ZoneId.systemDefault()
        return db.runs().finishedOnce().map { r ->
            val p = planned.firstOrNull { it.linkedRunId == r.id && it.sport == r.sport }
            SessionFacts(
                syncId = r.syncId, sport = Sport.of(r.sport), startedAt = r.startedAtWall,
                date = Instant.ofEpochMilli(r.startedAtWall).atZone(zone).toLocalDate(),
                measured = r.source == RunSource.GPS && r.status == RunStatus.FINISHED,
                activeMs = r.activeMs, gpsDistanceM = r.distanceM, best1kMs = r.best1kMs,
                plannedKey = p?.syncId, routeId = r.routeId, routeCovered = (r.routeCoverage ?: 0.0) >= RouteCoverage.REQUIRED,
            )
        }
    }

    suspend fun refresh(): Rewards.Replay = Rewards.replay(facts(), routesAvailable()).also { _replay.value = it }

    /**
     * Lo que daría guardar esta actividad (resumen antes de «Guardar»): puntos, marcas (anterior, nueva y criterio) y
     * piezas que se desbloquearían.
     */
    suspend fun preview(run: RunEntity): SessionResult? {
        val zone = ZoneId.systemDefault()
        val me = SessionFacts(run.syncId, Sport.of(run.sport), run.startedAtWall, Instant.ofEpochMilli(run.startedAtWall).atZone(zone).toLocalDate(),
            run.source == RunSource.GPS, run.activeMs, run.distanceM, run.best1kMs, null, run.routeId, (run.routeCoverage ?: 0.0) >= RouteCoverage.REQUIRED)
        val r = Rewards.replay(facts().filter { it.syncId != run.syncId } + me, routesAvailable())
        val owned = dao.inventoryOnce().map { GearCatalog.translate(it.itemId) }.toSet()
        return r.sessions[run.syncId]?.let { it.copy(unlocked = it.unlocked.filter { id -> id !in owned }) }
    }

    /**
     * Concilia puntos y premios con el historial: tras guardar, al actualizar desde una versión anterior, al importar o
     * al sincronizar actividades antiguas. Idempotente: repetirlo no cambia nada.
     * @return piezas concedidas en esta llamada.
     */
    suspend fun reconcile(): List<String> = mutex.withLock {
        val r = Rewards.replay(facts(), routesAvailable())
        val granted = mutableListOf<String>()
        db.withTransaction {
            for ((id, res) in r.sessions) {
                if (!res.valid || dao.hasEntry("act:$id") > 0) continue
                res.entries.forEach { dao.insertEntry(LedgerEntity(it.id, it.amount, it.reason, runSyncId = id)) }
            }
            for ((ach, runId) in r.reached) {
                if (dao.insertItem(InventoryEntity(ach, "ACHIEVEMENT", runSyncId = runId)) != -1L) granted += ach
            }
        }
        _replay.value = r
        if (granted.isNotEmpty() || r.sessions.isNotEmpty()) onChange()
        granted
    }

    suspend fun awardFor(@Suppress("UNUSED_PARAMETER") run: RunEntity) { reconcile() }

    sealed interface BuyResult { data object Ok : BuyResult; data object AlreadyOwned : BuyResult; data class NotEnough(val missing: Int) : BuyResult; data object NotForSale : BuyResult }

    /** Compra con puntos (confirmada antes en la interfaz). Gastar y equipar son acciones distintas. */
    suspend fun buy(item: Gear): BuyResult {
        val price = (item.price as? GearPrice.Points)?.amount ?: return BuyResult.NotForSale
        val r: BuyResult = db.withTransaction<BuyResult> {
            if (dao.inventoryOnce().any { GearCatalog.translate(it.itemId) == item.id } || dao.hasEntry("buy:${item.id}") > 0) return@withTransaction BuyResult.AlreadyOwned
            val bal = dao.balanceOnce()
            if (bal < price) return@withTransaction BuyResult.NotEnough(price - bal)
            dao.insertEntry(LedgerEntity("buy:${item.id}", -price, "Compra: ${item.name}", itemId = item.id))
            dao.insertItem(InventoryEntity(item.id, "BOUGHT"))
            BuyResult.Ok
        }
        if (r == BuyResult.Ok) onChange()
        return r
    }
}
