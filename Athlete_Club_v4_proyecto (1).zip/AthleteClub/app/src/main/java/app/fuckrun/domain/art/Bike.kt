package app.fuckrun.domain.art

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Bici del probador y de la pose ciclista. Dibujo auxiliar con cuadro, ruedas y puntos de anclaje compartidos
 * (tubo diagonal, tubo de sillín, triángulo principal, sillín, manillar y portaequipajes), así que una pieza montada
 * sigue en su sitio en cualquier cuadro.
 */
object Bike {
    private val tire = Col.rgb(0x24272C)
    private val metal = Col.rgb(0xA6ABB2)

    private fun frameGear(o: Outfit) = o.gear(Slot.BIKE_FRAME) ?: GearCatalog.baseFrame
    private fun frameColor(o: Outfit) = frameGear(o).let { GearArt.color(o, it) }

    fun draw(d: Drawing, b: BikeGeo, o: Outfit, behindRider: Boolean) {
        if (behindRider) {
            wheel(d, b.rear, b.r); wheel(d, b.front, b.r)
            frame(d, b, o)
            o.gear(Slot.BIKE_REAR)?.let { part(d, b, o, it) }
            o.gear(Slot.BIKE_SADDLEBAG)?.let { part(d, b, o, it) }
            o.gear(Slot.BIKE_FRAMEBAG)?.let { part(d, b, o, it) }
            o.gear(Slot.BIKE_CAGE)?.let { part(d, b, o, it) }
            o.gear(Slot.BIKE_CAGE_SEAT)?.let { part(d, b, o, it) }
            crank(d, b, 1)
            saddle(d, b)
        } else {
            crank(d, b, 0)
            bars(d, b, o)
            o.gear(Slot.BIKE_BARBAG)?.let { part(d, b, o, it) }
        }
    }

    private fun wheel(d: Drawing, c: P, r: Float) {
        d.stroke(Path.circle(c, r - 3.5f), tire, 7f)
        d.stroke(Path.circle(c, r - 8f), metal, 2.2f)
        for (k in 0 until 16) { val a = k * PI.toFloat() / 8f
            d.stroke(Path.line(c + P(cos(a), sin(a)) * 3f, c + P(cos(a + 0.4f), sin(a + 0.4f)) * (r - 9f)), Col.rgb(0xC3C7CC), 0.6f) }
        d.solid(Path.circle(c, 4.5f), metal, line = 1f, depth = 1f)
    }

    private fun tubeP(a: P, b: P, w: Float) = Path.limb(a, b, w, w, 0f)

    private fun frame(d: Drawing, b: BikeGeo, o: Outfit) {
        val f = frameGear(o); val c = frameColor(o); val a = GearArt.color(o, f, false)
        val low = f.d.contains(D.LOW_STAYS)
        val rack = f.d.contains(D.RACK) || o.gear(Slot.BIKE_REAR) != null
        val stayTop = if (low) b.bb.lerp(b.seatJoin, 0.58f) else b.seatJoin
        // Tirantes y vainas.
        d.solid(tubeP(stayTop, b.rear, 4.2f), Col.shade(c, 0.08f), line = 1.1f, depth = 1f)
        d.solid(tubeP(b.bb, b.rear, 5f), Col.shade(c, 0.08f), line = 1.1f, depth = 1f)
        if (rack) {
            val r0 = b.rear + P(0f, -50f); val r1 = b.seatJoin + P(-4f, 10f)
            d.solid(tubeP(r0 + P(-34f, 0f), r1, 3f), Col.rgb(0x3C4047), line = 0.9f, depth = 0.5f)
            d.solid(tubeP(r0 + P(-30f, 0f), b.rear, 3f), Col.rgb(0x3C4047), line = 0.9f, depth = 0.5f)
            d.solid(tubeP(r0, b.rear + P(0f, -2f), 3f), Col.rgb(0x3C4047), line = 0.9f, depth = 0.5f)
        }
        // Triángulo principal.
        d.solid(tubeP(b.bb, b.headBottom, 7f), c, line = 1.3f, depth = 2f)
        d.solid(tubeP(b.bb, b.saddle + P(5f, 12f), 6.4f), c, line = 1.3f, depth = 2f)
        val ttFront = if (f.d.contains(D.RACK)) b.headTop + P(2f, 10f) else b.headTop + P(0f, 4f)
        d.solid(tubeP(b.seatJoin, ttFront, 6f), c, line = 1.3f, depth = 2f)
        d.solid(tubeP(b.headTop, b.headBottom, 8.5f), Col.shade(c, 0.05f), line = 1.3f, depth = 2f)
        // Horquilla.
        d.solid(Path.smooth(listOf(b.headBottom + P(-3f, 0f), b.headBottom + P(4f, 0f), b.front + P(4f, -14f), b.front + P(1f, 0f), b.front + P(-3f, -4f), b.front + P(-2f, -20f)), true), c, line = 1.1f, depth = 1f)
        // Decoración del cuadro con el color de acento.
        d.solid(tubeP(b.bb.lerp(b.headBottom, 0.45f), b.bb.lerp(b.headBottom, 0.62f), 7.2f), a, line = 0f, depth = 0f, accent = false)
        d.solid(Path.circle(b.bb, 6.5f), metal, line = 1f, depth = 1f)
        if (f.d.contains(D.RACK)) { // cicloturismo: guardabarros
            d.stroke(Path.smooth((0..8).map { k -> val t = PI.toFloat() * (1.1f + k * 0.11f); b.rear + P(cos(t), sin(t)) * (b.r + 3f) }, false), Col.rgb(0x3C4047), 3f)
            d.stroke(Path.smooth((0..8).map { k -> val t = PI.toFloat() * (1.2f + k * 0.11f); b.front + P(cos(t), sin(t)) * (b.r + 3f) }, false), Col.rgb(0x3C4047), 3f)
        }
    }

    private fun saddle(d: Drawing, b: BikeGeo) {
        d.solid(tubeP(b.saddle + P(4f, 2f), b.saddle + P(5f, 16f), 4f), metal, line = 0.9f, depth = 0.5f)
        d.solid(Path.smooth(listOf(b.saddle + P(-16f, -3f), b.saddle + P(4f, -4f), b.saddle + P(18f, -1f), b.saddle + P(16f, 3f), b.saddle + P(-14f, 4f)), true), Col.rgb(0x2A2D33), line = 1.1f, depth = 1.5f)
    }

    private fun crank(d: Drawing, b: BikeGeo, i: Int) {
        if (i == 1) {
            d.stroke(Path.circle(b.bb, 13f), Col.rgb(0x5A5F66), 3f)
            d.stroke(Path.line(b.bb + P(0f, -13f), b.rear + P(0f, -6f)), Col.rgb(0x5A5F66), 1.4f)
            d.stroke(Path.line(b.bb + P(0f, 13f), b.rear + P(0f, 6f)), Col.rgb(0x5A5F66), 1.4f)
        }
        d.solid(tubeP(b.bb, b.pedal[i], 4.5f), if (i == 1) Col.shade(metal, 0.2f) else metal, line = 1f, depth = 0.5f)
        d.solid(Path.roundRect(b.pedal[i].x - 7f, b.pedal[i].y - 2.5f, b.pedal[i].x + 7f, b.pedal[i].y + 2.5f, 1.2f), Col.rgb(0x2A2D33), line = 0.8f, depth = 0.4f)
    }

    private fun barPath(b: BikeGeo) = listOf(b.headTop + P(0f, -2f), b.bar, b.hood, b.hood + P(6f, 8f), b.hood + P(4f, 26f), b.hood + P(-6f, 30f))

    private fun bars(d: Drawing, b: BikeGeo, o: Outfit) {
        val pts = barPath(b)
        d.solid(tubeP(pts[0], pts[1], 5f), metal, line = 1f, depth = 0.5f)
        val drop = Figure.tube(pts.drop(1), pts.drop(1).map { 5f }, capStart = true, capEnd = true)
        val tape = o.gear(Slot.BIKE_TAPE)
        val tc = tape?.let { GearArt.color(o, it) } ?: Col.rgb(0x2A2D33)
        d.solid(drop, tc, line = 1.1f, depth = 1f)
        if (tape != null && tape.d.contains(D.HERRINGBONE)) d.group(clip = drop) {
            val a = GearArt.color(o, tape, false)
            for (k in 0..14) { val q = Figure.cut(pts.drop(1), k / 14f).last(); stroke(Path.line(q + P(-3f, -2f), q, q + P(3f, -2f)), a, 0.9f) }
        }
    }

    /** Pieza montable en sus anclajes. */
    fun part(d: Drawing, b: BikeGeo, o: Outfit, g: Gear) {
        val c = GearArt.color(o, g); val a = GearArt.color(o, g, false)
        when (g.kind) {
            K.FRAME -> { val oo = o.with(g); wheel(d, b.rear, b.r); wheel(d, b.front, b.r); frame(d, b, oo); saddle(d, b); crank(d, b, 1); crank(d, b, 0); bars(d, b, oo) }
            K.BOTTLE -> {
                val q = b.bb.lerp(b.headBottom, 0.42f) + P(-4f, -9f)
                val dir = (b.headBottom - b.bb).norm(); val n = dir.perp()
                d.stroke(Path.line(q - dir * 14f + n * 4f, q + dir * 14f + n * 4f), Col.rgb(0x3C4047), 2f)
                val bottle = Path.roundRect(-16f, -6f, 14f, 6f, 5f).map { rot(it, P(0f, 0f), dir.angle()) + q }
                d.fill(bottle, if (g.d.contains(D.TRANSLUCENT)) Col.of(Col.r(c), Col.g(c), Col.b(c), 150) else c)
                d.group(clip = bottle) { fill(Path.rect(-6f, -8f, 2f, 8f).map { rot(it, P(0f, 0f), dir.angle()) + q }, a) }
                d.stroke(bottle, Col.ink(c), 1f)
                d.solid(Path.roundRect(14f, -3.5f, 19f, 3.5f, 1.2f).map { rot(it, P(0f, 0f), dir.angle()) + q }, Col.rgb(0x2A2D33), line = 0.7f, depth = 0.3f)
            }
            K.CAGE_DOUBLE -> {
                val dir = (b.saddle - b.bb).norm(); val n = dir.perp()
                for (k in 0..1) { val q = b.bb.lerp(b.saddle, 0.3f + k * 0.0f) + n * (-9f - k * 10f) + dir * (k * 2f)
                    d.stroke(Path.line(q - dir * 13f, q + dir * 13f), Col.rgb(0x3C4047), 2.2f)
                    d.solid(Path.roundRect(-13f, -4.8f, 12f, 4.8f, 4f).map { rot(it, P(0f, 0f), dir.angle()) + q }, if (k == 0) c else a, line = 1f, depth = 1f) }
            }
            K.SADDLEBAG -> {
                val q = b.saddle + P(-12f, 12f)
                d.solid(Path.smooth(listOf(q + P(-12f, -6f), q + P(10f, -6f), q + P(8f, 7f), q + P(-4f, 10f), q + P(-14f, 3f)), true), c, line = 1.2f, depth = 2f)
                d.solid(Path.roundRect(-3f, -6f, 3f, 6f, 1f).map { it + q + P(-1f, 1f) }, a, line = 0.8f, depth = 0.5f)
                d.fill(Path.roundRect(-2.4f, -1.5f, 2.4f, 1.5f, 0.5f).map { it + q + P(-1f, 1f) }, metal)
            }
            K.FRAMEBAG -> {
                val tri = Path.smooth(listOf(b.seatJoin + P(7f, 5f), b.headTop + P(-10f, 9f), b.bb.lerp(b.headBottom, 0.72f) + P(-6f, -6f), b.bb + P(8f, -14f)), true)
                d.solid(tri, c, line = 1.3f, depth = 3f)
                d.stroke(Path.line(b.seatJoin + P(12f, 9f), b.headTop + P(-14f, 13f)), a, 1.4f)
            }
            K.BARBAG -> {
                val q = b.bar + P(10f, 10f)
                d.solid(Path.roundRect(-14f, -8f, 14f, 8f, 8f).map { it + q }, c, line = 1.3f, depth = 2.5f)
                d.solid(Path.ellipse(q + P(14f, 0f), 3.6f, 8f), Col.shade(c, 0.12f), line = 1f, depth = 1f)
                d.stroke(Path.line(q + P(-8f, -8f), q + P(-8f, 8f)), a, 1.8f)
            }
            K.BARTAPE -> { val oo = o.with(g); bars(d, b, oo) }
            K.PANNIERS -> {
                val q = b.rear + P(-8f, -28f)
                d.solid(Path.roundRect(-22f, -20f, 22f, 22f, 6f).map { it + q }, c, line = 1.4f, depth = 4f)
                d.solid(Path.roundRect(-22f, -24f, 22f, -6f, 6f).map { it + q }, Col.shade(c, 0.1f), line = 1.1f, depth = 2f)
                for (s in listOf(-1f, 1f)) d.stroke(Path.line(q + P(s * 12f, -10f), q + P(s * 12f, 6f)), a, 2.2f)
                if (g.d.contains(D.CANVAS)) d.group(clip = Path.roundRect(-22f, -6f, 22f, 22f, 6f).map { it + q }) { for (k in 0..12) stroke(Path.line(q + P(-24f + k * 4f, 24f), q + P(-16f + k * 4f, -8f)), Col.shade(c, 0.12f), 0.6f) }
            }
            else -> Unit
        }
    }
}
