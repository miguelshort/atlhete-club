package app.fuckrun.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.foundation.border
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.*
import app.fuckrun.data.db.PlannedSessionEntity
import app.fuckrun.data.db.RoutineEntity
import app.fuckrun.data.db.RunKind
import app.fuckrun.domain.*
import app.fuckrun.domain.Sport
import app.fuckrun.reminders.Reminders
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

fun stateColor(s: PlanState) = when (s) { PlanState.DONE -> C.Green; PlanState.MISSED -> C.Red; PlanState.PENDING -> C.Grey; PlanState.REST -> C.Control }
fun stateLabel(s: PlanState) = when (s) { PlanState.DONE -> "Completada"; PlanState.MISSED -> "Vencida"; PlanState.PENDING -> "Pendiente"; PlanState.REST -> "Descanso" }

/**
 * Rutinas: calendario SEMANAL con la apariencia del mensual (misma cabecera de mes y año, mismas celdas e indicadores),
 * en una sola fila de lunes a domingo. «Hoy» lleva contorno; el día consultado, relleno. Cada fecha se puede tocar,
 * aunque esté vacía, y debajo se ven solo sus sesiones. Semana y fecha consultadas se conservan al volver.
 */
@Composable
fun RoutinesScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    val routines by remember { g.routines.routines() }.collectAsStateWithLifecycle(emptyList())
    val today = LocalDate.now()
    var monthView by rememberSaveable { mutableStateOf(false) }
    var anchorDay by rememberSaveable { mutableStateOf(today.toEpochDay()) }
    var selectedDay by rememberSaveable { mutableStateOf(today.toEpochDay()) }
    val anchor = LocalDate.ofEpochDay(anchorDay)
    val selected = LocalDate.ofEpochDay(selectedDay)

    val weekStart = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val (from, to) = if (monthView) YearMonth.from(anchor).let { it.atDay(1) to it.atEndOfMonth() } else weekStart to weekStart.plusDays(6)
    val comp = compliance(planned, from, to, today)

    fun actions(p: PlannedSessionEntity) = plannedActions(p, sheet, nav, scope, ctx)
    fun addSession(day: LocalDate) {
        if (routines.isEmpty()) sheet.dialog {
            Text("Primero crea una rutina", style = T.Section)
            Spacer(Modifier.height(8.dp))
            Text("Una rutina agrupa tus sesiones. Puedes crearla desde una plantilla o desde cero.", style = T.Body.copy(color = C.TextSec))
            Spacer(Modifier.height(14.dp))
            PillButton("Nueva rutina", color = C.Green, icon = Icons.Rounded.Add, modifier = Modifier.fillMaxWidth()) { sheet.hide(); nav.navigate(Routes.ROUTINE_NEW) }
            Spacer(Modifier.height(8.dp))
            PillButton("Cancelar", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { sheet.hide() }
        } else sheet.page("Nueva sesión") { PlannedEditor(null, routines, day) { sheet.hide() } }
    }
    fun shift(weeks: Long) {
        val a = if (monthView) anchor.plusMonths(weeks) else anchor.plusWeeks(weeks)
        anchorDay = a.toEpochDay()
        // La fecha consultada se mueve con la semana (mismo día de la semana).
        selectedDay = (if (monthView) a.withDayOfMonth(1) else selected.plusWeeks(weeks)).toEpochDay()
    }

    ScreenScaffold("Rutinas", header = {
        Row(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), C.Control, role = androidx.compose.ui.semantics.Role.DropdownList) {
            sheet.pick("Vista", listOf(false, true), { if (it) "Mensual" else "Semanal" }, monthView, icon = { if (it) Icons.Rounded.CalendarMonth else Icons.Rounded.ViewWeek }) { monthView = it }
        }.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (monthView) "Mensual" else "Semanal", style = T.BodyStrong); Icon(Icons.Rounded.ExpandMore, null, tint = C.Text)
        }
    }) {
        item {
            FCard {
                // Cabecera común a semana y mes: mes y año (o los dos meses/años si la semana los cruza), flechas y «Hoy».
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RoundIconButton(Icons.Rounded.ChevronLeft, if (monthView) "Mes anterior" else "Semana anterior") { shift(-1) }
                    Text(if (monthView) Fmt.month(YearMonth.from(anchor)) else weekTitle(weekStart), style = T.BodyStrong,
                        textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    RoundIconButton(Icons.Rounded.ChevronRight, if (monthView) "Mes siguiente" else "Semana siguiente") { shift(1) }
                }
                val onThisWeek = !monthView && today in weekStart..weekStart.plusDays(6) && selected == today
                if (!onThisWeek) Text("Hoy", style = T.Body.copy(color = C.Blue), modifier = Modifier.align(Alignment.CenterHorizontally)
                    .heightIn(min = 48.dp).liquid(RoundedCornerShape(50)) { anchorDay = today.toEpochDay(); selectedDay = today.toEpochDay() }
                    .padding(horizontal = 16.dp, vertical = 12.dp))
                Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 4.dp)) {
                    DayOfWeek.values().forEach { Text(Fmt.dayShort(it).take(1), style = T.Label, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
                }
                if (monthView) {
                    val ym = YearMonth.from(anchor); val first = ym.atDay(1); val offset = first.dayOfWeek.value - 1
                    (0 until (offset + ym.lengthOfMonth() + 6) / 7).forEach { w ->
                        Row(Modifier.fillMaxWidth()) {
                            (0..6).forEach { c ->
                                val idx = w * 7 + c - offset
                                Box(Modifier.weight(1f)) {
                                    if (idx in 0 until ym.lengthOfMonth()) {
                                        val d = first.plusDays(idx.toLong())
                                        DayCell(d, today, selected, planned) { selectedDay = d.toEpochDay() }
                                    }
                                }
                            }
                        }
                    }
                } else Row(Modifier.fillMaxWidth()) {
                    (0..6).forEach { i ->
                        val d = weekStart.plusDays(i.toLong())
                        Box(Modifier.weight(1f)) { DayCell(d, today, selected, planned) { selectedDay = d.toEpochDay() } }
                    }
                }
            }
        }
        // Día consultado
        item {
            Text(Fmt.dateLong(selected), style = T.Section, modifier = Modifier.padding(start = 4.dp, top = 4.dp).semantics { heading() })
        }
        val dayList = planned.filter { it.epochDay == selectedDay }.sortedWith(compareBy({ it.reminderMinuteOfDay ?: Int.MAX_VALUE }, { it.id }))
        if (dayList.isEmpty()) item {
            FCard {
                Text("Sin rutina para este día", style = T.BodyStrong)
                Spacer(Modifier.height(10.dp))
                PillButton("Añadir sesión", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Add) { addSession(selected) }
            }
        } else {
            dayList.forEach { p -> item(key = "p${p.id}") { DaySession(p, onStart = { nav.navigate(Routes.prerun(RunKind.ROUTINE, planned = p.id)) }) { actions(p) } } }
            item { PillButton("Añadir sesión", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Add) { addSession(selected) } }
        }
        item {
            FCard {
                Text(if (monthView) "Cumplimiento del mes" else "Cumplimiento de la semana", style = T.Label)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ComplianceDonut(comp.done, comp.missed, comp.pending)
                    Spacer(Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${comp.done} completadas", style = T.Body.copy(color = C.Green))
                        Text("${comp.missed} vencidas sin completar", style = T.Body.copy(color = C.Red))
                        Text("${comp.pending} pendientes o futuras", style = T.Body.copy(color = C.TextSec))
                        Text("Los descansos (${comp.rest}) no cuentan como fallos.", style = T.Label)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Nueva rutina", color = C.Text, textColor = C.Bg, icon = Icons.Rounded.Add, modifier = Modifier.weight(1f)) { nav.navigate(Routes.ROUTINE_NEW) }
            }
        }
        if (routines.isNotEmpty()) {
            item { SectionTitle("Mis rutinas") }
            routines.forEach { r ->
                item(key = "r${r.id}") {
                    FCard {
                        ListRow(r.name, "${Fmt.date(LocalDate.ofEpochDay(r.startEpochDay))} – ${Fmt.date(LocalDate.ofEpochDay(r.endEpochDay))}" +
                            (r.templateId?.let { id -> " · plantilla ${Templates.all.firstOrNull { it.id == id }?.name ?: id}" } ?: ""), leading = Icons.Rounded.Repeat) {
                            sheet.show {
                                MenuTitle(r.name)
                                ListRow("Eliminar rutina", "Las actividades ya registradas no se modifican", leading = Icons.Rounded.DeleteOutline, leadingTint = C.Red) {
                                    sheet.confirm("¿Eliminar ${r.name}?", "Se borrarán sus sesiones planificadas. Tu historial de actividades no cambia.", "Eliminar", C.Red) {
                                        scope.launch { g.routines.deleteRoutine(r.id) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Plantillas") }
        Templates.all.forEach { t ->
            item(key = t.id) {
                FCard {
                    Text("Nivel ${t.level.label}", style = T.Label)
                    Text(t.name, style = T.BodyStrong)
                    Text(t.summary, style = T.Body.copy(color = C.TextSec))
                    Text("Procedencia: ${t.source}", style = T.Label, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

/** «Noviembre 2026», «Noviembre – Diciembre 2026» o «Diciembre 2026 – Enero 2027». */
fun weekTitle(start: LocalDate): String {
    val end = start.plusDays(6)
    fun m(d: LocalDate) = d.month.getDisplayName(java.time.format.TextStyle.FULL, ES).replaceFirstChar { it.uppercase() }
    return when {
        start.month == end.month -> "${m(start)} ${start.year}"
        start.year == end.year -> "${m(start)} – ${m(end)} ${start.year}"
        else -> "${m(start)} ${start.year} – ${m(end)} ${end.year}"
    }
}

/** Celda de fecha común a semana y mes: «hoy» con contorno, día consultado con relleno, puntos de estado. */
@Composable
private fun DayCell(d: LocalDate, today: LocalDate, selected: LocalDate, planned: List<PlannedSessionEntity>, onClick: () -> Unit) {
    val isSel = d == selected; val isToday = d == today
    val list = planned.filter { it.epochDay == d.toEpochDay() }
    Column(Modifier.fillMaxWidth().padding(2.dp).heightIn(min = 56.dp)
        .liquid(RoundedCornerShape(14.dp), if (isSel) C.Blue else Color.Transparent, onClickLabel = Fmt.dateLong(d), onClick = onClick)
        .then(if (isToday && !isSel) Modifier.border(1.5.dp, C.Blue, RoundedCornerShape(14.dp)) else Modifier)
        .semantics { contentDescription = Fmt.dateLong(d) + (if (isToday) ", hoy" else "") + if (list.isEmpty()) ", sin sesiones" else ", ${list.size} sesiones" }
        .padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${d.dayOfMonth}", style = T.Body.copy(color = if (isSel) C.OnColor else C.Text))
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.height(8.dp).padding(top = 2.dp)) {
            list.take(3).forEach { p ->
                val s = p.state()
                Box(Modifier.size(6.dp).clip(CircleShape).background(when {
                    s == PlanState.REST -> if (isSel) C.OnColor.copy(alpha = 0.5f) else C.Grey.copy(alpha = 0.5f)
                    isSel -> C.OnColor
                    else -> stateColor(s)
                }))
            }
        }
    }
}

/** Sesión del día: deporte, nombre, objetivo, intensidad, estado y «Empezar» cuando corresponde. */
@Composable
private fun DaySession(p: PlannedSessionEntity, onStart: () -> Unit, onMore: () -> Unit) {
    val s = p.state()
    val sport = Sport.of(p.sport)
    FCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (s == PlanState.REST) Box(Modifier.size(44.dp).clip(CircleShape).background(C.Control), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Bedtime, null, tint = C.TextSec) } else SportBadge(sport, 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (s == PlanState.REST) "Descanso" else p.name, style = T.BodyStrong)
                Text(listOfNotNull(if (s == PlanState.REST) null else sport.label, stateLabel(s), p.targetMinutes?.let { "$it min" },
                    p.targetKm?.let { "${Fmt.km(it * 1000, 1)} km" },
                    runCatching { Intensity.valueOf(p.intensity).label }.getOrNull()?.takeIf { s != PlanState.REST }).joinToString(" · "), style = T.Label)
                if (p.structure.isNotBlank() && s != PlanState.REST) Text(p.structure, style = T.Label)
            }
            RoundIconButton(Icons.Rounded.MoreHoriz, "Opciones de la sesión", bg = Color.Transparent, tint = C.TextSec, onClick = onMore)
        }
        if (s == PlanState.PENDING || s == PlanState.MISSED) {
            Spacer(Modifier.height(10.dp))
            PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth(), onClick = onStart)
        }
    }
}

@Composable
fun PlannedRow(p: PlannedSessionEntity, onClick: () -> Unit) {
    val s = p.state()
    val sport = Sport.of(p.sport)
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp).liquid(RoundedCornerShape(20.dp), C.Card, onClickLabel = "Opciones de la sesión", onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(contentAlignment = Alignment.BottomEnd) {
            if (s == PlanState.REST) Box(Modifier.size(40.dp).clip(CircleShape).background(C.Control), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Bedtime, null, tint = C.TextSec, modifier = Modifier.size(20.dp)) }
            else SportBadge(sport, 40.dp)
            Box(Modifier.size(12.dp).clip(CircleShape).background(stateColor(s)))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, style = T.BodyStrong)
            Text(listOfNotNull(stateLabel(s), p.targetMinutes?.let { "$it min" }, p.targetKm?.let { "${Fmt.km(it * 1000, 1)} km" },
                runCatching { Intensity.valueOf(p.intensity).label }.getOrNull()?.takeIf { s != PlanState.REST },
                p.reminderMinuteOfDay?.let { "aviso %02d:%02d".format(it / 60, it % 60) }).joinToString(" · "), style = T.Label)
        }
        Icon(Icons.Rounded.MoreHoriz, "Acciones", tint = C.TextSec)
    }
}

/** Panel de acciones de una sesión planificada (fondo desenfocado). */
fun plannedActions(p: PlannedSessionEntity, sheet: SheetController, nav: NavController, scope: kotlinx.coroutines.CoroutineScope, ctx: android.content.Context) {
    val g = FuckrunApp.graph
    val today = LocalDate.now()
    val days = (-3..21).map { today.plusDays(it.toLong()) }
    sheet.show {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            Text(p.name, style = T.Section)
            Text("${Sport.of(p.sport).label} · ${Fmt.dateLong(LocalDate.ofEpochDay(p.epochDay))} · ${stateLabel(p.state())}", style = T.Label)
            if (p.structure.isNotBlank()) Text(p.structure, style = T.Body, modifier = Modifier.padding(top = 6.dp))
        }
        Spacer(Modifier.height(8.dp))
        if (p.type != SessionType.REST.name && p.linkedRunId == null) {
            PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) { sheet.hide(); nav.navigate(Routes.prerun(RunKind.ROUTINE, planned = p.id)) }
            Spacer(Modifier.height(6.dp))
            ListRow("Reducir", "Parte principal un 30 % más corta", leading = Icons.Rounded.Remove) {
                sheet.hide(); scope.launch { g.routines.update(p.copy(targetMinutes = p.targetMinutes?.let { (it * 0.7).toInt().coerceAtLeast(5) }, targetKm = p.targetKm?.let { it * 0.7 },
                    intensity = if (p.intensity == Intensity.MODERATE.name) Intensity.EASY.name else p.intensity)) }
            }
            ListRow("Sustituir por caminata o descanso", leading = Icons.Rounded.SwapHoriz) {
                sheet.pick("Cambiar por", listOf(SessionType.WALK, SessionType.REST), { it.label }, null) { t ->
                    scope.launch { g.routines.update(p.copy(type = t.name, name = t.label, intensity = Intensity.EASY.name,
                        sport = if (t == SessionType.WALK) Sport.WALK.name else p.sport,
                        structure = if (t == SessionType.WALK) "${p.targetMinutes ?: 30} min caminando a paso vivo" else "")) }
                }
            }
            ListRow("Posponer o reprogramar", leading = Icons.Rounded.EventRepeat) {
                sheet.pick("Nuevo día", days.filter { it >= today }, { Fmt.dateLong(it) }, null) { d -> scope.launch { g.routines.reschedule(p, d); Reminders.rescheduleAll(ctx) } }
            }
            ListRow("Recordatorio", p.reminderMinuteOfDay?.let { "%02d:%02d".format(it / 60, it % 60) } ?: "Sin recordatorio", leading = Icons.Rounded.NotificationsNone) {
                sheet.pick("Hora del aviso", listOf<Int?>(null) + (6..22).map { it * 60 }, { it?.let { m -> "%02d:00".format(m / 60) } ?: "Sin recordatorio" }, p.reminderMinuteOfDay) { m ->
                    scope.launch { g.routines.update(p.copy(reminderMinuteOfDay = m)); Reminders.rescheduleAll(ctx) }
                }
            }
        }
        ListRow("Editar", leading = Icons.Rounded.Edit) {
            scope.launch {
                val rs = g.routines.routines().first()
                sheet.page("Editar sesión") { PlannedEditor(p, rs, LocalDate.ofEpochDay(p.epochDay)) { sheet.hide() } }
            }
        }
        ListRow("Duplicar", leading = Icons.Rounded.ContentCopy) {
            sheet.pick("Duplicar en", days, { Fmt.dateLong(it) }, null) { d -> scope.launch { g.routines.duplicate(p, d) } }
        }
        ListRow("Eliminar", leading = Icons.Rounded.DeleteOutline, leadingTint = C.Red) {
            sheet.confirm("¿Eliminar sesión?", "Si estaba vinculada a una actividad, la actividad se conserva en tu historial.", "Eliminar", C.Red) {
                scope.launch { g.routines.delete(p.id) }
            }
        }
    }
}

/** Formulario de sesión planificada: nombre, día, tipo, objetivo, intensidad, ruta opcional. */
@Composable
fun PlannedEditor(existing: PlannedSessionEntity?, routines: List<RoutineEntity>, day0: LocalDate, onDone: () -> Unit) {
    val g = FuckrunApp.graph
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name ?: "Rodaje suave") }
    var type by remember { mutableStateOf(existing?.type?.let { runCatching { SessionType.valueOf(it) }.getOrNull() } ?: SessionType.EASY) }
    var day by remember { mutableStateOf(day0) }
    var minutes by remember { mutableStateOf(existing?.targetMinutes?.toString() ?: "30") }
    var km by remember { mutableStateOf(existing?.targetKm?.toString() ?: "") }
    var intensity by remember { mutableStateOf(existing?.intensity?.let { runCatching { Intensity.valueOf(it) }.getOrNull() } ?: Intensity.EASY) }
    var routineId by remember { mutableStateOf(existing?.routineId ?: routines.first().id) }
    var routeId by remember { mutableStateOf(existing?.routeId) }
    var showDays by remember { mutableStateOf(false) }
    var sport by remember { mutableStateOf(Sport.of(existing?.sport)) }

    Field(name, "Nombre", singleLine = true) { name = it }
    Spacer(Modifier.height(10.dp))
    SportSelector(sport) { sport = it }
    Spacer(Modifier.height(10.dp))
    ListRow("Día", Fmt.dateLong(day), leading = Icons.Rounded.Event) { showDays = !showDays }
    if (showDays) ChoiceChips((-7..28).map { LocalDate.now().plusDays(it.toLong()) }, { "${Fmt.dayShort(it.dayOfWeek)} ${it.dayOfMonth}/${it.monthValue}" }, { it == day }) { day = it; showDays = false }
    Text("Tipo", style = T.Label, modifier = Modifier.padding(top = 8.dp))
    ChoiceChips(SessionType.entries.filter { it != SessionType.FREE }, { it.label }, { it == type }) { type = it }
    if (type != SessionType.REST) {
        Text("Objetivo de tiempo (min) y/o distancia (km)", style = T.Label, modifier = Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { Field(minutes, "min", singleLine = true) { minutes = it.filter(Char::isDigit).take(3) } }
            Box(Modifier.weight(1f)) { Field(km, "km (opcional)", singleLine = true) { km = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(5) } }
        }
        Text("Intensidad", style = T.Label, modifier = Modifier.padding(top = 8.dp))
        ChoiceChips(Intensity.entries, { it.label }, { it == intensity }) { intensity = it }
        // Rutas guardadas (estrella) aptas para el deporte, más la ya elegida.
        val favIds by remember { g.db.favorites().all() }.collectAsStateWithLifecycle(emptyList())
        val routes = (favIds.mapNotNull { g.routes.byId(it.routeId) } + listOfNotNull(g.routes.byId(routeId))).distinctBy { it.id }.filter { sport in routeSports(it) }
        if (routes.isNotEmpty()) {
            Text("Ruta (opcional)", style = T.Label, modifier = Modifier.padding(top = 8.dp))
            ChoiceChips(listOf<String?>(null) + routes.map { it.id }, { id -> id?.let { g.routes.byId(it)?.name } ?: "Ninguna" }, { it == routeId }) { routeId = it }
        }
    }
    if (routines.size > 1) {
        Text("Rutina", style = T.Label, modifier = Modifier.padding(top = 8.dp))
        ChoiceChips(routines, { it.name }, { it.id == routineId }) { routineId = it.id }
    }
    Spacer(Modifier.height(16.dp))
    PillButton("Guardar", color = C.Green, modifier = Modifier.fillMaxWidth(), enabled = name.isNotBlank()) {
        scope.launch {
            val e = (existing ?: PlannedSessionEntity(routineId = routineId, name = name, epochDay = day.toEpochDay(), type = type.name)).copy(
                routineId = routineId, name = name.trim(), epochDay = day.toEpochDay(), type = type.name,
                targetMinutes = if (type == SessionType.REST) null else minutes.toIntOrNull(),
                targetKm = if (type == SessionType.REST) null else km.replace(',', '.').toDoubleOrNull(),
                intensity = intensity.name, routeId = routeId, sport = sport.name)
            if (existing == null) g.routines.add(e) else g.routines.update(e)
            onDone()
        }
    }
}

@Composable
private fun MonthGrid(month: YearMonth, planned: List<PlannedSessionEntity>, onDay: (LocalDate) -> Unit) {
    val byDay = planned.groupBy { it.epochDay }
    FCard {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp)) { DayOfWeek.values().forEach { Text(Fmt.dayShort(it).take(1), style = T.Label, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) } }
        val first = month.atDay(1); val offset = first.dayOfWeek.value - 1
        (0 until (offset + month.lengthOfMonth() + 6) / 7).forEach { w ->
            Row(Modifier.fillMaxWidth()) {
                (0..6).forEach { c ->
                    val idx = w * 7 + c - offset
                    Column(Modifier.weight(1f).padding(vertical = 6.dp).clip(RoundedCornerShape(10.dp))
                        .tap(enabled = idx in 0 until month.lengthOfMonth()) { onDay(first.plusDays(idx.toLong())) },
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        if (idx in 0 until month.lengthOfMonth()) {
                            val d = first.plusDays(idx.toLong())
                            Text("${idx + 1}", style = T.Label.copy(color = if (d == LocalDate.now()) C.Text else C.TextSec))
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.height(8.dp)) {
                                byDay[d.toEpochDay()].orEmpty().take(3).forEach { p ->
                                    val s = p.state()
                                    Box(Modifier.size(6.dp).clip(CircleShape).background(if (s == PlanState.REST) Color.Transparent else stateColor(s)))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
