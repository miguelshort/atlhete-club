package app.fuckrun.ui.theme

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.fuckrun.R
import app.fuckrun.data.Appearance

/**
 * Paleta de Athlete Club en dos variantes. Los valores se leen a través de [C] desde un estado observable,
 * así que cambiar de tema recompone la interfaz en el sitio (sin recrear la actividad ni perder formularios).
 *
 * Significados fijos, en cualquier deporte y tema:
 *  - Green: Empezar / Reanudar.  - Red: Pausar.  - Blue: Terminar.  - Chart (#6C8CFF): gráficas de progreso.
 */
data class Palette(
    val dark: Boolean,
    val bg: Color, val surface: Color, val card: Color, val control: Color,
    val text: Color, val textSec: Color, val border: Color, val grey: Color,
    val green: Color, val red: Color, val blue: Color, val onColor: Color, val chart: Color,
    val coral: Color, val forest: Color, val sky: Color, val amber: Color,
    val glassTint: Color, val glassFallback: Color, val edgeTop: Color, val edgeBottom: Color, val scrim: Color,
)

val DarkPalette = Palette(
    dark = true,
    bg = Color(0xFF0B0C0F), surface = Color(0xFF15171C), card = Color(0xFF1B1E24), control = Color(0xFF262A32),
    text = Color(0xFFF5F6F8), textSec = Color(0xFFA2A8B3), border = Color(0x1FFFFFFF), grey = Color(0xFF545B67),
    green = Color(0xFF34C77B), red = Color(0xFFFF5A5F), blue = Color(0xFF4C8DFF), onColor = Color(0xFF0B0C0F), chart = Color(0xFF6C8CFF),
    coral = Color(0xFFFF805F), forest = Color(0xFF36A572), sky = Color(0xFF579AFF), amber = Color(0xFFF5B844),
    glassTint = Color(0xFF15171C).copy(alpha = 0.30f), glassFallback = Color(0xFF1B1E24).copy(alpha = 0.94f),
    edgeTop = Color.White.copy(alpha = 0.30f), edgeBottom = Color.White.copy(alpha = 0.06f), scrim = Color.Black.copy(alpha = 0.40f),
)

val LightPalette = Palette(
    dark = false,
    bg = Color(0xFFF6F8FB), surface = Color(0xFFFFFFFF), card = Color(0xFFEDF0F6), control = Color(0xFFE1E5EC),
    text = Color(0xFF0E1116), textSec = Color(0xFF5A6170), border = Color(0x14000000), grey = Color(0xFFA7AEBA),
    green = Color(0xFF178A4C), red = Color(0xFFD63A40), blue = Color(0xFF1F6FEB), onColor = Color(0xFFFFFFFF), chart = Color(0xFF6C8CFF),
    coral = Color(0xFFD4532F), forest = Color(0xFF23804F), sky = Color(0xFF2F6FD6), amber = Color(0xFF9E6C06),
    glassTint = Color.White.copy(alpha = 0.42f), glassFallback = Color.White.copy(alpha = 0.94f),
    edgeTop = Color.White.copy(alpha = 0.95f), edgeBottom = Color.Black.copy(alpha = 0.06f), scrim = Color.Black.copy(alpha = 0.22f),
)

/** Estado de tema observable por Compose. Se actualiza desde [AthleteTheme]. */
object ThemeState {
    var palette by mutableStateOf(DarkPalette)
}

/** Colores semánticos. Getters: siempre devuelven la variante del tema activo. */
object C {
    private val p get() = ThemeState.palette
    val isDark get() = p.dark
    val Bg get() = p.bg
    val Surface get() = p.surface
    val Card get() = p.card
    val Control get() = p.control
    val Text get() = p.text
    val TextSec get() = p.textSec
    val Border get() = p.border
    val Grey get() = p.grey
    /** Empezar / Reanudar. */
    val Green get() = p.green
    /** Pausar. */
    val Red get() = p.red
    /** Terminar. */
    val Blue get() = p.blue
    /** Texto e iconos sobre botones de color. */
    val OnColor get() = p.onColor
    /** Gráficas de progreso. */
    val Chart get() = p.chart
    val Coral get() = p.coral
    val Forest get() = p.forest
    val Sky get() = p.sky
    val Amber get() = p.amber
    val GlassTint get() = p.glassTint
    val GlassFallback get() = p.glassFallback
    val EdgeTop get() = p.edgeTop
    val EdgeBottom get() = p.edgeBottom
    val Scrim get() = p.scrim
}

/** Solo Inter Regular: si algún estilo pidiera otro peso, no hay variante con la que sintetizarlo por error. */
val Inter = FontFamily(Font(R.font.inter_regular, FontWeight.Normal))

/** −80 milésimas de eme en TODOS los textos. */
val TightSpacing = (-0.08).em
private const val TNUM = "tnum"

private fun style(size: Int, line: Int? = null, color: Color = C.Text, tabular: Boolean = false) = TextStyle(
    fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = size.sp,
    lineHeight = (line ?: (size * 1.3f).toInt().coerceAtLeast(size + 4)).sp,
    letterSpacing = TightSpacing, color = color, fontFeatureSettings = if (tabular) TNUM else null,
)

/**
 * Estilos. Un único peso (400). La jerarquía sale del tamaño, el espacio, la posición y el color.
 * Getters para que el color siga al tema.
 */
object T {
    val RunMetric get() = style(72, 76, tabular = true)
    val HomeFigure get() = style(44, 50, tabular = true)
    val ScreenTitle get() = style(30, 36)
    val Section get() = style(21, 27)
    val Body get() = style(16, 22)
    val BodyStrong get() = style(17, 23)
    val Label get() = style(13, 18, color = C.TextSec)
    val Number get() = style(22, 28, tabular = true)
    val SmallNumber get() = style(15, 20, tabular = true)
}

@Composable
fun AthleteTheme(appearance: Appearance, content: @Composable () -> Unit) {
    val system = isSystemInDarkTheme()
    val dark = when (appearance) { Appearance.DARK -> true; Appearance.LIGHT -> false; Appearance.AUTO -> system }
    val palette = if (dark) DarkPalette else LightPalette
    // Escritura antes de que los hijos lean C.*: el primer fotograma ya sale con el tema correcto.
    remember(palette) { ThemeState.palette = palette; palette }

    val activity = LocalContext.current as? ComponentActivity
    LaunchedEffect(dark, activity) {
        val t = Color.Transparent.toArgb()
        activity?.enableEdgeToEdge(
            statusBarStyle = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t),
            navigationBarStyle = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t),
        )
    }

    val body = T.Body
    val typography = Typography(
        displayLarge = T.RunMetric, displayMedium = T.HomeFigure, displaySmall = style(36, 44),
        headlineLarge = T.ScreenTitle, headlineMedium = T.ScreenTitle, headlineSmall = T.Section,
        titleLarge = T.Section, titleMedium = T.BodyStrong, titleSmall = body,
        bodyLarge = body, bodyMedium = style(15, 21), bodySmall = T.Label,
        labelLarge = style(15, 20), labelMedium = T.Label, labelSmall = style(12, 16, color = C.TextSec),
    )
    val scheme = if (dark) darkColorScheme(
        primary = C.Blue, onPrimary = C.OnColor, secondary = C.Green, onSecondary = C.OnColor,
        error = C.Red, onError = C.OnColor, background = C.Bg, onBackground = C.Text,
        surface = C.Surface, onSurface = C.Text, surfaceVariant = C.Card, onSurfaceVariant = C.TextSec,
        outline = C.Control, surfaceContainerHigh = C.Card, surfaceContainer = C.Surface,
    ) else lightColorScheme(
        primary = C.Blue, onPrimary = C.OnColor, secondary = C.Green, onSecondary = C.OnColor,
        error = C.Red, onError = C.OnColor, background = C.Bg, onBackground = C.Text,
        surface = C.Surface, onSurface = C.Text, surfaceVariant = C.Card, onSurfaceVariant = C.TextSec,
        outline = C.Control, surfaceContainerHigh = C.Card, surfaceContainer = C.Surface,
    )
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
