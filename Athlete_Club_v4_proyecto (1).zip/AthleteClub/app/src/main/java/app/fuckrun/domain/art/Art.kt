package app.fuckrun.domain.art

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * Primitivas de la ilustración 2D (Kotlin puro, sin Android).
 * El mismo dibujo lo ejecuta Compose en la app (ui/components/ArtRenderer.kt) y el exportador SVG de las pruebas
 * (hojas de modelo e inventario): lo que se ve en las láminas es exactamente lo que se equipa en el móvil.
 *
 * Coordenadas: lienzo de 200 × 400 unidades, y hacia abajo, luz desde arriba a la izquierda.
 */

data class P(val x: Float, val y: Float) {
    operator fun plus(o: P) = P(x + o.x, y + o.y)
    operator fun minus(o: P) = P(x - o.x, y - o.y)
    operator fun times(k: Float) = P(x * k, y * k)
    fun len() = sqrt(x * x + y * y)
    fun norm(): P { val l = len(); return if (l < 1e-5f) P(0f, 0f) else P(x / l, y / l) }
    /** Perpendicular (girada 90° en sentido horario en pantalla). */
    fun perp() = P(-y, x)
    fun lerp(o: P, t: Float) = P(x + (o.x - x) * t, y + (o.y - y) * t)
    fun angle() = atan2(y, x)
}

fun p(x: Number, y: Number) = P(x.toFloat(), y.toFloat())
/** Dirección para un ángulo medido desde la vertical hacia abajo (positivo = hacia la derecha de la pantalla). */
fun dirDown(a: Float) = P(sin(a), cos(a))

sealed interface Cmd {
    data class M(val p: P) : Cmd
    data class L(val p: P) : Cmd
    data class Q(val c: P, val p: P) : Cmd
    data class C(val c1: P, val c2: P, val p: P) : Cmd
    data object Z : Cmd
}

class Path(val cmds: MutableList<Cmd> = mutableListOf()) {
    fun moveTo(p: P) = apply { cmds += Cmd.M(p) }
    fun lineTo(p: P) = apply { cmds += Cmd.L(p) }
    fun quadTo(c: P, p: P) = apply { cmds += Cmd.Q(c, p) }
    fun cubicTo(c1: P, c2: P, p: P) = apply { cmds += Cmd.C(c1, c2, p) }
    fun close() = apply { cmds += Cmd.Z }
    fun add(o: Path) = apply { cmds += o.cmds }

    fun map(f: (P) -> P) = Path(cmds.map {
        when (it) { is Cmd.M -> Cmd.M(f(it.p)); is Cmd.L -> Cmd.L(f(it.p)); is Cmd.Q -> Cmd.Q(f(it.c), f(it.p))
            is Cmd.C -> Cmd.C(f(it.c1), f(it.c2), f(it.p)); Cmd.Z -> Cmd.Z }
    }.toMutableList())
    fun translate(dx: Float, dy: Float) = map { P(it.x + dx, it.y + dy) }
    /** Escala alrededor de un punto. */
    fun scale(c: P, sx: Float, sy: Float = sx) = map { P(c.x + (it.x - c.x) * sx, c.y + (it.y - c.y) * sy) }
    fun mirrorX(cx: Float) = map { P(2 * cx - it.x, it.y) }

    fun points(): List<P> = cmds.flatMap { when (it) { is Cmd.M -> listOf(it.p); is Cmd.L -> listOf(it.p); is Cmd.Q -> listOf(it.c, it.p)
        is Cmd.C -> listOf(it.c1, it.c2, it.p); Cmd.Z -> emptyList() } }

    companion object {
        private const val K = 0.5523f
        fun ellipse(c: P, rx: Float, ry: Float) = Path()
            .moveTo(P(c.x + rx, c.y))
            .cubicTo(P(c.x + rx, c.y + ry * K), P(c.x + rx * K, c.y + ry), P(c.x, c.y + ry))
            .cubicTo(P(c.x - rx * K, c.y + ry), P(c.x - rx, c.y + ry * K), P(c.x - rx, c.y))
            .cubicTo(P(c.x - rx, c.y - ry * K), P(c.x - rx * K, c.y - ry), P(c.x, c.y - ry))
            .cubicTo(P(c.x + rx * K, c.y - ry), P(c.x + rx, c.y - ry * K), P(c.x + rx, c.y)).close()
        fun circle(c: P, r: Float) = ellipse(c, r, r)
        fun rect(l: Float, t: Float, r: Float, b: Float) = Path().moveTo(P(l, t)).lineTo(P(r, t)).lineTo(P(r, b)).lineTo(P(l, b)).close()
        fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float): Path {
            val k = rad * (1 - K)
            return Path().moveTo(P(l + rad, t)).lineTo(P(r - rad, t)).cubicTo(P(r - k, t), P(r, t + k), P(r, t + rad))
                .lineTo(P(r, b - rad)).cubicTo(P(r, b - k), P(r - k, b), P(r - rad, b))
                .lineTo(P(l + rad, b)).cubicTo(P(l + k, b), P(l, b - k), P(l, b - rad))
                .lineTo(P(l, t + rad)).cubicTo(P(l, t + k), P(l + k, t), P(l + rad, t)).close()
        }
        fun poly(vararg pts: P) = Path().also { pth -> pts.forEachIndexed { i, q -> if (i == 0) pth.moveTo(q) else pth.lineTo(q) }; pth.close() }
        fun line(vararg pts: P) = Path().also { pth -> pts.forEachIndexed { i, q -> if (i == 0) pth.moveTo(q) else pth.lineTo(q) } }

        /**
         * Segmento de miembro con grosor variable (hombro → codo, rodilla → tobillo…). Extremos redondeados y una
         * ligera curva hacia fuera en el lado del músculo para que no parezca un tubo.
         */
        fun limb(a: P, b: P, wa: Float, wb: Float, bulge: Float = 0.12f): Path {
            val d = (b - a).norm(); val n = d.perp()
            val m = a.lerp(b, 0.42f); val wm = (wa + wb) / 2 * (1 + bulge)
            val a1 = a + n * (wa / 2); val a2 = a - n * (wa / 2)
            val b1 = b + n * (wb / 2); val b2 = b - n * (wb / 2)
            val m1 = m + n * (wm / 2); val m2 = m - n * (wm / 2)
            return Path().moveTo(a1).quadTo(m1 + (m1 - a1.lerp(b1, 0.42f)), b1)
                .cubicTo(b1 + d * (wb * 0.55f), b2 + d * (wb * 0.55f), b2)
                .quadTo(m2 + (m2 - a2.lerp(b2, 0.42f)), a2)
                .cubicTo(a2 - d * (wa * 0.55f), a1 - d * (wa * 0.55f), a1).close()
        }

        /** Curva suave que pasa por los puntos (Catmull-Rom → Bézier), abierta o cerrada. */
        fun smooth(pts: List<P>, closed: Boolean): Path {
            val pth = Path()
            if (pts.size < 2) return pth
            val n = pts.size
            fun at(i: Int) = if (closed) pts[(i + n) % n] else pts[i.coerceIn(0, n - 1)]
            pth.moveTo(pts[0])
            val last = if (closed) n else n - 1
            for (i in 0 until last) {
                val p0 = at(i - 1); val p1 = at(i); val p2 = at(i + 1); val p3 = at(i + 2)
                pth.cubicTo(p1 + (p2 - p0) * (1f / 6f), p2 - (p3 - p1) * (1f / 6f), p2)
            }
            if (closed) pth.close()
            return pth
        }
    }
}

/** Colores ARGB. */
object Col {
    fun rgb(hex: Long) = 0xFF000000 or (hex and 0xFFFFFF)
    fun a(c: Long) = ((c ushr 24) and 0xFF).toInt()
    fun r(c: Long) = ((c ushr 16) and 0xFF).toInt()
    fun g(c: Long) = ((c ushr 8) and 0xFF).toInt()
    fun b(c: Long) = (c and 0xFF).toInt()
    fun of(r: Int, g: Int, b: Int, a: Int = 255) = (a.toLong().coerceIn(0, 255) shl 24) or (r.toLong().coerceIn(0, 255) shl 16) or
        (g.toLong().coerceIn(0, 255) shl 8) or b.toLong().coerceIn(0, 255)
    fun mix(x: Long, y: Long, t: Float) = of((r(x) + (r(y) - r(x)) * t).toInt(), (g(x) + (g(y) - g(x)) * t).toInt(), (b(x) + (b(y) - b(x)) * t).toInt(),
        (a(x) + (a(y) - a(x)) * t).toInt())
    /** Sombra recortada: más oscura y algo más saturada/fría (sin negro puro, que apaga la piel). */
    fun shade(c: Long, k: Float = 0.24f) = mix(c, of((r(c) * 0.55).toInt(), (g(c) * 0.5).toInt(), (b(c) * 0.62).toInt()), k / 0.24f * 0.6f)
    fun light(c: Long, k: Float = 0.18f) = mix(c, 0xFFFFFFFF, k)
    fun ink(c: Long) = mix(c, 0xFF15110F, 0.62f)
    fun lum(c: Long) = (0.2126 * r(c) + 0.7152 * g(c) + 0.0722 * b(c)) / 255.0
    fun hex(c: Long) = "#%02x%02x%02x".format(r(c), g(c), b(c))
}

sealed interface Op {
    data class Fill(val path: Path, val color: Long) : Op
    data class Stroke(val path: Path, val color: Long, val width: Float) : Op
    /** Dibujo recortado: dentro de [clip] (si hay) y fuera de [clipOut] (si hay). Máscaras de casco, pelo, calcetines… */
    data class Group(val ops: List<Op>, val clip: Path? = null, val clipOut: Path? = null) : Op
}

class Drawing {
    val ops = mutableListOf<Op>()
    fun fill(path: Path, color: Long) { ops += Op.Fill(path, color) }
    fun stroke(path: Path, color: Long, width: Float) { ops += Op.Stroke(path, color, width) }
    fun group(clip: Path? = null, clipOut: Path? = null, block: Drawing.() -> Unit) {
        val d = Drawing().apply(block); if (d.ops.isNotEmpty()) ops += Op.Group(d.ops, clip, clipOut)
    }

    /**
     * Pieza con volumen: color base, sombra recortada (lado opuesto a la luz), acento de luz en el canto iluminado y
     * línea exterior con más peso en la sombra que se afina hacia la luz.
     */
    fun solid(shape: Path, base: Long, line: Float = 1.6f, shadow: Float = 0.22f, depth: Float = 5f, accent: Boolean = true, outline: Long? = null) {
        fill(shape, base)
        group(clip = shape, clipOut = shape.translate(-depth, -depth * 0.7f)) { fill(shape, Col.shade(base, shadow)) }
        if (accent) group(clip = shape, clipOut = shape.translate(depth * 0.35f, depth * 0.28f)) { fill(shape, Col.mix(base, 0xFFFFFFFF, 0.16f)) }
        if (line > 0f) {
            val ink = outline ?: Col.ink(base)
            stroke(shape, ink, line * 0.7f)
            // Refuerzo en el lado en sombra (abajo-derecha).
            group(clipOut = shape.translate(-line * 1.1f, -line * 0.9f)) { stroke(shape, ink, line * 1.35f) }
        }
    }

    fun bounds(): FloatArray? {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        fun visit(o: List<Op>) { for (op in o) when (op) {
            is Op.Fill -> op.path.points().forEach { l = minOf(l, it.x); t = minOf(t, it.y); r = maxOf(r, it.x); b = maxOf(b, it.y) }
            is Op.Stroke -> op.path.points().forEach { l = minOf(l, it.x - op.width); t = minOf(t, it.y - op.width); r = maxOf(r, it.x + op.width); b = maxOf(b, it.y + op.width) }
            is Op.Group -> if (op.clip != null) op.clip.points().forEach { l = minOf(l, it.x); t = minOf(t, it.y); r = maxOf(r, it.x); b = maxOf(b, it.y) } else visit(op.ops)
        } }
        visit(ops)
        return if (l > r) null else floatArrayOf(l, t, r, b)
    }
}

fun angleOf(from: P, to: P) = (to - from).angle()
fun rot(p0: P, c: P, a: Float): P { val s = sin(a); val co = cos(a); val d = p0 - c; return P(c.x + d.x * co - d.y * s, c.y + d.x * s + d.y * co) }
