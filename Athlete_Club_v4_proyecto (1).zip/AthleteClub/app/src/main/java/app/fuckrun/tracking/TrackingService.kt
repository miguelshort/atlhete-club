package app.fuckrun.tracking

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import app.fuckrun.FuckrunApp
import app.fuckrun.MainActivity
import app.fuckrun.R
import app.fuckrun.data.db.*
import app.fuckrun.data.toSample
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.Sport
import app.fuckrun.domain.metrics.RunMetrics
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class SignalQuality(val label: String) { NONE("Sin señal"), WEAK("Señal débil"), OK("Señal aceptable"), GOOD("Señal buena") }
enum class Warning(val text: String) {
    SIGNAL_LOST("Sin señal GPS: el tramo sin datos no se dibujará como recorrido."),
    GPS_OFF("La ubicación está desactivada. Actívala para seguir registrando."),
    PERMISSION_LOST("Se ha retirado el permiso de ubicación. La captura está detenida."),
    BATTERY_LOW("Batería baja. La sesión sigue grabando."),
    TIME_CHANGED("Ha cambiado la hora del sistema. Los tiempos se miden con un reloj interno y no se ven afectados."),
}

fun signalFor(accuracy: Float?): SignalQuality = when {
    accuracy == null -> SignalQuality.NONE
    accuracy <= 10f -> SignalQuality.GOOD
    accuracy <= RunMetrics.MAX_ACCURACY_M -> SignalQuality.OK
    else -> SignalQuality.WEAK
}

data class LiveRun(
    val runId: Long,
    val status: String,
    val signal: SignalQuality,
    val stats: RunMetrics.Stats?,
    val warnings: Set<Warning>,
    val kindLabel: String,
    val sport: Sport = Sport.RUN,
    /** Todavía no ha llegado el primer punto: se muestra «Buscando señal». */
    val waitingFirstFix: Boolean = false,
)

/** Resultado del arranque, para que la preparación solo abra el registro tras la confirmación de inicio. */
sealed interface StartState {
    data object Idle : StartState
    data object Starting : StartState
    data class Started(val runId: Long) : StartState
    data class Failed(val reason: StartFailure) : StartState
}

enum class StartFailure(val message: String, val action: String) {
    PERMISSION("Athlete Club necesita tu ubicación para dibujar el recorrido.", "Permitir ubicación"),
    APPROXIMATE("Tienes la ubicación aproximada: el recorrido saldría impreciso. Activa la ubicación precisa.", "Permitir ubicación precisa"),
    GPS_OFF("La ubicación del móvil está desactivada.", "Abrir ajustes"),
    NOT_ALLOWED("El sistema no ha permitido iniciar el registro en este momento. Vuelve a la app y reinténtalo.", "Reintentar"),
    ERROR("No se ha podido iniciar el registro. No se ha creado ninguna actividad.", "Reintentar"),
}

/** Estado observable del registro en curso. */
object Tracking {
    internal val _live = MutableStateFlow<LiveRun?>(null)
    val live = _live.asStateFlow()
    internal val _ended = MutableStateFlow<Long?>(null)
    /** id de la sesión recién terminada, pendiente de guardar o descartar. */
    val ended = _ended.asStateFlow()
    fun consumeEnded() { _ended.value = null }

    internal val _start = MutableStateFlow<StartState>(StartState.Idle)
    val startState = _start.asStateFlow()
    fun resetStart() { if (_start.value !is StartState.Starting) _start.value = StartState.Idle }

    const val ACTION_START = "start"; const val ACTION_CONTINUE = "continue"
    const val ACTION_PAUSE = "pause"; const val ACTION_RESUME = "resume"; const val ACTION_STOP = "stop"

    /**
     * Pide iniciar una sesión. Devuelve false (y deja el motivo en [startState]) si no se puede intentar.
     * Un segundo toque mientras se inicia, o con una sesión ya en marcha, no crea otra actividad.
     */
    fun start(ctx: Context, sport: Sport, kind: String, plannedId: Long? = null, routeId: String? = null, sharedId: String? = null, sharedName: String? = null): Boolean {
        if (_start.value is StartState.Starting || _live.value != null) return false
        if (!hasLocationPermission(ctx)) { _start.value = StartState.Failed(if (hasCoarsePermission(ctx)) StartFailure.APPROXIMATE else StartFailure.PERMISSION); return false }
        _start.value = StartState.Starting
        val ok = send(ctx, ACTION_START) { putExtra("sport", sport.name); putExtra("kind", kind); plannedId?.let { putExtra("planned", it) }; putExtra("route", routeId)
            putExtra("shared", sharedId); putExtra("sharedName", sharedName) }
        if (!ok) _start.value = StartState.Failed(StartFailure.NOT_ALLOWED)
        return ok
    }
    fun continueRun(ctx: Context, runId: Long) = send(ctx, ACTION_CONTINUE) { putExtra("runId", runId) }
    fun pause(ctx: Context) = send(ctx, ACTION_PAUSE) {}
    fun resume(ctx: Context) = send(ctx, ACTION_RESUME) {}
    fun stop(ctx: Context) = send(ctx, ACTION_STOP) {}

    /**
     * Nunca lanza: si el sistema impide arrancar el servicio (p. ej. ForegroundServiceStartNotAllowedException
     * al intentarlo con la app en segundo plano), devuelve false y la interfaz ofrece «Reintentar».
     */
    private fun send(ctx: Context, action: String, extras: Intent.() -> Unit): Boolean = try {
        val i = Intent(ctx, TrackingService::class.java).setAction(action).apply(extras)
        if (action == ACTION_START || action == ACTION_CONTINUE) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
        true
    } catch (e: IllegalStateException) { false } catch (e: SecurityException) { false }

    /** Ubicación precisa concedida. */
    fun hasLocationPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    /** Al menos ubicación aproximada. */
    fun hasCoarsePermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
}

/**
 * Servicio en primer plano de tipo "location". Solo existe mientras hay una sesión iniciada por el usuario:
 * se detiene al terminar o descartar. No se reinicia solo (START_NOT_STICKY): si el sistema lo cierra,
 * la app ofrece recuperar lo guardado la próxima vez que se abra.
 */
class TrackingService : LifecycleService() {
    private val graph get() = FuckrunApp.graph
    private val repo get() = graph.runs
    private lateinit var lm: LocationManager
    private val mutex = Mutex()

    private var active: RunEntity? = null
    private val events = mutableListOf<EventEntity>()
    private val samples = mutableListOf<RunMetrics.Sample>()
    private var lastFix: Location? = null
    private var lastFixMono = 0L
    private var gapRefMono = 0L      // referencia para detectar huecos (último fijo o reanudación)
    private var signalLostFlag = false
    private val warnings = mutableSetOf<Warning>()
    private var ticker: Job? = null
    private var listening = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) { lifecycleScope.launch { onFix(loc) } }
        override fun onProviderDisabled(provider: String) { lifecycleScope.launch { onGpsOff() } }
        override fun onProviderEnabled(provider: String) { warnings.remove(Warning.GPS_OFF); publish() }
        @Deprecated("Deprecated in API") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
    }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = active?.id ?: return
            lifecycleScope.launch {
                when (i.action) {
                    Intent.ACTION_BATTERY_LOW -> { warnings += Warning.BATTERY_LOW; logEvent(EventType.BATTERY_LOW); alert(Warning.BATTERY_LOW) }
                    Intent.ACTION_BATTERY_OKAY -> warnings -= Warning.BATTERY_LOW
                    Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> { warnings += Warning.TIME_CHANGED; logEvent(EventType.TIME_CHANGED, i.action ?: "") }
                }
                publish()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LocationManager::class.java)
        val f = IntentFilter().apply { addAction(Intent.ACTION_BATTERY_LOW); addAction(Intent.ACTION_BATTERY_OKAY)
            addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED) }
        ContextCompat.registerReceiver(this, systemReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent == null) { stopSelf(); return START_NOT_STICKY }   // reinicio sin intención explícita: no rastrear
        when (intent.action) {
            Tracking.ACTION_START, Tracking.ACTION_CONTINUE -> {
                // 1) Primer plano inmediatamente (antes de 5 s) y con el tipo «location». Si el sistema lo impide
                //    (permiso retirado, app no visible…), se informa y NO se crea ninguna actividad.
                val fg = try { goForeground("Preparando el registro…"); null }
                    catch (e: SecurityException) { StartFailure.PERMISSION }
                    catch (e: IllegalStateException) { StartFailure.NOT_ALLOWED }   // incluye ForegroundServiceStartNotAllowedException
                    catch (e: RuntimeException) { StartFailure.ERROR }
                if (fg != null) {
                    Tracking._start.value = StartState.Failed(fg)
                    if (active == null) stopSelf()
                    return START_NOT_STICKY
                }
                lifecycleScope.launch {
                    var createdId: Long? = null
                    try {
                        mutex.withLock {
                            if (intent.action == Tracking.ACTION_START && active != null) {
                                // Doble toque o reintento con una sesión ya abierta: se mantiene la existente.
                                Tracking._start.value = StartState.Started(active!!.id); return@withLock
                            }
                            val id = if (intent.action == Tracking.ACTION_START) repo.startRun(
                                Sport.of(intent.getStringExtra("sport")),
                                intent.getStringExtra("kind") ?: RunKind.FREE,
                                intent.getLongExtra("planned", -1).takeIf { it > 0 },
                                intent.getStringExtra("route"), intent.getStringExtra("shared"), intent.getStringExtra("sharedName"),
                            ).also { createdId = it } else intent.getLongExtra("runId", -1)
                            load(id)
                            if (active == null) throw IllegalStateException("Sesión no encontrada")
                            if (intent.action == Tracking.ACTION_CONTINUE) resumeInternal()
                            Tracking._start.value = StartState.Started(id)
                        }
                        startLocation()
                        startTicker()
                        updateNotification()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // Libera recursos y no deja actividades vacías.
                        stopLocation(); ticker?.cancel()
                        createdId?.let { runCatching { repo.discard(it) } }
                        active = null; Tracking._live.value = null
                        Tracking._start.value = StartState.Failed(StartFailure.ERROR)
                        ServiceCompat.stopForeground(this@TrackingService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }
            Tracking.ACTION_PAUSE -> lifecycleScope.launch { mutex.withLock { pauseInternal() } }
            Tracking.ACTION_RESUME -> lifecycleScope.launch { mutex.withLock { resumeInternal() } }
            Tracking.ACTION_STOP -> lifecycleScope.launch { mutex.withLock { stopInternal() } }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private suspend fun load(id: Long) {
        active = repo.get(id)
        events.clear(); events += repo.events(id)
        samples.clear(); samples += repo.points(id).map { it.toSample() }
        gapRefMono = repo.clock.mono()
        publish()
    }

    private fun goForeground(text: String) {
        ServiceCompat.startForeground(this, NOTIF_ID, notification(text),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0)
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (listening) return
        if (!Tracking.hasLocationPermission(this)) { lifecycleScope.launch { onPermissionLost() }; return }
        // GPS si existe; si el dispositivo no lo tiene, proveedor combinado (Android 12+) o de red. Nunca lanza.
        val providers = buildList {
            add(LocationManager.GPS_PROVIDER)
            if (Build.VERSION.SDK_INT >= 31) add(LocationManager.FUSED_PROVIDER)
            add(LocationManager.NETWORK_PROVIDER)
        }.filter { runCatching { lm.allProviders.contains(it) }.getOrDefault(false) }
        if (runCatching { !lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(true)) lifecycleScope.launch { onGpsOff() }
        for (p in providers) {
            try {
                lm.requestLocationUpdates(p, 1000L, 0f, listener, Looper.getMainLooper())
                listening = true
                return
            } catch (e: SecurityException) { lifecycleScope.launch { onPermissionLost() }; return }
            catch (e: IllegalArgumentException) { /* proveedor no disponible: siguiente */ }
        }
    }

    private fun stopLocation() { if (listening) runCatching { lm.removeUpdates(listener) }; listening = false }

    private suspend fun logEvent(type: String, detail: String = "") {
        val r = active ?: return
        val e = EventEntity(runId = r.id, type = type, wallMs = repo.clock.wall(), monoMs = repo.clock.mono(), bootCount = repo.clock.boot(), detail = detail)
        graph.db.runs().insertEvent(e); events += e
    }

    private suspend fun newSegment() {
        val r = active ?: return
        val updated = r.copy(currentSegment = r.currentSegment + 1); active = updated; repo.update(updated)
    }

    private suspend fun onFix(loc: Location) = mutex.withLock {
        val r = active ?: return@withLock
        lastFix = loc; lastFixMono = repo.clock.mono(); gapRefMono = lastFixMono
        warnings.remove(Warning.GPS_OFF)
        if (r.status != RunStatus.RECORDING) { publish(); return@withLock }
        if (signalLostFlag) {   // vuelve la señal: segmento nuevo, el hueco no se une
            signalLostFlag = false; warnings.remove(Warning.SIGNAL_LOST)
            newSegment(); logEvent(EventType.SIGNAL_BACK)
        }
        val cur = active!!
        val monoFix = loc.elapsedRealtimeNanos / 1_000_000
        val p = PointEntity(runId = cur.id, segment = cur.currentSegment, wallMs = loc.time, monoMs = monoFix, bootCount = repo.clock.boot(),
            lat = loc.latitude, lon = loc.longitude, accuracyM = if (loc.hasAccuracy()) loc.accuracy else 999f,
            // Altitud solo con precisión vertical declarada ≤ 12 m: así el desnivel solo se muestra si es fiable.
            altitudeM = if (loc.hasAltitude() && loc.hasVerticalAccuracy() && loc.verticalAccuracyMeters <= 12f) loc.altitude else null)
        repo.addPoint(p)                // guardado incremental de cada punto
        samples += p.toSample()
        publish()
    }

    private suspend fun onGpsOff() = mutex.withLock {
        if (active == null || Warning.GPS_OFF in warnings) return@withLock
        warnings += Warning.GPS_OFF; logEvent(EventType.GPS_OFF); alert(Warning.GPS_OFF); publish()
    }

    private suspend fun onPermissionLost() = mutex.withLock {
        if (active == null) return@withLock
        warnings += Warning.PERMISSION_LOST; logEvent(EventType.PERMISSION_LOST)
        stopLocation(); alert(Warning.PERMISSION_LOST); publish()
    }

    private suspend fun pauseInternal() {
        val r = active ?: return
        if (r.status != RunStatus.RECORDING) return
        logEvent(EventType.PAUSE)
        active = r.copy(status = RunStatus.PAUSED).also { repo.update(it) }
        publish()
    }

    private suspend fun resumeInternal() {
        val r = active ?: return
        if (r.status != RunStatus.PAUSED) return
        logEvent(EventType.RESUME)
        active = r.copy(status = RunStatus.RECORDING, currentSegment = r.currentSegment + 1).also { repo.update(it) }
        signalLostFlag = false
        gapRefMono = repo.clock.mono()
        startLocation()
        publish()
    }

    private suspend fun stopInternal() {
        val r = active ?: run { stopSelf(); return }
        stopLocation(); ticker?.cancel()
        repo.endRecording(r.id)
        active = null
        Tracking._live.value = null
        Tracking._start.value = StartState.Idle
        Tracking._ended.value = r.id
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = lifecycleScope.launch {
            var n = 0
            while (isActive) {
                delay(1000)
                mutex.withLock {
                    val r = active
                    if (r != null && r.status == RunStatus.RECORDING && !signalLostFlag &&
                        repo.clock.mono() - gapRefMono > RunMetrics.SIGNAL_GAP_MS) {
                        signalLostFlag = true; warnings += Warning.SIGNAL_LOST
                        logEvent(EventType.SIGNAL_LOST); alert(Warning.SIGNAL_LOST)
                    }
                }
                publish()
                if (++n % 5 == 0) updateNotification()
            }
        }
    }

    private fun currentSignal(): SignalQuality {
        val f = lastFix ?: return SignalQuality.NONE
        if (repo.clock.mono() - lastFixMono > RunMetrics.STALE_FIX_MS) return SignalQuality.NONE
        return signalFor(if (f.hasAccuracy()) f.accuracy else null)
    }

    private fun publish() {
        val r = active ?: return
        val stats = runCatching { repo.stats(r, events, samples.toList(), live = true) }.getOrNull()
        val sport = Sport.of(r.sport)
        Tracking._live.value = LiveRun(r.id, r.status, currentSignal(), stats, warnings.toSet(),
            when (r.kind) { RunKind.ROUTINE -> "Rutina"; RunKind.ROUTE -> "Ruta guardada"; RunKind.SHARED -> r.sharedSessionName ?: "Encuentro del club"; else -> "Actividad libre" },
            sport, waitingFirstFix = samples.isEmpty())
    }

    private fun updateNotification() {
        val l = Tracking.live.value ?: return
        val s = l.stats
        val text = (if (l.status == RunStatus.PAUSED) "En pausa" else "Grabando") +
            " · ${Fmt.km(s?.distanceM)} km · ${Fmt.duration(s?.activeMs)}"
        if (NotificationManagerCompat.from(this).areNotificationsEnabled())
            runCatching { NotificationManagerCompat.from(this).notify(NOTIF_ID, notification(text)) }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("openActiveRun", true)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val paused = active?.status == RunStatus.PAUSED
        val action = Intent(this, TrackingService::class.java).setAction(if (paused) Tracking.ACTION_RESUME else Tracking.ACTION_PAUSE)
        val pi = PendingIntent.getService(this, 1, action, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, FuckrunApp.CH_SESSION)
            .setSmallIcon(R.drawable.ic_stat_run)
            .setContentTitle("Athlete Club · ${Sport.of(active?.sport).label}")
            .setColor(0xFF34C77B.toInt())
            .setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true).setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_WORKOUT)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(open)
            .addAction(0, if (paused) "Reanudar" else "Pausar", pi)
            .addAction(0, "Volver a la actividad", open)
            .build()
    }

    private fun alert(w: Warning) {
        val nm = NotificationManagerCompat.from(this)
        if (!nm.areNotificationsEnabled()) return
        runCatching {
            nm.notify(ALERT_ID + w.ordinal, NotificationCompat.Builder(this, FuckrunApp.CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_run).setContentTitle("Athlete Club").setContentText(w.text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(w.text)).setAutoCancel(true).build())
        }
    }

    override fun onDestroy() {
        stopLocation()
        runCatching { unregisterReceiver(systemReceiver) }
        super.onDestroy()
    }

    companion object { const val NOTIF_ID = 42; const val ALERT_ID = 100 }
}
