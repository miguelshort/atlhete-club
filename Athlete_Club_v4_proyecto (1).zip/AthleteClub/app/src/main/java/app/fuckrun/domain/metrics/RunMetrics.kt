package app.fuckrun.domain.metrics

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Motor de métricas de una sesión. Kotlin puro (sin Android) para poder probarlo.
 *
 * DEFINICIONES (también en docs/METRICAS.md):
 *  - Tiempo transcurrido: desde el inicio hasta el final (o ahora), INCLUYE pausas.
 *  - Tiempo activo: suma de los intervalos grabando, EXCLUYE pausas y tramos perdidos
 *    por cierre de la app (esos tramos se informan aparte).
 *  - Velocidad media activa = distancia / tiempo activo.
 *  - Ritmo medio activo = tiempo activo / distancia.
 *  - Velocidad actual: distancia/tiempo en una ventana deslizante de [WINDOW_MS].
 *  - Máxima y mínima en movimiento: sobre la velocidad suavizada de ventanas válidas
 *    (≥ [MIN_WINDOW_POINTS] puntos y ≥ [MIN_WINDOW_SPAN_MS]); nunca de un único salto.
 *    La mínima excluye ventanas por debajo de [MOVING_THRESHOLD_MPS] (paradas).
 *
 * FILTROS DE PRECISIÓN:
 *  1. Se descartan fijos con precisión peor que [MAX_ACCURACY_M].
 *  2. Se descartan fijos que implican una velocidad mayor que la plausible PARA EL DEPORTE respecto al último aceptado
 *     (ver SportRules: 45 km/h correr, 25 senderismo, 18 caminata, 90 bicicleta). [MAX_PLAUSIBLE_MPS] es el valor por defecto.
 *  3. Umbral anti-ruido acumulado desde un ancla (max(4 m, precisión declarada), sobre posiciones suavizadas): evita "distancia fantasma"
 *     estando parado sin perder distancia en trotes lentos.
 *  4. La distancia solo se suma DENTRO de un mismo segmento: entre segmentos (pausa, pérdida de
 *     señal, cierre de la app) no se inventa recorrido.
 */
object RunMetrics {
    const val MAX_ACCURACY_M = 25f
    const val MAX_PLAUSIBLE_MPS = 12.5          // 45 km/h
    const val WINDOW_MS = 10_000L
    const val MIN_WINDOW_POINTS = 3
    const val MIN_WINDOW_SPAN_MS = 5_000L
    const val MOVING_THRESHOLD_MPS = 0.5        // 1,8 km/h
    const val STALE_FIX_MS = 10_000L            // sin fijos durante 10 s => velocidad actual "sin datos"
    const val SIGNAL_GAP_MS = 15_000L           // hueco de señal que abre un segmento nuevo
    const val SMOOTH_RADIUS = 2                 // media centrada de 5 fijos
    const val MIN_NOISE_M = 4.0

    data class Sample(
        val segment: Int,
        val tMs: Long,          // tiempo monotónico comparable dentro del segmento (ms)
        val wallMs: Long,
        val lat: Double,
        val lon: Double,
        val accuracyM: Float,
        /** Altitud solo si el sistema da precisión vertical suficiente (ver TrackingService). */
        val altitudeM: Double? = null,
    )

    data class Interval(val startMs: Long, val endMs: Long?)   // reloj de pared ya corregido

    data class Split(val km: Int, val durationMs: Long, val partial: Boolean, val partialMeters: Double)

    data class Stats(
        val distanceM: Double,
        val elapsedMs: Long,
        val activeMs: Long,
        val currentSpeedMps: Double?,
        val avgSpeedMps: Double?,
        val maxSpeedMps: Double?,
        val minMovingSpeedMps: Double?,
        val acceptedPoints: Int,
        val rejectedPoints: Int,
        val segments: List<List<Sample>>,
        val splits: List<Split>,
        /** Desnivel positivo acumulado (m); null si la altitud no es fiable. */
        val elevationGainM: Double? = null,
        /** Mejor tramo continuo de 1 km (ms); null si no hay tramo válido. */
        val best1kMs: Long? = null,
    ) {
        val avgPaceSecPerKm: Double? get() = paceFromSpeed(avgSpeedMps)
        val currentPaceSecPerKm: Double? get() = paceFromSpeed(currentSpeedMps)
    }

    fun paceFromSpeed(mps: Double?): Double? =
        if (mps == null || mps < MOVING_THRESHOLD_MPS) null else 1000.0 / mps

    fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6_371_000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * atan2(sqrt(a), sqrt(1 - a))
    }

    /** Aplica los filtros 1 y 2 y devuelve los puntos aceptados agrupados por segmento. */
    fun filter(raw: List<Sample>, maxPlausibleMps: Double = MAX_PLAUSIBLE_MPS): Pair<List<List<Sample>>, Int> {
        var rejected = 0
        val out = linkedMapOf<Int, MutableList<Sample>>()
        for (s in raw.sortedWith(compareBy({ it.segment }, { it.tMs }))) {
            if (s.accuracyM > MAX_ACCURACY_M) { rejected++; continue }
            val seg = out.getOrPut(s.segment) { mutableListOf() }
            val prev = seg.lastOrNull()
            if (prev != null) {
                val dt = (s.tMs - prev.tMs) / 1000.0
                if (dt <= 0) { rejected++; continue }
                val d = haversine(prev.lat, prev.lon, s.lat, s.lon)
                if (d / dt > maxPlausibleMps) { rejected++; continue }
            }
            seg.add(s)
        }
        return out.values.filter { it.isNotEmpty() } to rejected
    }

    /**
     * Distancia acumulada por punto con umbral anti-ruido ACUMULADO: se mide desde un punto ancla y solo
     * se suma cuando el desplazamiento supera el ruido esperado (max(4 m, precisión declarada)), sobre posiciones
     * suavizadas con una media centrada de 5 fijos. Así un trote lento
     * con un fijo por segundo suma bien, y la deriva del GPS estando parado no genera distancia.
     */
    fun cumulative(seg: List<Sample>): DoubleArray = track(seg).first

    /** Distancia acumulada y, para cada punto, el índice del último ancla (donde la distancia cambió de verdad). */
    private fun track(seg: List<Sample>): Pair<DoubleArray, IntArray> {
        val cum = DoubleArray(seg.size)
        val anchorOf = IntArray(seg.size)
        if (seg.isEmpty()) return cum to anchorOf
        // Suavizado: media centrada de hasta 5 fijos (±2) dentro del segmento.
        val lat = DoubleArray(seg.size); val lon = DoubleArray(seg.size)
        for (i in seg.indices) {
            // Ventana simétrica (se estrecha en los extremos) para no acortar el principio ni el final del tramo.
            val r = minOf(SMOOTH_RADIUS, i, seg.lastIndex - i); val a = i - r; val b = i + r
            var sl = 0.0; var so = 0.0
            for (j in a..b) { sl += seg[j].lat; so += seg[j].lon }
            lat[i] = sl / (b - a + 1); lon[i] = so / (b - a + 1)
        }
        var anchor = 0
        for (i in 1 until seg.size) {
            val d = haversine(lat[anchor], lon[anchor], lat[i], lon[i])
            val noise = max(MIN_NOISE_M, max(seg[anchor].accuracyM, seg[i].accuracyM).toDouble())
            if (d >= noise) { cum[i] = cum[anchor] + d; anchor = i } else cum[i] = cum[i - 1]
            anchorOf[i] = anchor
        }
        return cum to anchorOf
    }

    /** Velocidad entre dos puntos usando los instantes de sus anclas (evita el sesgo de cuantización). */
    private fun speedBetween(seg: List<Sample>, cum: DoubleArray, anchorOf: IntArray, s: Int, e: Int): Double? {
        val ts = seg[anchorOf[s]].tMs; val te = seg[anchorOf[e]].tMs
        if (te - ts < MIN_WINDOW_SPAN_MS) return null
        return (cum[e] - cum[s]) / ((te - ts) / 1000.0)
    }

    /** Velocidades suavizadas de ventanas válidas (m/s). */
    private fun windowSpeeds(seg: List<Sample>): List<Double> {
        val res = mutableListOf<Double>()
        if (seg.size < MIN_WINDOW_POINTS) return res
        val (cum, anchorOf) = track(seg)
        var start = 0
        for (end in seg.indices) {
            while (seg[end].tMs - seg[start].tMs > WINDOW_MS) start++
            if (end - start + 1 >= MIN_WINDOW_POINTS) speedBetween(seg, cum, anchorOf, start, end)?.let { res.add(it) }
        }
        return res
    }

    fun activeMs(intervals: List<Interval>, nowMs: Long): Long =
        intervals.sumOf { (it.endMs ?: nowMs) - it.startMs }.coerceAtLeast(0)

    fun compute(
        raw: List<Sample>,
        intervals: List<Interval>,
        startWallMs: Long,
        endWallMs: Long?,
        nowMs: Long,
        nowMonotonicMs: Long? = null,   // para la velocidad actual en directo
        recording: Boolean = false,
        maxPlausibleMps: Double = MAX_PLAUSIBLE_MPS,
        currentWindowMs: Long = WINDOW_MS,
    ): Stats {
        val (segments, rejected) = filter(raw, maxPlausibleMps)
        val distance = segments.sumOf { cumulative(it).lastOrNull() ?: 0.0 }

        val active = activeMs(intervals, nowMs)
        val elapsed = ((endWallMs ?: nowMs) - startWallMs).coerceAtLeast(0)
        val avg = if (active >= 1000 && distance > 0) distance / (active / 1000.0) else null

        val speeds = segments.flatMap { windowSpeeds(it) }
        val max = speeds.maxOrNull()
        val minMoving = speeds.filter { it >= MOVING_THRESHOLD_MPS }.minOrNull()

        // Velocidad actual: solo si se está grabando y el último fijo es reciente.
        var current: Double? = null
        if (recording && nowMonotonicMs != null) {
            val last = segments.lastOrNull()
            val lastPoint = last?.lastOrNull()
            if (last != null && lastPoint != null && nowMonotonicMs - lastPoint.tMs <= STALE_FIX_MS) {
                val (cum, anchorOf) = track(last)
                val from = last.indexOfFirst { lastPoint.tMs - it.tMs <= currentWindowMs }
                val span = lastPoint.tMs - last[from].tMs
                if (last.size - from >= 2 && span >= 3_000) {
                    val lastAnchorAge = lastPoint.tMs - last[anchorOf.last()].tMs
                    current = if (lastAnchorAge > MIN_WINDOW_SPAN_MS) 0.0          // parada real: 0, sin maquillar
                        else speedBetween(last, cum, anchorOf, from, last.lastIndex)
                            ?: ((cum.last() - cum[from]) / (span / 1000.0))
                }
            }
        }

        return Stats(
            distanceM = distance,
            elapsedMs = elapsed,
            activeMs = active,
            currentSpeedMps = current,
            avgSpeedMps = avg,
            maxSpeedMps = max,
            minMovingSpeedMps = minMoving,
            acceptedPoints = segments.sumOf { it.size },
            rejectedPoints = rejected,
            segments = segments,
            splits = splits(segments),
            elevationGainM = elevationGain(segments),
            best1kMs = best1kMs(segments),
        )
    }

    const val BEST_1K_MAX_ACCURACY_M = 15f
    const val BEST_1K_MAX_GAP_MS = 10_000L

    /**
     * Mejor tiempo (ms) en un tramo CONTINUO de 1 km dentro de un mismo segmento, interpolando el instante en que se
     * completa el kilómetro. Calidad exigida: todos los puntos del tramo con precisión ≤ 15 m y sin huecos de más de
     * 10 s entre fijos. Sin tramo válido devuelve null (no hay récord de tramo).
     */
    fun best1kMs(segments: List<List<Sample>>): Long? {
        var best: Double? = null
        for (seg in segments) {
            if (seg.size < 2) continue
            val cum = cumulative(seg)
            var start = 0
            for (end in 1 until seg.size) {
                val bad = seg[end].accuracyM > BEST_1K_MAX_ACCURACY_M || seg[end].tMs - seg[end - 1].tMs > BEST_1K_MAX_GAP_MS
                if (bad) { start = end; continue }
                if (seg[start].accuracyM > BEST_1K_MAX_ACCURACY_M) { start = end; continue }
                while (start < end && cum[end] - cum[start + 1] >= 1000.0) start++
                val d = cum[end] - cum[start]
                if (d >= 1000.0) {
                    val prevD = cum[end - 1] - cum[start]
                    val frac = if (d > prevD) ((1000.0 - prevD) / (d - prevD)).coerceIn(0.0, 1.0) else 1.0
                    val tEnd = seg[end - 1].tMs + frac * (seg[end].tMs - seg[end - 1].tMs)
                    val t = tEnd - seg[start].tMs
                    if (t > 0 && (best == null || t < best)) best = t
                }
            }
        }
        return best?.toLong()
    }

    const val MIN_ALT_POINTS = 20
    const val MIN_ALT_COVERAGE = 0.7
    const val ALT_HYSTERESIS_M = 4.0

    /**
     * Desnivel positivo con histéresis sobre altitud suavizada, solo dentro de cada segmento.
     * Se considera fiable si al menos el 70 % de los puntos aceptados tiene altitud (con precisión vertical) y hay ≥ 20.
     * Si no, devuelve null y la interfaz muestra «—».
     */
    fun elevationGain(segments: List<List<Sample>>): Double? {
        val all = segments.sumOf { it.size }
        val withAlt = segments.sumOf { s -> s.count { it.altitudeM != null } }
        if (withAlt < MIN_ALT_POINTS || withAlt < all * MIN_ALT_COVERAGE) return null
        var gain = 0.0
        for (seg in segments) {
            val alts = seg.mapNotNull { it.altitudeM }
            if (alts.size < 3) continue
            val sm = alts.indices.map { i -> val a = maxOf(0, i - 2); val b = minOf(alts.lastIndex, i + 2); alts.subList(a, b + 1).average() }
            var ref = sm.first()
            for (v in sm) {
                if (v - ref >= ALT_HYSTERESIS_M) { gain += v - ref; ref = v }
                else if (v < ref) ref = v
            }
        }
        return gain
    }

    /**
     * Parciales por kilómetro usando el tiempo en movimiento registrado dentro de los segmentos
     * (interpolando el instante en que se cruza cada km). Entre segmentos no se cuenta tiempo
     * ni distancia, así que un parcial que contenga un hueco se calcula solo con lo registrado.
     */
    fun splits(segments: List<List<Sample>>): List<Split> {
        val res = mutableListOf<Split>()
        var cumD = 0.0
        var cumT = 0.0
        var lastKmT = 0.0
        var nextKm = 1000.0
        for (seg in segments) { val c = cumulative(seg); for (i in 1 until seg.size) {
            val d = c[i] - c[i - 1]
            val t = (seg[i].tMs - seg[i - 1].tMs).toDouble()
            if (d == 0.0) { cumT += t; continue }
            var remD = d
            var remT = t
            while (cumD + remD >= nextKm) {
                val need = nextKm - cumD
                val tPart = remT * (need / remD)
                cumT += tPart; cumD += need; remD -= need; remT -= tPart
                res.add(Split(res.size + 1, (cumT - lastKmT).toLong(), false, 1000.0))
                lastKmT = cumT
                nextKm += 1000.0
            }
            cumD += remD; cumT += remT
        } }
        val rest = cumD - (nextKm - 1000.0)
        if (res.isNotEmpty() && rest >= 100) {
            res.add(Split(res.size + 1, (cumT - lastKmT).toLong(), true, rest))
        }
        return res
    }
}
