package app.fuckrun.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.fuckrun.FuckrunApp
import app.fuckrun.data.AppSettings
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.Sport
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.delay

/**
 * Bienvenida a pantalla completa en cada apertura desde el icono:
 *  1) saludo y UNA pregunta (franja horaria del móvil, nombre si lo hay), con el avatar saludando;
 *  2) «Elegir deporte»: el cristal del propio botón se ensancha y revela Correr, Sendero, Bicicleta y Caminata;
 *     elegir una fila abre la preparación con ese deporte (el GPS y el cronómetro solo arrancan con «Empezar»);
 *  3) «Solo quiero entrar en la aplicación»: siempre visible, también sin cuenta y sin conexión.
 * Con una actividad en marcha, la acción principal es «Volver a mi actividad».
 */
@Composable
fun WelcomeScreen(greeting: String, onSport: (Sport) -> Unit, onEnter: () -> Unit, onBackToActivity: () -> Unit) {
    val g = FuckrunApp.graph
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val live by Tracking.live.collectAsStateWithLifecycle()
    var open by rememberSaveable { mutableStateOf(false) }
    val motion = rememberAvatarMotion()
    val reduce = LocalReduceMotion.current
    LaunchedEffect(Unit) {
        if (reduce) return@LaunchedEffect
        delay(350)
        // Saludo breve con la mano
        motion.waveOnce()
    }
    BackHandler(enabled = open) { open = false }
    BackHandler(enabled = !open) { onEnter() }

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)) {
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(greeting, style = T.ScreenTitle.copy(fontSize = 30.sp, lineHeight = 37.sp), modifier = Modifier.weight(1f)
                .semantics { heading(); liveRegion = LiveRegionMode.Polite })
            Avatar(settings.avatarLook, settings.avatarOutfit, Modifier.size(width = 96.dp, height = 150.dp), motion = motion)
        }
        Spacer(Modifier.height(24.dp))

        val l = live
        if (l != null) {
            val paused = l.status == RunStatus.PAUSED
            PillButton("Volver a mi actividad", color = if (paused) C.Red else C.Green, icon = if (paused) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                big = true, modifier = Modifier.fillMaxWidth(), onClick = onBackToActivity)
            Text("${l.sport.label} · ${if (paused) "en pausa" else "grabando"} · ${Fmt.duration(l.stats?.activeMs)}", style = T.Label,
                modifier = Modifier.padding(start = 8.dp, top = 6.dp, bottom = 14.dp))
        }

        SportExpander(open, settings.lastFreeSport, onToggle = { open = !open }, onPick = { s -> open = false; onSport(s) })

        Spacer(Modifier.height(14.dp))
        Text("Solo quiero entrar en la aplicación", style = T.Body.copy(color = C.Blue, fontSize = 17.sp),
            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp).liquid(RoundedCornerShape(26.dp), onClickLabel = "Ir a Inicio", onClick = onEnter)
                .padding(horizontal = 12.dp, vertical = 14.dp))
        Spacer(Modifier.height(24.dp))
    }
}

/**
 * Botón «Elegir deporte» que se convierte en panel: el contorno de cristal crece desde el borde inferior del botón y las
 * filas aparecen a medida que hay sitio. Cada fila responde con una lente de su color.
 */
@Composable
private fun SportExpander(open: Boolean, preferred: Sport, onToggle: () -> Unit, onPick: (Sport) -> Unit) {
    val reduce = LocalReduceMotion.current
    val chevron by animateFloatAsState(if (open) 180f else 0f, if (reduce) tween(0) else tween(220), label = "chevron")
    val shape = RoundedCornerShape(if (open) 28.dp else 34.dp)
    Column(Modifier.fillMaxWidth()
        .shadow(8.dp, shape, ambientColor = Color.Black.copy(alpha = 0.2f), spotColor = Color.Black.copy(alpha = 0.25f))
        // Sobre el fondo liso de la bienvenida no hay nada que desenfocar: misma película, filo y sombra del cristal.
        .clip(shape).background(C.GlassFallback)
        .background(preferred.color.copy(alpha = if (open) 0.08f else 0.16f))
        .border(1.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(C.EdgeTop, C.EdgeBottom)), shape)
        .animateContentSize(if (reduce) tween(0) else spring(dampingRatio = 0.85f, stiffness = 600f))) {
        Row(Modifier.fillMaxWidth().heightIn(min = 68.dp).liquid(shape, Color.Transparent, role = Role.DropdownList, onClickLabel = "Elegir deporte", onClick = onToggle)
            .semantics { stateDescription = if (open) "Desplegado" else "Plegado" }
            .padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(preferred.icon, null, tint = preferred.color, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Text("Elegir deporte", style = T.Section, modifier = Modifier.weight(1f))
            Icon(Icons.Rounded.ExpandMore, null, tint = preferred.color, modifier = Modifier.size(30.dp).graphicsLayer { rotationZ = chevron })
        }
        if (open) Column(Modifier.padding(start = 8.dp, end = 8.dp, bottom = 8.dp)) {
            Sport.entries.forEach { s -> MenuRow(s.label, s.icon, s.color, selected = s == preferred) { onPick(s) } }
        }
    }
}
