package app.fuckrun.domain

import java.time.DayOfWeek
import java.time.LocalDate
import kotlin.math.roundToLong

// =============================================================================================================
// Puntos, marcas personales y logros. Lógica pura y determinista: con el mismo historial, los mismos
// identificadores y el mismo resultado en cualquier móvil (dos dispositivos o una reinstalación convergen).
// =============================================================================================================

/** Categorías de marca personal. */
enum class RecordCat(val label: String, val criterion: String) {
    DISTANCE("Mayor distancia", "Gana la distancia mayor en una sesión, con 2 decimales en km."),
    DURATION("Mayor duración activa", "Gana el tiempo activo mayor en una sesión, al segundo."),
    SPEED_1K("Mayor velocidad media en 1 km", "Mejor kilómetro completo y continuo; velocidad media con un decimal."),
    PACE_1K("Mejor ritmo en 1 km", "Mejor kilómetro completo y continuo; ritmo al segundo por km.");

    companion object {
        /** Bicicleta compara velocidad; los deportes a pie, ritmo. */
        fun oneK(s: Sport) = if (s == Sport.BIKE) SPEED_1K else PACE_1K
        fun forSport(s: Sport) = listOf(DISTANCE, DURATION, oneK(s))
    }
}

/**
 * Lo que hace falta de una actividad guardada.
 * @param measured personal, medida con GPS y guardada (las manuales siguen en el historial, pero no puntúan).
 * @param gpsDistanceM distancia con muestras aceptadas por los filtros (sin huecos); null si el GPS fue insuficiente.
 * @param plannedKey sesión planificada vinculada a esta actividad completada (cuenta una vez).
 * @param routeId ruta verificada seguida; [routeCovered] = se completó ≥ 80 % de su trazado.
 */
data class SessionFacts(
    val syncId: String,
    val sport: Sport,
    val startedAt: Long,
    val date: LocalDate,
    val measured: Boolean,
    val activeMs: Long,
    val gpsDistanceM: Double?,
    val best1kMs: Long?,
    val plannedKey: String? = null,
    val routeId: String? = null,
    val routeCovered: Boolean = false,
)

data class RecordChange(val cat: RecordCat, val previous: Double?, val current: Double) {
    val isReference get() = previous == null
}

/** Movimiento de puntos con identificador estable: «act:<actividad>» y «rec:<actividad>:<categoría>». */
data class LedgerEntry(val id: String, val amount: Int, val reason: String)

data class SessionResult(
    val syncId: String,
    val valid: Boolean,
    val entries: List<LedgerEntry>,
    val changes: List<RecordChange>,
    /** Logros que esta sesión hace alcanzar (todas las piezas recién elegibles a la vez). */
    val unlocked: List<String>,
) { val points get() = entries.sumOf { it.amount } }

/** Progreso acumulado de un deporte con el historial vigente. */
data class SportProgress(
    val sessions: Int = 0,
    val sumKm: Double = 0.0,
    val maxSingleKm: Double = 0.0,
    val sumMin: Double = 0.0,
    val weeks: Set<Long> = emptySet(),
    val planned: Set<String> = emptySet(),
    val improvements: Map<RecordCat, Int> = emptyMap(),
    val routes: Set<String> = emptySet(),
    val best: Map<RecordCat, Double> = emptyMap(),
)

enum class Metric { SESSIONS, SUM_KM, SINGLE_KM, SUM_MIN, WEEKS, PLANNED, IMPROVE_DIST, IMPROVE_DUR, IMPROVE_1K, ROUTES }

data class Achievement(val id: String, val sport: Sport, val metric: Metric, val target: Double, val goal: String, val altWeeks: Int? = null)

object Achievements {
    private fun a(id: String, metric: Metric, target: Number, goal: String, alt: Int? = null): Achievement {
        val s = when (id.take(3)) { "COR" -> Sport.RUN; "SEN" -> Sport.HIKE; "BIC" -> Sport.BIKE; else -> Sport.WALK }
        return Achievement(id, s, metric, target.toDouble(), goal, alt)
    }

    val all = listOf(
        a("COR-01", Metric.SESSIONS, 1, "Guardar la primera carrera"), a("COR-02", Metric.SESSIONS, 3, "Completar 3 carreras"),
        a("COR-03", Metric.SESSIONS, 10, "Completar 10 carreras"), a("COR-04", Metric.SESSIONS, 25, "Completar 25 carreras"),
        a("COR-05", Metric.SUM_KM, 10, "Sumar 10 km"), a("COR-06", Metric.SUM_KM, 30, "Sumar 30 km"),
        a("COR-07", Metric.SUM_KM, 75, "Sumar 75 km"), a("COR-08", Metric.SUM_KM, 150, "Sumar 150 km"),
        a("COR-09", Metric.SINGLE_KM, 3, "Completar 3 km en una carrera"), a("COR-10", Metric.SINGLE_KM, 5, "Completar 5 km en una carrera"),
        a("COR-11", Metric.SINGLE_KM, 10, "Completar 10 km en una carrera"), a("COR-12", Metric.SUM_MIN, 60, "Sumar 60 min activos"),
        a("COR-13", Metric.SUM_MIN, 180, "Sumar 180 min activos"), a("COR-14", Metric.SUM_MIN, 360, "Sumar 360 min activos"),
        a("COR-15", Metric.WEEKS, 3, "Correr en 3 semanas distintas"), a("COR-16", Metric.WEEKS, 6, "Correr en 6 semanas distintas"),
        a("COR-17", Metric.PLANNED, 3, "Completar 3 sesiones planificadas"), a("COR-18", Metric.PLANNED, 6, "Completar 6 sesiones planificadas"),
        a("COR-19", Metric.IMPROVE_DIST, 1, "Primera mejora de distancia por sesión"), a("COR-20", Metric.IMPROVE_DIST, 3, "Tercera mejora de distancia por sesión"),
        a("COR-21", Metric.IMPROVE_DUR, 1, "Primera mejora de duración activa por sesión"), a("COR-22", Metric.IMPROVE_DUR, 3, "Tercera mejora de duración activa por sesión"),
        a("COR-23", Metric.IMPROVE_1K, 1, "Primera mejora de ritmo en 1 km"), a("COR-24", Metric.IMPROVE_1K, 3, "Tercera mejora de ritmo en 1 km"),

        a("SEN-01", Metric.SESSIONS, 1, "Guardar la primera excursión"), a("SEN-02", Metric.SESSIONS, 3, "Completar 3 excursiones"),
        a("SEN-03", Metric.SESSIONS, 8, "Completar 8 excursiones"), a("SEN-04", Metric.SESSIONS, 16, "Completar 16 excursiones"),
        a("SEN-05", Metric.SUM_KM, 8, "Sumar 8 km"), a("SEN-06", Metric.SUM_KM, 25, "Sumar 25 km"),
        a("SEN-07", Metric.SUM_KM, 60, "Sumar 60 km"), a("SEN-08", Metric.SUM_KM, 120, "Sumar 120 km"),
        a("SEN-09", Metric.SINGLE_KM, 3, "Completar 3 km en una excursión"), a("SEN-10", Metric.SINGLE_KM, 6, "Completar 6 km en una excursión"),
        a("SEN-11", Metric.SINGLE_KM, 10, "Completar 10 km en una excursión"), a("SEN-12", Metric.SUM_MIN, 90, "Sumar 90 min activos"),
        a("SEN-13", Metric.SUM_MIN, 240, "Sumar 240 min activos"), a("SEN-14", Metric.SUM_MIN, 600, "Sumar 600 min activos"),
        a("SEN-15", Metric.WEEKS, 3, "Salir por senderos en 3 semanas distintas"), a("SEN-16", Metric.WEEKS, 6, "Salir por senderos en 6 semanas distintas"),
        a("SEN-17", Metric.PLANNED, 2, "Completar 2 sesiones planificadas"), a("SEN-18", Metric.PLANNED, 5, "Completar 5 sesiones planificadas"),
        a("SEN-19", Metric.IMPROVE_DIST, 1, "Primera mejora de distancia por sesión"), a("SEN-20", Metric.IMPROVE_DIST, 3, "Tercera mejora de distancia por sesión"),
        a("SEN-21", Metric.IMPROVE_DUR, 1, "Primera mejora de duración activa por sesión"), a("SEN-22", Metric.IMPROVE_DUR, 3, "Tercera mejora de duración activa por sesión"),
        a("SEN-23", Metric.ROUTES, 3, "Completar 3 rutas verificadas distintas", alt = 4), a("SEN-24", Metric.ROUTES, 5, "Completar 5 rutas verificadas distintas", alt = 8),

        a("BIC-01", Metric.SESSIONS, 1, "Guardar la primera salida en bici"), a("BIC-02", Metric.SESSIONS, 3, "Completar 3 salidas"),
        a("BIC-03", Metric.SESSIONS, 10, "Completar 10 salidas"), a("BIC-04", Metric.SESSIONS, 25, "Completar 25 salidas"),
        a("BIC-05", Metric.SUM_KM, 20, "Sumar 20 km"), a("BIC-06", Metric.SUM_KM, 60, "Sumar 60 km"),
        a("BIC-07", Metric.SUM_KM, 150, "Sumar 150 km"), a("BIC-08", Metric.SUM_KM, 300, "Sumar 300 km"),
        a("BIC-09", Metric.SINGLE_KM, 10, "Completar 10 km en una salida"), a("BIC-10", Metric.SINGLE_KM, 20, "Completar 20 km en una salida"),
        a("BIC-11", Metric.SINGLE_KM, 40, "Completar 40 km en una salida"), a("BIC-12", Metric.SUM_MIN, 90, "Sumar 90 min activos"),
        a("BIC-13", Metric.SUM_MIN, 300, "Sumar 300 min activos"), a("BIC-14", Metric.SUM_MIN, 600, "Sumar 600 min activos"),
        a("BIC-15", Metric.WEEKS, 3, "Pedalear en 3 semanas distintas"), a("BIC-16", Metric.WEEKS, 6, "Pedalear en 6 semanas distintas"),
        a("BIC-17", Metric.PLANNED, 3, "Completar 3 sesiones planificadas"), a("BIC-18", Metric.PLANNED, 6, "Completar 6 sesiones planificadas"),
        a("BIC-19", Metric.IMPROVE_DIST, 1, "Primera mejora de distancia por sesión"), a("BIC-20", Metric.IMPROVE_DIST, 3, "Tercera mejora de distancia por sesión"),
        a("BIC-21", Metric.IMPROVE_DUR, 1, "Primera mejora de duración activa por sesión"), a("BIC-22", Metric.IMPROVE_DUR, 3, "Tercera mejora de duración activa por sesión"),
        a("BIC-23", Metric.IMPROVE_1K, 1, "Primera mejora de velocidad media en 1 km"), a("BIC-24", Metric.IMPROVE_1K, 3, "Tercera mejora de velocidad media en 1 km"),

        a("CAM-01", Metric.SESSIONS, 1, "Guardar el primer paseo"), a("CAM-02", Metric.SESSIONS, 3, "Completar 3 paseos"),
        a("CAM-03", Metric.SESSIONS, 10, "Completar 10 paseos"), a("CAM-04", Metric.SESSIONS, 25, "Completar 25 paseos"),
        a("CAM-05", Metric.SUM_KM, 5, "Sumar 5 km"), a("CAM-06", Metric.SUM_KM, 15, "Sumar 15 km"),
        a("CAM-07", Metric.SUM_KM, 40, "Sumar 40 km"), a("CAM-08", Metric.SUM_KM, 100, "Sumar 100 km"),
        a("CAM-09", Metric.SINGLE_KM, 1, "Completar 1 km en un paseo"), a("CAM-10", Metric.SINGLE_KM, 3, "Completar 3 km en un paseo"),
        a("CAM-11", Metric.SINGLE_KM, 5, "Completar 5 km en un paseo"), a("CAM-12", Metric.SUM_MIN, 45, "Sumar 45 min activos"),
        a("CAM-13", Metric.SUM_MIN, 150, "Sumar 150 min activos"), a("CAM-14", Metric.SUM_MIN, 300, "Sumar 300 min activos"),
        a("CAM-15", Metric.WEEKS, 3, "Caminar en 3 semanas distintas"), a("CAM-16", Metric.WEEKS, 6, "Caminar en 6 semanas distintas"),
        a("CAM-17", Metric.PLANNED, 3, "Completar 3 sesiones planificadas"), a("CAM-18", Metric.PLANNED, 6, "Completar 6 sesiones planificadas"),
        a("CAM-19", Metric.IMPROVE_DIST, 1, "Primera mejora de distancia por sesión"), a("CAM-20", Metric.IMPROVE_DIST, 3, "Tercera mejora de distancia por sesión"),
        a("CAM-21", Metric.IMPROVE_DUR, 1, "Primera mejora de duración activa por sesión"), a("CAM-22", Metric.IMPROVE_DUR, 3, "Tercera mejora de duración activa por sesión"),
        a("CAM-23", Metric.IMPROVE_1K, 1, "Primera mejora de ritmo en 1 km"), a("CAM-24", Metric.IMPROVE_1K, 3, "Tercera mejora de ritmo en 1 km"),
    )
    private val index = all.associateBy { it.id }
    fun byId(id: String) = index[id]
}

object Rewards {
    const val MIN_ACTIVE_MS = 5 * 60_000L
    const val POINTS_SESSION = 10
    const val POINTS_RECORD = 5

    fun valid(f: SessionFacts) = f.measured && f.activeMs >= MIN_ACTIVE_MS

    /**
     * Marca en la PRECISIÓN MOSTRADA (entero; mayor = mejor). Dos marcas que se ven iguales valen lo mismo y no
     * generan premio. Distancia: decenas de metro (km con 2 decimales). Duración: segundos. Ritmo: segundos por km
     * (negativo, porque menos es mejor). Velocidad: décimas de km/h.
     */
    fun units(f: SessionFacts, c: RecordCat): Long? = when (c) {
        RecordCat.DISTANCE -> f.gpsDistanceM?.takeIf { it > 0 }?.let { (it / 10.0).roundToLong() }?.takeIf { it > 0 }
        RecordCat.DURATION -> f.activeMs.takeIf { it > 0 }?.let { (it / 1000.0).roundToLong() }
        RecordCat.PACE_1K -> f.best1kMs?.takeIf { it > 0 }?.let { -(it / 1000.0).roundToLong() }
        RecordCat.SPEED_1K -> f.best1kMs?.takeIf { it > 0 }?.let { (3600.0 / (it / 1000.0) * 10.0).roundToLong() }
    }

    /** Valor legible de unas unidades (para «antes → ahora»). */
    fun display(c: RecordCat, u: Long): String = when (c) {
        RecordCat.DISTANCE -> "${Fmt.km(u * 10.0)} km"
        RecordCat.DURATION -> Fmt.duration(u * 1000)
        RecordCat.PACE_1K -> "${Fmt.pace(-u.toDouble())} min/km"
        RecordCat.SPEED_1K -> "%.1f km/h".format(java.util.Locale("es", "ES"), u / 10.0)
    }

    fun weekKey(d: LocalDate) = d.with(DayOfWeek.MONDAY).toEpochDay()

    private val order = compareBy<SessionFacts>({ it.startedAt }, { it.syncId })

    class Replay(
        val sessions: Map<String, SessionResult>,
        val progress: Map<Sport, SportProgress>,
        /** Logro → actividad en la que se alcanzó. */
        val reached: Map<String, String>,
    ) {
        fun of(s: Sport) = progress[s] ?: SportProgress()
    }

    /**
     * Reproduce el historial en orden cronológico (desempate estable por identificador). Cada referencia personal se
     * calcula contra actividades anteriores del mismo deporte: la primera fija la marca; una mejora estricta posterior
     * cuenta una vez por categoría y sesión y da 5 puntos. Al cruzar un umbral se conceden a la vez todas las piezas
     * recién elegibles.
     *
     * @param routesAvailable si el municipio tiene catálogo de rutas verificadas (si no, SEN-23/24 se consiguen con 4 y 8 semanas activas).
     */
    fun replay(history: List<SessionFacts>, routesAvailable: Boolean = true): Replay {
        val prog = Sport.entries.associateWith { SportProgress() }.toMutableMap()
        val results = LinkedHashMap<String, SessionResult>()
        val reached = LinkedHashMap<String, String>()
        for (f in history.distinctBy { it.syncId }.sortedWith(order)) {
            if (!valid(f)) { results[f.syncId] = SessionResult(f.syncId, false, emptyList(), emptyList(), emptyList()); continue }
            var p = prog.getValue(f.sport)
            val entries = mutableListOf(LedgerEntry("act:${f.syncId}", POINTS_SESSION, "Sesión completada"))
            val changes = mutableListOf<RecordChange>()
            val best = p.best.toMutableMap(); val imp = p.improvements.toMutableMap()
            for (c in RecordCat.forSport(f.sport)) {
                val u = units(f, c) ?: continue
                val prev = best[c]?.toLong()
                if (prev == null) { changes += RecordChange(c, null, u.toDouble()); best[c] = u.toDouble() }
                else if (u > prev) {
                    changes += RecordChange(c, prev.toDouble(), u.toDouble()); best[c] = u.toDouble()
                    imp[c] = (imp[c] ?: 0) + 1
                    entries += LedgerEntry("rec:${f.syncId}:${c.name}", POINTS_RECORD, "Marca mejorada: ${c.label.lowercase()}")
                }
            }
            val km = f.gpsDistanceM?.takeIf { it > 0 }?.div(1000.0)
            p = p.copy(
                sessions = p.sessions + 1,
                sumKm = p.sumKm + (km ?: 0.0),
                maxSingleKm = maxOf(p.maxSingleKm, km ?: 0.0),
                sumMin = p.sumMin + f.activeMs / 60_000.0,
                weeks = p.weeks + weekKey(f.date),
                planned = if (f.plannedKey != null) p.planned + f.plannedKey else p.planned,
                routes = if (f.routeId != null && f.routeCovered) p.routes + f.routeId else p.routes,
                improvements = imp, best = best,
            )
            prog[f.sport] = p
            val newly = Achievements.all.filter { it.sport == f.sport && it.id !in reached && met(it, p, routesAvailable) }.map { it.id }
            newly.forEach { reached[it] = f.syncId }
            results[f.syncId] = SessionResult(f.syncId, true, entries, changes, newly)
        }
        return Replay(results, prog, reached)
    }

    fun value(a: Achievement, p: SportProgress): Double = when (a.metric) {
        Metric.SESSIONS -> p.sessions.toDouble()
        Metric.SUM_KM -> p.sumKm
        Metric.SINGLE_KM -> p.maxSingleKm
        Metric.SUM_MIN -> p.sumMin
        Metric.WEEKS -> p.weeks.size.toDouble()
        Metric.PLANNED -> p.planned.size.toDouble()
        Metric.IMPROVE_DIST -> (p.improvements[RecordCat.DISTANCE] ?: 0).toDouble()
        Metric.IMPROVE_DUR -> (p.improvements[RecordCat.DURATION] ?: 0).toDouble()
        Metric.IMPROVE_1K -> (p.improvements[RecordCat.oneK(a.sport)] ?: 0).toDouble()
        Metric.ROUTES -> p.routes.size.toDouble()
    }

    fun met(a: Achievement, p: SportProgress, routesAvailable: Boolean): Boolean =
        value(a, p) + 1e-9 >= a.target || (a.metric == Metric.ROUTES && !routesAvailable && a.altWeeks != null && p.weeks.size >= a.altWeeks)

    fun fraction(a: Achievement, p: SportProgress, routesAvailable: Boolean = true): Float {
        if (met(a, p, routesAvailable)) return 1f
        val f = (value(a, p) / a.target).toFloat()
        val alt = if (a.metric == Metric.ROUTES && !routesAvailable && a.altWeeks != null) p.weeks.size / a.altWeeks.toFloat() else 0f
        return maxOf(f, alt).coerceIn(0f, 1f)
    }

    /** Progreso real de una ficha bloqueada, p. ej. «18 de 25 km en Sendero» o «1 de 3 mejoras de ritmo». */
    fun progressText(a: Achievement, p: SportProgress, routesAvailable: Boolean = true): String {
        val v = value(a, p); val t = a.target
        fun n(x: Double) = if (x == Math.floor(x)) x.toLong().toString() else "%.1f".format(java.util.Locale("es", "ES"), Math.floor(x * 10) / 10)
        val sport = a.sport.label
        return when (a.metric) {
            Metric.SESSIONS -> "${n(v)} de ${n(t)} ${if (t == 1.0) "sesión" else "sesiones"} de $sport"
            Metric.SUM_KM -> "${n(v)} de ${n(t)} km en $sport"
            Metric.SINGLE_KM -> "Mejor sesión: ${n(v)} de ${n(t)} km en $sport"
            Metric.SUM_MIN -> "${v.toLong()} de ${n(t)} min activos en $sport"
            Metric.WEEKS -> "${n(v)} de ${n(t)} semanas con $sport"
            Metric.PLANNED -> "${n(v)} de ${n(t)} sesiones planificadas de $sport"
            Metric.IMPROVE_DIST -> "${n(v)} de ${n(t)} ${if (t == 1.0) "mejora" else "mejoras"} de distancia"
            Metric.IMPROVE_DUR -> "${n(v)} de ${n(t)} ${if (t == 1.0) "mejora" else "mejoras"} de duración"
            Metric.IMPROVE_1K -> "${n(v)} de ${n(t)} ${if (t == 1.0) "mejora" else "mejoras"} de ${if (a.sport == Sport.BIKE) "velocidad" else "ritmo"} en 1 km"
            Metric.ROUTES -> "${n(v)} de ${n(t)} rutas verificadas" + (if (!routesAvailable && a.altWeeks != null) " · o ${p.weeks.size} de ${a.altWeeks} semanas activas" else "")
        }
    }
}

/**
 * Cobertura de una ruta verificada: fracción de su trazado recorrida siguiendo su geometría. Una muestra de la ruta
 * cuenta como recorrida si hay un punto válido de la actividad a menos de [toleranceM] metros. Se admite el sentido
 * inverso (para recorridos de doble sentido) y se exige que la mayoría del avance siga un sentido.
 */
object RouteCoverage {
    const val TOLERANCE_M = 35.0
    const val REQUIRED = 0.8

    data class Pt(val lat: Double, val lon: Double)

    private fun dist(a: Pt, b: Pt): Double {
        val k = Math.PI / 180; val x = (b.lon - a.lon) * k * Math.cos((a.lat + b.lat) / 2 * k); val y = (b.lat - a.lat) * k
        return Math.sqrt(x * x + y * y) * 6_371_000.0
    }

    fun length(route: List<Pt>) = route.zipWithNext { a, b -> dist(a, b) }.sum()

    /** Muestrea el trazado cada ~10 m. */
    private fun resample(route: List<Pt>, step: Double = 10.0): List<Pt> {
        val out = mutableListOf(route.first())
        for ((a, b) in route.zipWithNext()) {
            val d = dist(a, b); val n = (d / step).toInt()
            for (k in 1..n) { val t = k * step / d; out += Pt(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t) }
            out += b
        }
        return out
    }

    fun fraction(route: List<Pt>, track: List<Pt>, bidirectional: Boolean = true, toleranceM: Double = TOLERANCE_M): Double {
        if (route.size < 2 || track.isEmpty() || length(route) <= 0.0) return 0.0
        val samples = resample(route)
        val covered = BooleanArray(samples.size)
        val matched = ArrayList<Int>()
        for (q in track) {
            var bi = -1; var bd = Double.MAX_VALUE
            for (i in samples.indices) { val d = dist(q, samples[i]); if (d < bd) { bd = d; bi = i } }
            if (bd <= toleranceM) { matched += bi; for (i in samples.indices) if (!covered[i] && dist(q, samples[i]) <= toleranceM) covered[i] = true }
        }
        if (matched.size < 2) return 0.0
        val fwd = matched.zipWithNext().count { (a, b) -> b >= a }; val back = matched.zipWithNext().count { (a, b) -> b <= a }
        val dir = maxOf(fwd, if (bidirectional) back else 0) / (matched.size - 1).toDouble()
        if (dir < 0.7) return 0.0
        return covered.count { it } / samples.size.toDouble()
    }
}
