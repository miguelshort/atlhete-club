package app.fuckrun.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.fuckrun.domain.Sport
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T

/** Pictogramas: figura corriendo (coral), bota de montaña (bosque), bicicleta (azul) y figura andando (ámbar). */
val Sport.icon: ImageVector get() = when (this) {
    Sport.RUN -> Icons.Rounded.DirectionsRun
    Sport.HIKE -> Icons.Rounded.Hiking
    Sport.BIKE -> Icons.Rounded.DirectionsBike
    Sport.WALK -> Icons.Rounded.DirectionsWalk
}

/** Acento del deporte ajustado a la luminosidad del tema (variantes más oscuras en claro). */
val Sport.color: Color get() = when (this) {
    Sport.RUN -> C.Coral
    Sport.HIKE -> C.Forest
    Sport.BIKE -> C.Sky
    Sport.WALK -> C.Amber
}

@Composable
fun SportBadge(sport: Sport, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(sport.color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
        Icon(sport.icon, null, tint = sport.color, modifier = Modifier.size(size * 0.58f))
    }
}

/**
 * Selector de deporte: pictograma grande, nombre y chevrón en el propio control de cristal. Al tocarlo, el mismo
 * contorno crece desde aquí hasta envolver los cuatro deportes; al elegir, se recoge y deja el pictograma y el nombre.
 * Cerrado deja ver más fondo (tinte menor); los textos adaptan su tinta a lo que hay detrás.
 */
@Composable
fun SportSelector(sport: Sport, modifier: Modifier = Modifier, enabled: Boolean = true, compact: Boolean = false, onChange: (Sport) -> Unit) {
    val sheet = LocalSheet.current
    var bounds by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    val open = bounds != null && sheet.openAnchor == bounds
    val chevron by androidx.compose.animation.core.animateFloatAsState(if (open) 180f else 0f, label = "chevron")
    val probe = remember { GlassProbe() }
    val ink = rememberGlassInk(probe, C.Text)
    Row(
        modifier.then(if (compact) Modifier else Modifier.fillMaxWidth()).heightIn(min = if (compact) 60.dp else 76.dp)
            .onGloballyPositioned { bounds = it.boundsInRoot() }
            .liquid(RoundedCornerShape(if (compact) 30.dp else 26.dp), C.Surface, enabled = enabled, role = Role.DropdownList,
                onClickLabel = "Cambiar deporte", probe = probe, tintBias = -0.12f) {
                sheet.pick("Deporte", Sport.entries, { it.label }, sport, icon = { it.icon }, tint = { it.color }) { onChange(it) }
            }
            .semantics { contentDescription = "Deporte: ${sport.label}. Toca para cambiar" }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SportBadge(sport, if (compact) 44.dp else 56.dp)
        Spacer(Modifier.width(12.dp))
        Column(if (compact) Modifier else Modifier.weight(1f)) {
            if (!compact) Text("Deporte", style = T.Label.copy(color = ink.copy(alpha = 0.7f)))
            Text(sport.label, style = (if (compact) T.BodyStrong else T.Section).copy(color = ink))
        }
        if (compact) Spacer(Modifier.width(6.dp))
        if (enabled) Icon(Icons.Rounded.ExpandMore, null, tint = sport.color, modifier = Modifier.size(28.dp).graphicsLayer { rotationZ = chevron })
    }
}
