package app.fuckrun.domain

import app.fuckrun.data.db.RunEntity
import app.fuckrun.data.db.RunSource
import java.time.*
import java.time.temporal.TemporalAdjusters

enum class Period(val label: String) { WEEK("Semana"), MONTH("Mes"), YEAR("Año") }

data class PeriodRange(val period: Period, val start: LocalDate, val end: LocalDate) {
    fun previous(): PeriodRange = when (period) {
        Period.WEEK -> PeriodRange(period, start.minusWeeks(1), end.minusWeeks(1))
        Period.MONTH -> start.minusMonths(1).let { PeriodRange(period, it, it.with(TemporalAdjusters.lastDayOfMonth())) }
        Period.YEAR -> PeriodRange(period, start.minusYears(1), end.minusYears(1))
    }
    fun next(): PeriodRange = when (period) {
        Period.WEEK -> PeriodRange(period, start.plusWeeks(1), end.plusWeeks(1))
        Period.MONTH -> start.plusMonths(1).let { PeriodRange(period, it, it.with(TemporalAdjusters.lastDayOfMonth())) }
        Period.YEAR -> PeriodRange(period, start.plusYears(1), end.plusYears(1))
    }
    val title: String get() = when (period) {
        Period.WEEK -> "${Fmt.date(start)} – ${Fmt.date(end)}"
        Period.MONTH -> Fmt.month(YearMonth.from(start))
        Period.YEAR -> start.year.toString()
    }
    companion object {
        fun current(p: Period, today: LocalDate = LocalDate.now()) = when (p) {
            Period.WEEK -> today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).let { PeriodRange(p, it, it.plusDays(6)) }
            Period.MONTH -> PeriodRange(p, today.withDayOfMonth(1), today.with(TemporalAdjusters.lastDayOfMonth()))
            Period.YEAR -> PeriodRange(p, today.withDayOfYear(1), today.with(TemporalAdjusters.lastDayOfYear()))
        }
    }
}

data class Totals(
    val distanceM: Double, val activeMs: Long, val sessions: Int, val measured: Int, val manual: Int,
    /** Ritmo agregado = tiempo acumulado / distancia acumulada (solo actividades con distancia). */
    val aggregatedPaceSecPerKm: Double?,
    val activeDays: Set<LocalDate>,
) {
    val avgDurationMs: Long? get() = if (sessions == 0) null else activeMs / sessions
}

object ProgressCalc {
    private val zone: ZoneId get() = ZoneId.systemDefault()
    fun dateOf(r: RunEntity): LocalDate = Instant.ofEpochMilli(r.startedAtWall).atZone(zone).toLocalDate()

    fun inRange(runs: List<RunEntity>, r: PeriodRange) = runs.filter { dateOf(it) in r.start..r.end }

    fun totals(runs: List<RunEntity>): Totals {
        val withDist = runs.filter { (it.distanceM ?: 0.0) > 0 && it.activeMs > 0 }
        val d = withDist.sumOf { it.distanceM!! }
        val t = withDist.sumOf { it.activeMs }
        return Totals(
            distanceM = runs.sumOf { it.distanceM ?: 0.0 },
            activeMs = runs.sumOf { it.activeMs },
            sessions = runs.size,
            measured = runs.count { it.source == RunSource.GPS },
            manual = runs.count { it.source == RunSource.MANUAL },
            aggregatedPaceSecPerKm = if (d >= 100) (t / 1000.0) / (d / 1000.0) else null,
            activeDays = runs.map { dateOf(it) }.toSet(),
        )
    }

    /** Barras del periodo: días (semana), semanas (mes) o meses (año). Valor = km. */
    fun buckets(runs: List<RunEntity>, r: PeriodRange): List<Pair<String, Double>> = when (r.period) {
        Period.WEEK -> (0..6).map { i -> val day = r.start.plusDays(i.toLong())
            Fmt.dayShort(day.dayOfWeek).take(1) to runs.filter { dateOf(it) == day }.sumOf { (it.distanceM ?: 0.0) / 1000 } }
        Period.MONTH -> {
            val res = mutableListOf<Pair<String, Double>>()
            var s = r.start; var i = 1
            while (!s.isAfter(r.end)) {
                val e = minOf(s.plusDays(6), r.end)
                res += "S$i" to runs.filter { dateOf(it) in s..e }.sumOf { (it.distanceM ?: 0.0) / 1000 }
                s = e.plusDays(1); i++
            }
            res
        }
        Period.YEAR -> (1..12).map { m -> Month.of(m).getDisplayName(java.time.format.TextStyle.NARROW, ES) to
            runs.filter { dateOf(it).year == r.start.year && dateOf(it).monthValue == m }.sumOf { (it.distanceM ?: 0.0) / 1000 } }
    }

    /** Serie de ritmo agregado por cubo (null si no hay datos), para la evolución con contexto. */
    fun paceSeries(runs: List<RunEntity>, r: PeriodRange): List<Double?> {
        val measured = runs.filter { it.source == RunSource.GPS }
        fun pace(list: List<RunEntity>) = totals(list).aggregatedPaceSecPerKm
        return when (r.period) {
            Period.WEEK -> (0..6).map { i -> pace(measured.filter { dateOf(it) == r.start.plusDays(i.toLong()) }) }
            Period.MONTH -> buckets(measured, r).indices.map { i -> val s = r.start.plusDays(7L * i); pace(measured.filter { dateOf(it) in s..minOf(s.plusDays(6), r.end) }) }
            Period.YEAR -> (1..12).map { m -> pace(measured.filter { dateOf(it).monthValue == m && dateOf(it).year == r.start.year }) }
        }
    }
}
