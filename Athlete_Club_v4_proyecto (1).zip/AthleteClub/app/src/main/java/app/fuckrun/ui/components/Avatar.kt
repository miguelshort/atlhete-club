package app.fuckrun.ui.components

import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import app.fuckrun.domain.art.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random
import androidx.compose.ui.graphics.Path as CPath

// ------------------------------------------------------------------------------------------- render del dibujo

/** Dibujo listo para Compose: los trazados se convierten una vez por dibujo. */
class ArtFrame(val drawing: Drawing, val sk: Sk?, val vp: Figure.Viewport) {
    internal val cache = HashMap<app.fuckrun.domain.art.Path, CPath>()
    internal fun path(p: app.fuckrun.domain.art.Path): CPath = cache.getOrPut(p) {
        CPath().apply {
            for (c in p.cmds) when (c) {
                is Cmd.M -> moveTo(c.p.x, c.p.y)
                is Cmd.L -> lineTo(c.p.x, c.p.y)
                is Cmd.Q -> quadraticTo(c.c.x, c.c.y, c.p.x, c.p.y)
                is Cmd.C -> cubicTo(c.c1.x, c.c1.y, c.c2.x, c.c2.y, c.p.x, c.p.y)
                Cmd.Z -> close()
            }
        }
    }
}

private fun argb(c: Long) = Color(c.toInt())

private fun DrawScope.ops(f: ArtFrame, list: List<Op>) {
    for (op in list) when (op) {
        is Op.Fill -> drawPath(f.path(op.path), argb(op.color))
        is Op.Stroke -> drawPath(f.path(op.path), argb(op.color), style = Stroke(op.width, cap = StrokeCap.Round, join = StrokeJoin.Round))
        is Op.Group -> {
            val inner: DrawScope.() -> Unit = { if (op.clipOut != null) clipPath(f.path(op.clipOut), ClipOp.Difference) { ops(f, op.ops) } else ops(f, op.ops) }
            if (op.clip != null) clipPath(f.path(op.clip)) { inner() } else inner()
        }
    }
}

/** Escala y centra el dibujo en el espacio disponible. Devuelve (escala, desplazamiento). */
fun fit(vp: Figure.Viewport, w: Float, h: Float): Pair<Float, Offset> {
    val k = minOf(w / vp.w, h / vp.h)
    return k to Offset((w - vp.w * k) / 2f - vp.l * k, (h - vp.h * k) / 2f - vp.t * k)
}

fun DrawScope.drawArt(f: ArtFrame) {
    val (k, o) = fit(f.vp, size.width, size.height)
    withTransform({ translate(o.x, o.y); scale(k, k, Offset.Zero) }) { ops(f, f.drawing.ops) }
}

fun frameOf(scene: Scene, portrait: Boolean): ArtFrame {
    val (d, sk) = Figure.draw(scene)
    return ArtFrame(d, sk, Figure.viewport(scene.pose, portrait, sk))
}

/** Miniatura de una pieza (fichas de tienda y logros), con su propia ilustración. */
@Composable
fun GearThumb(g: Gear, modifier: Modifier, tint: Tint? = null, alpha: Float = 1f) {
    val f = remember(g.id, tint) {
        val d = GearArt.thumbnail(g, tint)
        val b = d.bounds() ?: floatArrayOf(0f, 0f, 10f, 10f)
        ArtFrame(d, null, Figure.Viewport(b[0] - 6f, b[1] - 6f, b[2] - b[0] + 12f, b[3] - b[1] + 12f))
    }
    Canvas(modifier.graphicsLayer { this.alpha = alpha }.semantics { contentDescription = g.name }) { drawArt(f) }
}

// ------------------------------------------------------------------------------------------- avatar vivo

/** Estado de animación compartido (saludo, mirada, sonrisa, parpadeo). */
@Stable
class AvatarMotion {
    val wave = Animatable(-1f)
    val smile = Animatable(0.32f)
    var lookX by mutableFloatStateOf(0f)
    var lookY by mutableFloatStateOf(0f)
    val blink = Animatable(0f)
    var celebrating by mutableStateOf(false)
}

@Composable
fun rememberAvatarMotion() = remember { AvatarMotion() }

/** Saludo con anticipación del codo y retraso de la muñeca (la fase la interpreta el esqueleto). */
suspend fun AvatarMotion.waveOnce() { wave.snapTo(0f); wave.animateTo(1f, tween(1500, easing = LinearEasing)); wave.snapTo(-1f) }

/**
 * Personaje 2D. En reposo, respiración sutil y parpadeos espaciados; con movimiento reducido, pose estática expresiva.
 * [portrait] usa el encuadre de cabeza y hombros (Inicio, 48 dp).
 */
@Composable
fun Avatar(
    look: AvatarLook,
    outfit: Outfit,
    modifier: Modifier = Modifier,
    pose: ArtPose = ArtPose.IDLE,
    view: ArtView = ArtView.THREE_QUARTER,
    animated: Boolean = true,
    portrait: Boolean = false,
    motion: AvatarMotion = rememberAvatarMotion(),
    zoomFace: Float = 0f,
) {
    val reduce = LocalReduceMotion.current
    val live = animated && !reduce
    val breath = if (live) rememberInfiniteTransition(label = "breath").animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b").value else 0f
    if (live) LaunchedEffect(motion) {
        while (isActive) {
            delay(2600L + Random.nextLong(3400))
            motion.blink.animateTo(1f, tween(70)); motion.blink.animateTo(0f, tween(110))
        }
    }
    val expr = Expression(smile = if (reduce) 0.45f else motion.smile.value, lookX = motion.lookX, lookY = motion.lookY, blink = motion.blink.value,
        brow = (motion.smile.value - 0.32f).coerceAtLeast(0f) * 0.8f)
    val w = motion.wave.value
    val frame = remember(look, outfit, pose, view, expr, w, portrait) { frameOf(Scene(look, outfit, view, pose, expr, wave = w), portrait) }
    Canvas(modifier.semantics { contentDescription = "Tu avatar" }) {
        val vp = frame.vp
        val sk = frame.sk
        val zoomed = if (zoomFace > 0f && sk != null) {
            // Encuadre cercano para Rostro y Pelo; al volver, el cuerpo completo.
            val face = Figure.Viewport(sk.hc.x - 60f, sk.hc.y - 70f, 120f, 150f)
            fun l(a: Float, b: Float) = a + (b - a) * zoomFace
            Figure.Viewport(l(vp.l, face.l), l(vp.t, face.t), l(vp.w, face.w), l(vp.h, face.h))
        } else vp
        val f2 = if (zoomed === vp) frame else ArtFrame(frame.drawing, sk, zoomed).also { it.cache.putAll(frame.cache) }
        val (k, o) = fit(f2.vp, size.width, size.height)
        withTransform({
            translate(o.x, o.y); scale(k, k, Offset.Zero)
            // Respiración: el torso sube y baja muy poco.
            if (breath > 0f) scale(1f, 1f + 0.006f * breath, Offset(0f, Figure.GROUND))
        }) { ops(f2, f2.drawing.ops) }
    }
}

/**
 * Avatar del vestidor: tocar la cara lleva la mirada al toque y provoca una sonrisa; tocar la mano hace que salude;
 * deslizar en horizontal alterna entre las vistas dibujadas de frente y de tres cuartos.
 */
@Composable
fun InteractiveAvatar(
    look: AvatarLook, outfit: Outfit, view: ArtView, onView: (ArtView) -> Unit, modifier: Modifier = Modifier,
    pose: ArtPose = ArtPose.IDLE, motion: AvatarMotion = rememberAvatarMotion(), zoomFace: Float = 0f,
) {
    val scope = rememberCoroutineScope()
    var size by remember { mutableStateOf(IntSize.Zero) }
    val currentView by rememberUpdatedState(view)
    val sk = remember(look, outfit, pose, view) { Figure.skeleton(Scene(look, outfit, view, pose)) }
    val vp = remember(pose, sk) { Figure.viewport(pose, false, sk) }
    fun toArt(p: Offset): P {
        val v = if (zoomFace > 0f) Figure.Viewport(sk.hc.x - 60f, sk.hc.y - 70f, 120f, 150f).let { face ->
            Figure.Viewport(vp.l + (face.l - vp.l) * zoomFace, vp.t + (face.t - vp.t) * zoomFace, vp.w + (face.w - vp.w) * zoomFace, vp.h + (face.h - vp.h) * zoomFace) } else vp
        val (k, o) = fit(v, size.width.toFloat(), size.height.toFloat())
        return P((p.x - o.x) / k, (p.y - o.y) / k)
    }
    Box(modifier
        .onSizeChanged { size = it }
        .pointerInput(look, outfit, pose, view, zoomFace) {
            detectTapGestures { pos ->
                val a = toArt(pos)
                val hand = sk.wr[0] + sk.handDir[0] * 8f
                when {
                    (a - hand).len() < 26f || (a - sk.el[0]).len() < 18f -> scope.launch { motion.waveOnce() }
                    (a - sk.hc).len() < 42f -> scope.launch {
                        motion.lookX = ((a.x - sk.hc.x) / 30f).coerceIn(-1f, 1f); motion.lookY = ((a.y - sk.hc.y) / 30f).coerceIn(-1f, 1f)
                        motion.smile.animateTo(0.85f, tween(220)); delay(1300)
                        motion.smile.animateTo(0.32f, tween(500)); motion.lookX = 0f; motion.lookY = 0f
                    }
                }
            }
        }
        .pointerInput(pose) {
            var acc = 0f
            detectHorizontalDragGestures(onDragStart = { acc = 0f }) { _, dx ->
                acc += dx
                if (acc > 48f || acc < -48f) { onView(if (currentView == ArtView.FRONT) ArtView.THREE_QUARTER else ArtView.FRONT); acc = 0f }
            }
        }) {
        Avatar(look, outfit, Modifier.matchParentSize(), pose, view, animated = true, motion = motion, zoomFace = zoomFace)
    }
}


// ------------------------------------------------------------------------------------------- retrato en caché

/**
 * Retrato en caché (PNG) que se actualiza al guardar el conjunto: lo usan los sitios fuera de pantalla (avisos) y
 * permite consultar el aspecto sin recalcular. Se dibuja con el mismo motor, sin cristal ni animación.
 */
object PortraitCache {
    fun file(ctx: Context) = File(ctx.filesDir, "avatar_portrait.png")

    fun save(ctx: Context, look: AvatarLook, outfit: Outfit, px: Int = 192) = runCatching {
        val bmp = ImageBitmap(px, px)
        val canvas = androidx.compose.ui.graphics.Canvas(bmp)
        val f = frameOf(Scene(look, outfit), portrait = true)
        CanvasDrawScope().draw(Density(1f), LayoutDirection.Ltr, canvas, androidx.compose.ui.geometry.Size(px.toFloat(), px.toFloat())) { drawArt(f) }
        file(ctx).outputStream().use { bmp.asAndroidBitmap().compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun load(ctx: Context): android.graphics.Bitmap? = runCatching { android.graphics.BitmapFactory.decodeFile(file(ctx).path) }.getOrNull()
}
