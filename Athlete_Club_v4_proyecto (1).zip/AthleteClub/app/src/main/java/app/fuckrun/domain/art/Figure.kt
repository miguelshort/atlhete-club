package app.fuckrun.domain.art

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/*
 * Personaje 2D de cuerpo entero, dibujado por piezas sobre un esqueleto (cabeza, clavícula, codo, mano, cintura,
 * rodilla, tobillo y pie). Las prendas se adaptan a hombros, cintura y largo de pierna porque se construyen sobre las
 * mismas articulaciones. Orden de capas, de atrás hacia delante:
 *   bici · volumen de mochila · pelo trasero · brazo lejano · piernas · pelvis · torso y prendas · cabeza · pelo delantero
 *   y casco · brazo cercano y lo que sujeta.
 */

enum class ArtView { FRONT, THREE_QUARTER }
enum class ArtPose { IDLE, RUN, HIKE, BIKE, WALK }

data class Expression(val smile: Float = 0.3f, val lookX: Float = 0f, val lookY: Float = 0f, val blink: Float = 0f, val brow: Float = 0f)

data class Scene(
    val look: AvatarLook,
    val outfit: Outfit,
    val view: ArtView = ArtView.THREE_QUARTER,
    val pose: ArtPose = ArtPose.IDLE,
    val expr: Expression = Expression(),
    /** Saludo con la mano cercana: < 0 sin saludo; 0…1 fase. */
    val wave: Float = -1f,
    /** Respiración 0…1. */
    val breath: Float = 0f,
)

/** Esqueleto resuelto. Índice 0 = lado cercano (izquierda de la pantalla), 1 = lado lejano. */
class Sk(
    val view: ArtView, val pose: ArtPose,
    val hc: P, val hr: Float, val headTilt: Float,
    val neck: P, val up: P, val right: P,
    val sh: Array<P>, val el: Array<P>, val wr: Array<P>, val handDir: Array<P>, val handMode: Array<Hand>,
    val pelvis: P, val waist: P, val hip: Array<P>, val kn: Array<P>, val an: Array<P>, val toe: Array<P>,
    val shW: Float, val waistW: Float, val hipW: Float, val armW: Float, val legW: Float, val neckW: Float, val farK: Float,
    val bike: BikeGeo?, val poleGrip: Array<P?>,
) {
    val q get() = view == ArtView.THREE_QUARTER
    val chest get() = neck.lerp(waist, 0.32f)
    /** Dirección de la cara: +1 hacia la derecha de la pantalla en tres cuartos. */
    val facing get() = if (q) 1f else 0f
}

enum class Hand { RELAXED, OPEN, GRIP }

class BikeGeo(val rear: P, val front: P, val r: Float, val bb: P, val saddle: P, val seatJoin: P, val headTop: P, val headBottom: P,
              val bar: P, val hood: P, val pedal: Array<P>)

object Figure {
    const val GROUND = 384f

    // ------------------------------------------------------------------ esqueleto

    private fun ik(root: P, target: P, l1: Float, l2: Float, bend: Float): P {
        val d = target - root
        val dist = d.len().coerceIn(abs(l1 - l2) + 0.5f, l1 + l2 - 0.5f)
        val a = acos(((l1 * l1 + dist * dist - l2 * l2) / (2 * l1 * dist)).coerceIn(-1f, 1f))
        val base = atan2(d.y, d.x)
        val ang = base + bend * a
        return root + P(cos(ang), sin(ang)) * l1
    }

    private fun smoothstep(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }

    fun skeleton(s: Scene): Sk {
        val look = s.look
        val b = look.build.coerceIn(0, 3); val h = look.height.coerceIn(0, 2)
        val ls = floatArrayOf(0.93f, 1f, 1.07f)[h]
        val ts = floatArrayOf(0.95f, 1f, 1.04f)[h]
        val shW = floatArrayOf(26f, 32f, 37f, 43f)[b]
        val waistW = floatArrayOf(13.5f, 18.5f, 19.5f, 29f)[b]
        val hipW = floatArrayOf(14.5f, 18f, 19f, 25f)[b]
        val armW = floatArrayOf(10.5f, 13f, 15.5f, 17.5f)[b]
        val legW = floatArrayOf(14.5f, 18f, 21f, 25f)[b]
        val neckW = floatArrayOf(9.5f, 11f, 13f, 14.5f)[b]
        val upper = 52f * ls; val fore = 47f * ls
        val thigh = 80f * ls; val shin = 77f * ls; val torso = 100f * ts
        val q = s.view == ArtView.THREE_QUARTER || s.pose != ArtPose.IDLE
        val view = if (q) ArtView.THREE_QUARTER else ArtView.FRONT
        val farK = if (q) 0.74f else 1f

        // Ángulos (desde la vertical hacia abajo; + = hacia delante/derecha).
        var lean = 0f; var tilt = 0f; var headTilt = 0f
        val upperA = floatArrayOf(-0.14f, 0.16f); val foreA = floatArrayOf(-0.04f, 0.1f)
        val thighA = floatArrayOf(0.03f, 0.1f); val shinA = floatArrayOf(0f, 0.02f)
        val mode = arrayOf(Hand.RELAXED, Hand.RELAXED)
        when (s.pose) {
            ArtPose.IDLE -> { tilt = 3f; if (q) { thighA[1] = -0.06f; shinA[1] = 0.02f; upperA[0] = -0.1f; upperA[1] = 0.12f } }
            ArtPose.RUN -> { lean = 0.13f; upperA[0] = -0.62f; foreA[0] = 0.95f; upperA[1] = 0.62f; foreA[1] = 2.05f
                thighA[0] = 0.78f; shinA[0] = 0.02f; thighA[1] = -0.36f; shinA[1] = -1.35f; mode[0] = Hand.GRIP; mode[1] = Hand.GRIP; headTilt = -0.05f }
            ArtPose.WALK -> { lean = 0.04f; upperA[0] = -0.3f; foreA[0] = -0.1f; upperA[1] = 0.3f; foreA[1] = 0.62f
                thighA[0] = 0.32f; shinA[0] = 0.08f; thighA[1] = -0.24f; shinA[1] = -0.46f }
            ArtPose.HIKE -> { lean = 0.1f; upperA[1] = -0.1f; foreA[1] = 0.3f; thighA[0] = 0.34f; shinA[0] = 0.02f; thighA[1] = -0.14f; shinA[1] = -0.36f
                mode[0] = Hand.GRIP }
            ArtPose.BIKE -> { mode[0] = Hand.GRIP; mode[1] = Hand.GRIP }
        }

        // Piernas relativas a la pelvis (0,0); después se apoya el pie más bajo en el suelo.
        var pelvis = P(0f, 0f)
        val hip = arrayOf(P(-hipW, -tilt), P(hipW * farK, tilt))
        val kn = arrayOf(P(0f, 0f), P(0f, 0f)); val an = arrayOf(P(0f, 0f), P(0f, 0f)); val toe = arrayOf(P(0f, 0f), P(0f, 0f))
        var bike: BikeGeo? = null
        if (s.pose == ArtPose.BIKE) {
            val r = 64f; val rear = P(-6f, GROUND - r); val front = P(196f, GROUND - r)
            val bb = P(72f, GROUND - r + 6f)
            val saddle = P(36f, 200f); val seatJoin = P(42f, 222f)
            val headTop = P(166f, 214f); val headBottom = P(174f, 252f)
            val bar = P(176f, 198f); val hood = P(190f, 206f)
            val crank = 30f
            val pedal = arrayOf(bb + P(crank * 0.94f, -crank * 0.34f), bb + P(-crank * 0.94f, crank * 0.34f))
            bike = BikeGeo(rear, front, r, bb, saddle, seatJoin, headTop, headBottom, bar, hood, pedal)
            pelvis = saddle + P(4f, -8f)
            hip[0] = pelvis + P(-3f, 0f); hip[1] = pelvis + P(3f, -2f)
            for (i in 0..1) {
                an[i] = pedal[i] + P(-7f, -9f)
                kn[i] = ik(hip[i], an[i], thigh, shin, -1f)
                toe[i] = an[i] + P(21f, 7f)
            }
            lean = 1.0f; headTilt = -0.5f
        } else {
            for (i in 0..1) {
                kn[i] = hip[i] + dirDown(thighA[i]) * thigh
                an[i] = kn[i] + dirDown(shinA[i]) * shin
                toe[i] = if (q) an[i] + rot(P(21f, 6f), P(0f, 0f), -shinA[i] * 1.1f)
                else an[i] + P(if (i == 0) -6f else 6f, 9f)
            }
            val low = max(max(an[0].y + 10f, toe[0].y + 4f), max(an[1].y + 10f, toe[1].y + 4f))
            val cx = if (q) 96f else 100f
            val dx = cx; val dy = GROUND - low
            pelvis = P(dx, dy)
            for (i in 0..1) { hip[i] = hip[i] + pelvis; kn[i] = kn[i] + pelvis; an[i] = an[i] + pelvis; toe[i] = toe[i] + pelvis }
        }

        val up = P(sin(lean), -cos(lean))
        val right = P(-up.y, up.x)
        val breath = s.breath.coerceIn(0f, 1f) * 1.3f
        val sc = pelvis + up * (torso + breath)
        val sh = arrayOf(sc - right * shW + up * (if (s.pose == ArtPose.IDLE) -2f else 0f), sc + right * (shW * farK) + up * (if (s.pose == ArtPose.IDLE) 1.5f else 0f))
        val neck = sc + up * 5f
        val hr = 25f
        val hc = neck + up * 40f + P(if (q) 3f else 0f, 0f)
        val waist = pelvis.lerp(sc, 0.36f)

        val el = arrayOf(P(0f, 0f), P(0f, 0f)); val wr = arrayOf(P(0f, 0f), P(0f, 0f)); val hd = arrayOf(P(0f, 1f), P(0f, 1f))
        val grip = arrayOf<P?>(null, null)
        for (i in 0..1) {
            when {
                bike != null -> { val t = if (i == 0) bike.hood else bike.hood + P(-6f, -3f)
                    el[i] = ik(sh[i], t, upper, fore, 1f); wr[i] = t; hd[i] = (t - el[i]).norm() }
                s.pose == ArtPose.HIKE && i == 0 -> { val g = hip[0] + P(40f, -16f); grip[0] = g
                    el[i] = ik(sh[i], g, upper, fore, 1f); wr[i] = g; hd[i] = P(0.3f, 0.95f).norm() }
                s.pose == ArtPose.HIKE && i == 1 -> { val g = hip[1] + P(-30f, -12f); grip[1] = g
                    el[i] = ik(sh[i], g, upper, fore, 1f); wr[i] = g; hd[i] = (g - el[i]).norm() }
                else -> { el[i] = sh[i] + dirDown(upperA[i]) * upper; wr[i] = el[i] + dirDown(foreA[i]) * fore; hd[i] = dirDown(foreA[i] + if (i == 0) -0.08f else 0.08f) }
            }
        }
        // Saludo: anticipación del codo y retraso de la muñeca.
        if (s.wave >= 0f) {
            val ph = s.wave.coerceIn(0f, 1f)
            val raise = smoothstep(0.1f, 0.32f, ph) * (1f - smoothstep(0.8f, 1f, ph))
            val antic = -0.12f * smoothstep(0f, 0.08f, ph) * (1f - smoothstep(0.08f, 0.2f, ph))
            val sway = sin(ph * 2f * PI.toFloat() * 2.2f)
            val sway2 = sin(ph * 2f * PI.toFloat() * 2.2f - 0.7f)
            val ua = upperA[0] + antic + (-2.25f - upperA[0]) * raise
            val fa = foreA[0] + ((PI.toFloat() - 0.08f + 0.32f * sway) - foreA[0]) * raise
            el[0] = sh[0] + dirDown(ua) * upper; wr[0] = el[0] + dirDown(fa) * fore
            hd[0] = dirDown(fa + 0.38f * sway2 * raise); mode[0] = if (raise > 0.4f) Hand.OPEN else Hand.RELAXED
        }
        return Sk(view, s.pose, hc, hr, headTilt, neck, up, right, sh, el, wr, hd, mode, pelvis, waist, hip, kn, an, toe,
            shW, waistW, hipW, armW, legW, neckW, farK, bike, grip)
    }

    // ------------------------------------------------------------------ utilidades de forma

    /** Contorno de un tubo que sigue una polilínea con grosor variable (brazos, piernas, mangas, perneras). */
    fun tube(pts: List<P>, ws: List<Float>, capStart: Boolean = true, capEnd: Boolean = true): Path {
        val n = pts.size
        val l = ArrayList<P>(); val r = ArrayList<P>()
        for (i in 0 until n) {
            val dIn = if (i > 0) (pts[i] - pts[i - 1]).norm() else (pts[1] - pts[0]).norm()
            val dOut = if (i < n - 1) (pts[i + 1] - pts[i]).norm() else dIn
            val d = (dIn + dOut).norm().let { if (it.len() < 0.1f) dIn else it }
            val nn = d.perp()
            l += pts[i] + nn * (ws[i] / 2); r += pts[i] - nn * (ws[i] / 2)
        }
        val dEnd = (pts[n - 1] - pts[n - 2]).norm(); val dStart = (pts[1] - pts[0]).norm()
        val ring = ArrayList<P>()
        if (capStart) ring += pts[0] - dStart * (ws[0] * 0.3f)
        ring += l
        if (capEnd) ring += pts[n - 1] + dEnd * (ws[n - 1] * 0.32f)
        ring += r.reversed()
        return if (capStart && capEnd) Path.smooth(ring, true) else {
            // Bordes rectos en los extremos abiertos (mangas, perneras): sin redondeo que invada la piel.
            val pth = Path(); val all = ring
            pth.moveTo(all[0]); for (i in 1 until all.size) pth.lineTo(all[i]); pth.close()
            Path.smooth(all, true)
        }
    }

    /** Corta una polilínea a la fracción t de su longitud. */
    fun cut(pts: List<P>, t: Float): List<P> {
        val total = pts.zipWithNext { a, b -> (b - a).len() }.sum()
        var left = total * t.coerceIn(0.02f, 1f)
        val out = mutableListOf(pts[0])
        for (i in 1 until pts.size) {
            val seg = (pts[i] - pts[i - 1]).len()
            if (left >= seg) { out += pts[i]; left -= seg } else { out += pts[i - 1].lerp(pts[i], left / seg); break }
        }
        if (out.size < 2) out += pts[0] + (pts[1] - pts[0]).norm()
        return out
    }

    fun widthsAlong(pts: List<P>, full: List<P>, fullW: List<Float>): List<Float> = pts.map { q ->
        // Interpola el grosor del tramo original más cercano.
        var best = fullW[0]; var bd = Float.MAX_VALUE
        for (i in 0 until full.size - 1) {
            val a = full[i]; val b = full[i + 1]; val ab = b - a
            val t = (((q.x - a.x) * ab.x + (q.y - a.y) * ab.y) / (ab.x * ab.x + ab.y * ab.y).coerceAtLeast(1e-3f)).coerceIn(0f, 1f)
            val pp = a + ab * t; val dd = (q - pp).len()
            if (dd < bd) { bd = dd; best = fullW[i] + (fullW[i + 1] - fullW[i]) * t }
        }
        best
    }

    fun armPts(sk: Sk, i: Int) = listOf(sk.sh[i] + sk.up * (-3f), sk.el[i], sk.wr[i])
    fun armWs(sk: Sk, i: Int) = (if (i == 1) sk.farK.coerceAtLeast(0.88f) else 1f).let { k -> listOf(sk.armW * 1.18f * k, sk.armW * 0.84f * k, sk.armW * 0.62f * k) }
    fun legPts(sk: Sk, i: Int) = listOf(sk.hip[i] + sk.up * 4f, sk.kn[i], sk.an[i])
    fun legWs(sk: Sk, i: Int) = (if (i == 1) 0.94f else 1f).let { k -> listOf(sk.legW * 1.18f * k, sk.legW * 0.74f * k, sk.legW * 0.46f * k) }

    /**
     * Contorno del torso (o de una prenda de torso si [e] > 0). [hem] = caída del bajo bajo la cadera (negativo: más corto).
     * [neckDrop] = profundidad del escote; [neckUp] > 0 sube el cuello (cuello alto).
     */
    fun torso(sk: Sk, e: Float, hem: Float, neckDrop: Float = 7f, neckUp: Float = 0f, neckWide: Float = 1f, sleeveless: Boolean = false): Path {
        val u = sk.up; val r = sk.right; val fk = sk.farK
        val nw = sk.neckW * neckWide + e * 0.6f
        val nL = sk.neck - r * nw + u * (2f + neckUp); val nR = sk.neck + r * (nw * fk) + u * (2f + neckUp)
        val sL = sk.sh[0]; val sR = sk.sh[1]
        val shTopL = sL + r * 7f + u * (5f + e * 0.4f); val shTopR = sR - r * (7f * fk) + u * (5f + e * 0.4f)
        val shOutL = sL - r * (if (sleeveless) -5f else 5f + e) - u * 2f; val shOutR = sR + r * ((if (sleeveless) -5f else 5f + e) * fk) - u * 2f
        val apL = sL - u * 24f + r * (if (sleeveless) 6f else 2f - e * 0.5f); val apR = sR - u * 24f - r * ((if (sleeveless) 6f else 2f - e * 0.5f) * fk)
        val wL = sk.waist - r * (sk.waistW + e); val wR = sk.waist + r * ((sk.waistW + e) * fk)
        val hipC = sk.pelvis - u * hem
        val hL = hipC - r * (sk.hipW + 5f + e); val hR = hipC + r * ((sk.hipW + 5f + e) * fk)
        val hMid = hipC - u * 1.5f
        val neckMid = sk.neck - u * (neckDrop - neckUp) + r * (if (sk.q) 3f else 0f)
        val pts = listOf(nL, shTopL, shOutL, apL, wL, hL + u * 3f, hL, hMid, hR, hR + u * 3f, wR, apR, shOutR, shTopR, nR, nR.lerp(neckMid, 0.6f) + r * 0.5f, neckMid, nL.lerp(neckMid, 0.6f))
        return Path.smooth(pts, true)
    }

    // ------------------------------------------------------------------ dibujo completo

    data class Viewport(val l: Float, val t: Float, val w: Float, val h: Float)
    fun viewport(pose: ArtPose, portrait: Boolean, sk: Sk? = null): Viewport = when {
        portrait && sk != null -> Viewport(sk.hc.x - 46f, sk.hc.y - 52f, 92f, 108f)
        pose == ArtPose.BIKE -> Viewport(-80f, 92f, 360f, 300f)
        else -> Viewport(0f, 0f, 200f, 400f)
    }

    fun draw(s: Scene): Pair<Drawing, Sk> {
        val look = s.look.migrated()
        val sk = skeleton(s.copy(look = look))
        val d = Drawing()
        val skin = Looks.skins[look.skin.coerceIn(0, Looks.skins.lastIndex)].color
        val o = s.outfit.migrated()
        val head = o.gear(Slot.HEAD)

        if (sk.bike != null) Bike.draw(d, sk.bike, o, behindRider = true)
        GearArt.back(d, sk, o)
        Hair.back(d, sk, look, head)
        GearArt.carry(d, sk, o, 1)
        arm(d, sk, 1, skin, o)
        leg(d, sk, 1, skin, o)
        leg(d, sk, 0, skin, o)
        GearArt.pelvis(d, sk, o)
        // Cuello y torso de piel (se ven con tirantes o escotes).
        d.solid(Path.limb(sk.neck - sk.up * 6f, sk.hc + sk.up * (-18f), sk.neckW * 2f, sk.neckW * 1.7f, 0f), skin, line = 1.3f)
        d.solid(torso(sk, 0f, -10f, 3f, sleeveless = true), skin, line = 1.3f)
        GearArt.torso(d, sk, o)
        Face.draw(d, sk, look, s.expr, skin, o)
        Hair.front(d, sk, look, head)
        GearArt.head(d, sk, o)
        Hair.overHeadwear(d, sk, look, head)
        GearArt.frontOfTorso(d, sk, o)
        if (sk.bike != null) Bike.draw(d, sk.bike, o, behindRider = false)
        GearArt.carry(d, sk, o, 0)
        arm(d, sk, 0, skin, o)
        return d to sk
    }

    fun arm(d: Drawing, sk: Sk, i: Int, skin: Long, o: Outfit) {
        val pts = armPts(sk, i); val ws = armWs(sk, i)
        val sk2 = if (i == 1) Col.shade(skin, 0.1f) else skin
        d.solid(tube(pts, ws), sk2, line = 1.4f)
        GearArt.armLayers(d, sk, o, i)
        val gloved = o.gear(Slot.HANDS)
        handShape(d, sk, i, if (gloved != null && !gloved.d.contains(D.FINGERLESS)) GearArt.color(o, gloved, true) else sk2, gloved)
        GearArt.afterHand(d, sk, o, i)
    }

    fun handShape(d: Drawing, sk: Sk, i: Int, color: Long, glove: Gear?) {
        val w = sk.wr[i]; val dir = sk.handDir[i]; val n = dir.perp() * (if (i == 0) -1f else 1f)
        val s = if (i == 1) 0.92f else 1f
        val base = w + dir * 3f
        val palmC = base + dir * (7f * s)
        when (sk.handMode[i]) {
            Hand.GRIP -> {
                val fist = Path.smooth(listOf(base - n * 6f * s, palmC - n * 7.5f * s + dir * 3f, base + dir * 13f * s, palmC + n * 7.5f * s + dir * 2f, base + n * 6f * s), true)
                d.solid(fist, color, line = 1.2f, depth = 3f)
                for (k in 0..2) { val a = palmC + dir * 3f - n * (3.5f - k * 3.4f) * s
                    d.stroke(Path.line(a, a + dir * 3.5f + n * 0.4f), Col.ink(color), 0.8f) }
                // Pulgar sobre los dedos.
                d.solid(Path.limb(base + n * 4f * s, palmC + n * 1f + dir * 4f, 4.6f * s, 3.6f * s, 0f), Col.shade(color, 0.08f), line = 0.9f, depth = 1.5f)
            }
            Hand.OPEN, Hand.RELAXED -> {
                val spread = if (sk.handMode[i] == Hand.OPEN) 0.22f else 0.06f
                val palm = Path.smooth(listOf(base - n * 5.5f * s, palmC - n * 6.5f * s, base + dir * 12.5f * s, palmC + n * 6.2f * s, base + n * 5.5f * s), true)
                d.solid(palm, color, line = 1.1f, depth = 2.5f)
                val fingerLen = floatArrayOf(10f, 11.2f, 10.6f, 8.4f)
                for (k in 0..3) {
                    val off = (k - 1.5f) * 3.1f * s
                    val a = palmC + dir * 4.5f * s + n * off
                    val ang = (k - 1.5f) * spread
                    val fd = rot(dir, P(0f, 0f), ang * (if (i == 0) -1f else 1f))
                    val curl = if (sk.handMode[i] == Hand.RELAXED) 0.25f else 0f
                    val mid = a + fd * (fingerLen[k] * 0.55f * s)
                    val tip = mid + rot(fd, P(0f, 0f), curl * (if (i == 0) 1f else -1f)) * (fingerLen[k] * 0.45f * s)
                    d.solid(tube(listOf(a, mid, tip), listOf(3.7f * s, 3.3f * s, 2.9f * s)), color, line = 0.9f, depth = 1.2f, accent = false)
                }
                val tb = base + n * 5f * s
                val td = rot(dir, P(0f, 0f), if (i == 0) 0.9f else -0.9f)
                d.solid(tube(listOf(tb, tb + td * 6f, tb + td * 10f + dir * 2f), listOf(4.6f * s, 4f * s, 3.2f * s)), color, line = 0.9f, depth = 1.2f, accent = false)
            }
        }
        if (glove != null) GearArt.gloveDetail(d, sk, i, glove, palmC, dir, n)
    }

    fun leg(d: Drawing, sk: Sk, i: Int, skin: Long, o: Outfit) {
        val sk2 = if (i == 1) Col.shade(skin, 0.1f) else skin
        d.solid(tube(legPts(sk, i), legWs(sk, i)), sk2, line = 1.4f)
        // Pie descalzo (casi siempre lo cubre el calzado).
        d.solid(Path.limb(sk.an[i], sk.toe[i], sk.legW * 0.5f, sk.legW * 0.36f, 0f), sk2, line = 1.1f)
        GearArt.legLayers(d, sk, o, i)
    }
}

// ====================================================================================================== cara

object Face {
    /** Transformación de tres cuartos para la cara: el lado lejano se estrecha y los rasgos se desplazan hacia él. */
    fun fx(sk: Sk, x: Float) = if (!sk.q) x else (if (x < 0) x * 1.02f else x * 0.8f) + 4.5f
    fun skull(sk: Sk, x: Float) = if (!sk.q) x else (if (x < 0) x * 1.1f else x * 0.88f) + 1f

    private data class FaceShape(val cheek: Float, val jaw: Float, val len: Float, val chin: Float)
    private val shapes = listOf(FaceShape(1f, 0.86f, 1f, 0.5f), FaceShape(0.93f, 0.72f, 1.06f, 0.36f), FaceShape(0.97f, 0.93f, 1f, 0.58f),
        FaceShape(1.01f, 0.64f, 1.03f, 0.26f), FaceShape(0.87f, 0.75f, 1.14f, 0.4f), FaceShape(1.03f, 0.66f, 1.06f, 0.3f))

    fun head(sk: Sk, look: AvatarLook): Path {
        val f = shapes[look.face.coerceIn(0, 5)]; val r = sk.hr
        val pts = listOf(P(0f, -31f), P(r * 0.78f, -25f), P(r * f.cheek, -6f), P(r * f.cheek * 0.98f, 4f), P(r * f.jaw * 0.92f, 19f * f.len),
            P(r * f.chin * 0.5f, 29f * f.len), P(0f, 31.5f * f.len), P(-r * f.chin * 0.5f, 29f * f.len), P(-r * f.jaw * 0.92f, 19f * f.len),
            P(-r * f.cheek * 0.98f, 4f), P(-r * f.cheek, -6f), P(-r * 0.78f, -25f))
        return Path.smooth(pts.map { P(if (it.y < 2f) skull(sk, it.x) else fx(sk, it.x) - (if (sk.q) 2f else 0f), it.y) }.map { at(sk, it) }, true)
    }

    fun cheekX(sk: Sk, look: AvatarLook) = shapes[look.face.coerceIn(0, 5)].cheek * sk.hr
    fun chinY(look: AvatarLook) = 31.5f * shapes[look.face.coerceIn(0, 5)].len

    /** De coordenadas locales de la cabeza a la escena (con la inclinación de la cabeza). */
    fun at(sk: Sk, q: P): P = rot(sk.hc + q, sk.hc, sk.headTilt * 0.6f + (if (sk.pose == ArtPose.BIKE) 0.9f else 0f) * 0f)

    fun draw(d: Drawing, sk: Sk, look: AvatarLook, e: Expression, skin: Long, o: Outfit) {
        val r = sk.hr
        val cx = cheekX(sk, look)
        val earC = if (sk.q) P(skull(sk, -cx) + 3f, 4f) else P(-cx, 4f)
        val ear = Path.smooth(listOf(earC + P(1f, -9f), earC + P(-6f, -7f), earC + P(-6.5f, 3f), earC + P(-2f, 10f), earC + P(2f, 7f)), true).map { at(sk, it) }
        d.solid(ear, skin, line = 1.2f, depth = 2.5f)
        d.stroke(Path.smooth(listOf(earC + P(-3.5f, -4f), earC + P(-4f, 2f), earC + P(-1f, 5f)), false).map { at(sk, it) }, Col.shade(skin, 0.3f), 1f)
        if (!sk.q) {
            val ear2C = P(cx, 4f)
            val ear2 = Path.smooth(listOf(ear2C + P(-1f, -9f), ear2C + P(6f, -7f), ear2C + P(6.5f, 3f), ear2C + P(2f, 10f), ear2C + P(-2f, 7f)), true).map { at(sk, it) }
            d.solid(ear2, skin, line = 1.2f, depth = 2.5f)
        }
        val headP = head(sk, look)
        d.solid(headP, skin, line = 1.5f, depth = 5f)
        // Sombra recortada de la mandíbula sobre el cuello ya la da el orden; aquí, mejilla y bajo la ceja.
        d.group(clip = headP) {
            fill(Path.ellipse(at(sk, P(fx(sk, r * 0.62f), 10f)), 6f, 3.6f), Col.mix(skin, Col.rgb(0xE07060), 0.22f).let { Col.of(Col.r(it), Col.g(it), Col.b(it), 110) })
            if (!sk.q) fill(Path.ellipse(at(sk, P(fx(sk, -r * 0.62f), 10f)), 6f, 3.6f), Col.mix(skin, Col.rgb(0xE07060), 0.22f).let { Col.of(Col.r(it), Col.g(it), Col.b(it), 110) })
        }
        freckles(d, sk, look, skin)
        eyes(d, sk, look, e, skin)
        nose(d, sk, look, skin)
        mouth(d, sk, look, e, skin)
        facialHair(d, sk, look, headP)
        if (o.gear(Slot.EYES) == null) dailyGlasses(d, sk, look)
    }

    private fun freckles(d: Drawing, sk: Sk, look: AvatarLook, skin: Long) {
        val n = (look.freckles.coerceIn(0f, 1f) * 26).toInt(); if (n == 0) return
        val c = Col.mix(skin, Col.rgb(0x6B3A22), 0.45f)
        var seed = 7
        repeat(n) {
            seed = (seed * 1103515245 + 12345) and 0x7fffffff
            val side = if (it % 2 == 0) -1f else 1f
            val x = side * (4f + (seed % 100) / 100f * 13f); val y = 5f + ((seed / 100) % 100) / 100f * 8f
            if (sk.q && side < 0 && it % 4 == 0) return@repeat
            d.fill(Path.circle(at(sk, P(fx(sk, x), y)), 0.55f + (seed % 3) * 0.18f), c)
        }
    }

    private data class EyeShape(val w: Float, val h: Float, val tilt: Float, val lid: Float, val crease: Boolean)
    private val eyeShapes = listOf(EyeShape(9.2f, 4.4f, 0.08f, 0.3f, true), EyeShape(8.4f, 5.6f, 0f, 0.2f, true), EyeShape(9.4f, 3.7f, 0f, 0.62f, true),
        EyeShape(9.6f, 3.9f, 0.2f, 0.3f, true), EyeShape(9.2f, 4.3f, -0.15f, 0.36f, true), EyeShape(9.6f, 3.4f, 0.05f, 0f, false))

    private fun eyes(d: Drawing, sk: Sk, look: AvatarLook, e: Expression, skin: Long) {
        val es = eyeShapes[look.eyes.coerceIn(0, 5)]
        val iris = Looks.irises[look.iris.coerceIn(0, 7)].color
        val ink = Col.rgb(0x241814)
        for (side in listOf(-1f, 1f)) {
            val far = sk.q && side > 0
            val near = sk.q && side < 0
            val k = if (far) 0.8f else 1f
            val c0 = P(fx(sk, side * 9.4f), 1f)
            val w = es.w * k; val h = es.h
            val tilt = es.tilt * (if (side < 0) -1f else 1f)
            fun pt(t: Float, top: Boolean): P { // t: -1 (interior) … 1 (exterior)
                val x = c0.x + t * w / 2 * side
                val shape = (1 - t * t)
                val y = c0.y + (if (top) -h * (0.62f * shape + 0.38f * shape * shape) else h * 0.42f * shape) - tilt * t * 4f
                return P(x, y)
            }
            val upper = (0..8).map { pt(-1f + it / 4f, true) }
            val lower = (0..8).map { pt(1f - it / 4f, false) }
            val blink = e.blink.coerceIn(0f, 1f)
            val eyeShape = Path.smooth(upper + lower.drop(1).dropLast(1), true).map { at(sk, it) }
            if (blink < 0.85f) {
                d.fill(eyeShape, Col.rgb(0xF7F2EC))
                d.group(clip = eyeShape) {
                    val lx = e.lookX.coerceIn(-1f, 1f) * w * 0.22f + (if (sk.q) 1.2f else 0f)
                    val ly = e.lookY.coerceIn(-1f, 1f) * h * 0.2f
                    val ic = at(sk, c0 + P(lx, ly + 0.2f))
                    val ir = h * 0.78f * (if (far) 0.92f else 1f)
                    d.fill(Path.circle(ic, ir), iris)
                    d.fill(Path.circle(ic, ir * 0.45f), Col.rgb(0x120C0A))
                    d.fill(Path.circle(ic + P(-ir * 0.35f, -ir * 0.38f), ir * 0.24f), Col.rgb(0xFFFFFF))
                    // Sombra del párpado superior sobre el ojo.
                    d.fill(Path.smooth(upper.map { it + P(0f, 1.4f) } + upper.reversed().map { it + P(0f, -3f) }, true).map { at(sk, it) }, Col.of(60, 40, 30, 60))
                    // Párpado que baja al parpadear.
                    if (blink > 0f) d.fill(Path.rect(c0.x - w, c0.y - h * 1.2f, c0.x + w, c0.y - h * 1.2f + h * 2f * blink).map { at(sk, it) }, skin)
                }
                // Línea del párpado superior: más peso en el exterior.
                d.stroke(Path.smooth(upper, false).map { at(sk, it) }, ink, 1.5f)
                d.stroke(Path.smooth(upper.subList(4, 9), false).map { at(sk, it) }, ink, 2.1f)
                d.stroke(Path.smooth(lower.subList(1, 6), false).map { at(sk, it) }, Col.mix(ink, skin, 0.55f), 0.8f)
            } else {
                d.stroke(Path.smooth(lower.map { it + P(0f, -h * 0.25f) }.subList(1, 8), false).map { at(sk, it) }, ink, 1.6f)
            }
            if (es.crease) d.stroke(Path.smooth(upper.subList(2, 9).map { it + P(0f, -2.4f - es.lid * 1.2f) }, false).map { at(sk, it) }, Col.shade(skin, 0.45f), 0.9f)
            brow(d, sk, look, e, side, c0, w, skin, near)
        }
    }

    private data class BrowShape(val th: Float, val arch: Float, val angle: Float, val len: Float)
    private val browShapes = listOf(BrowShape(2.3f, 0.3f, 0.02f, 1.1f), BrowShape(2.2f, 1.9f, 0.06f, 1.1f), BrowShape(2.0f, 0.9f, 0f, 1.05f),
        BrowShape(3.4f, 0.9f, 0.02f, 1.15f), BrowShape(1.3f, 1.2f, 0.02f, 1.05f), BrowShape(2.4f, 1.6f, 0.16f, 1.1f))

    private fun brow(d: Drawing, sk: Sk, look: AvatarLook, e: Expression, side: Float, eye: P, w: Float, skin: Long, near: Boolean) {
        val b = browShapes[look.brows.coerceIn(0, 5)]
        val hair = Looks.hairColors[look.hairColor.coerceIn(0, 11)].color
        // Ceja que puede levantarse; la del lado lejano un poco más (asimetría).
        val raise = e.brow * (if (side > 0) 3.6f else 2.6f)
        val y0 = eye.y - 7.5f - raise
        val inner = P(eye.x - side * w * 0.55f, y0 + 1.2f + b.angle * 6f)
        val peak = P(eye.x + side * w * 0.15f, y0 - b.arch)
        val outer = P(eye.x + side * w * 0.62f * b.len, y0 + 1.2f - b.angle * 3f)
        val top = listOf(inner + P(0f, -b.th * 0.5f), peak + P(0f, -b.th * 0.6f), outer + P(0f, -b.th * 0.15f))
        val bot = listOf(outer + P(0f, b.th * 0.15f), peak + P(0f, b.th * 0.5f), inner + P(0f, b.th * 0.6f))
        val p = Path.smooth(top + bot, true).map { at(sk, it) }
        d.fill(p, Col.mix(hair, skin, if (Col.lum(hair) > 0.6) 0.1f else 0f).let { if (Col.lum(hair) > 0.7) Col.shade(it, 0.35f) else it })
    }

    private fun nose(d: Drawing, sk: Sk, look: AvatarLook, skin: Long) {
        val ink = Col.shade(skin, 0.55f)
        val x0 = fx(sk, 0f)
        val sx = if (sk.q) 1f else 0.6f
        when (look.nose.coerceIn(0, 4)) {
            0 -> { // botón
                d.stroke(Path.smooth(listOf(P(x0 + 2f, 9f), P(x0 + 4f * sx + 1f, 12.5f), P(x0, 14f), P(x0 - 3f, 13f)), false).map { at(sk, it) }, ink, 1.2f)
            }
            1 -> { // recta
                d.stroke(Path.line(P(x0 + 1.5f, 1f), P(x0 + 3f * sx + 1f, 11f)).map { at(sk, it) }, Col.mix(ink, skin, 0.4f), 1f)
                d.stroke(Path.smooth(listOf(P(x0 + 3.5f * sx + 1f, 11.5f), P(x0 + 2f, 14.5f), P(x0 - 2f, 14.2f), P(x0 - 4f, 12.8f)), false).map { at(sk, it) }, ink, 1.25f)
            }
            2 -> { // aguileña: puente marcado
                d.stroke(Path.smooth(listOf(P(x0 + 1f, 0f), P(x0 + 4.5f * sx + 1f, 6f), P(x0 + 4.5f * sx + 1f, 11f), P(x0 + 2f, 15f)), false).map { at(sk, it) }, ink, 1.25f)
                d.stroke(Path.smooth(listOf(P(x0 + 1f, 15f), P(x0 - 2.5f, 14.4f), P(x0 - 4f, 12.6f)), false).map { at(sk, it) }, ink, 1.1f)
            }
            3 -> { // ancha
                d.stroke(Path.smooth(listOf(P(x0 - 5.5f, 11f), P(x0 - 6f, 13.8f), P(x0 - 2f, 14.8f), P(x0 + 2.5f, 14.8f), P(x0 + 6f, 13.6f), P(x0 + 5.5f, 11f)), false).map { at(sk, it) }, ink, 1.25f)
                d.fill(Path.ellipse(at(sk, P(x0 + 3f, 13.6f)), 1.4f, 0.8f), Col.shade(skin, 0.6f))
            }
            else -> { // respingona
                d.stroke(Path.smooth(listOf(P(x0 + 1f, 4f), P(x0 + 3f * sx, 9.5f), P(x0 + 4.5f * sx + 1f, 11.6f), P(x0 + 1.5f, 13.6f), P(x0 - 2.5f, 13f)), false).map { at(sk, it) }, ink, 1.2f)
            }
        }
        d.fill(Path.ellipse(at(sk, P(x0 + 2.5f, 12.2f)), 3.2f, 2f), Col.of(Col.r(Col.shade(skin, 0.4f)), Col.g(Col.shade(skin, 0.4f)), Col.b(Col.shade(skin, 0.4f)), 70))
    }

    private data class MouthShape(val w: Float, val up: Float, val low: Float, val bow: Float, val smirk: Float)
    private val mouthShapes = listOf(MouthShape(13f, 2.6f, 3.6f, 1.2f, 0.25f), MouthShape(12f, 1.1f, 1.6f, 0.6f, 0.25f), MouthShape(16f, 2f, 2.6f, 0.9f, 0.25f),
        MouthShape(9.5f, 1.8f, 2.4f, 1f, 0.25f), MouthShape(12.5f, 2.4f, 2.8f, 2.2f, 0.25f), MouthShape(13f, 1.8f, 2.4f, 0.9f, 1f))

    private fun mouth(d: Drawing, sk: Sk, look: AvatarLook, e: Expression, skin: Long) {
        val m = mouthShapes[look.mouth.coerceIn(0, 5)]
        val lip = Col.mix(skin, Col.rgb(0xB0524C), if (Col.lum(skin) > 0.5) 0.32f else 0.22f).let { Col.shade(it, 0.1f) }
        val ink = Col.mix(Col.rgb(0x3A1E1A), skin, 0.15f)
        val smile = e.smile.coerceIn(0f, 1f)
        val k = if (sk.q) 0.86f else 1f
        val c = P(fx(sk, 0.5f), 21.5f)
        val hw = m.w / 2 * k * (1f + smile * 0.1f)
        // Pequeña asimetría: la comisura lejana sube un poco más.
        val lc = c + P(-hw, -smile * 2.6f + 0.6f); val rc = c + P(hw, -smile * (2.6f + 1.6f * m.smirk) + 0.2f)
        val mid = c + P(0f, smile * 1.2f)
        val line = Path.smooth(listOf(lc, lc.lerp(mid, 0.5f) + P(0f, smile * 1.2f), mid, rc.lerp(mid, 0.5f) + P(0f, smile * 1.2f), rc), false)
        // Labio superior con arco de Cupido y labio inferior más claro.
        val upPts = listOf(lc, c + P(-hw * 0.5f, -m.up), c + P(-1.6f, -m.up - m.bow * 0.5f), c + P(0f, -m.up + m.bow * 0.4f), c + P(1.6f, -m.up - m.bow * 0.5f),
            c + P(hw * 0.5f, -m.up), rc)
        val upper = Path.smooth(upPts + listOf(rc.lerp(mid, 0.5f) + P(0f, smile * 1.2f), mid, lc.lerp(mid, 0.5f) + P(0f, smile * 1.2f)), true)
        val lower = Path.smooth(listOf(lc, lc.lerp(mid, 0.5f) + P(0f, smile * 1.2f), mid, rc.lerp(mid, 0.5f) + P(0f, smile * 1.2f), rc,
            c + P(hw * 0.5f, m.low + smile), c + P(0f, m.low + 0.6f + smile * 0.8f), c + P(-hw * 0.5f, m.low + smile)), true)
        d.fill(lower.map { at(sk, it) }, Col.light(lip, 0.08f))
        d.fill(upper.map { at(sk, it) }, lip)
        d.stroke(line.map { at(sk, it) }, ink, 1.35f)
        // Hoyuelo en la comisura que sube.
        if (smile > 0.35f) d.stroke(Path.smooth(listOf(rc + P(1.5f, -1.5f), rc + P(2.6f, 0.2f), rc + P(2f, 2f)), false).map { at(sk, it) }, Col.shade(skin, 0.4f), 0.9f)
        d.stroke(Path.smooth(listOf(c + P(-hw * 0.4f, m.low + 3.6f + smile), c + P(0f, m.low + 4.2f + smile), c + P(hw * 0.4f, m.low + 3.6f + smile)), false).map { at(sk, it) },
            Col.shade(skin, 0.3f), 0.8f)
    }

    private fun facialHair(d: Drawing, sk: Sk, look: AvatarLook, headP: Path) {
        val t = look.facialHair.coerceIn(0, 6); if (t == 0) return
        val hair = Looks.hairColors[look.hairColor.coerceIn(0, 11)].color
        val cy = chinY(look); val cx = cheekX(sk, look)
        fun lp(vararg q: P) = Path.smooth(q.map { P(fx(sk, it.x), it.y) }, true).map { at(sk, it) }
        val stubble = Col.of(Col.r(hair), Col.g(hair), Col.b(hair), 70)
        when (t) {
            1 -> d.group(clip = headP) { fill(lp(P(-cx, 6f), P(-cx * 0.8f, 20f), P(0f, cy + 2f), P(cx * 0.8f, 20f), P(cx, 6f), P(cx * 0.55f, 16f), P(0f, 24f), P(-cx * 0.55f, 16f)), stubble) }
            2 -> d.solid(lp(P(-8f, 18.3f), P(-3f, 16.4f), P(0f, 17.2f), P(3f, 16.4f), P(8f, 18.3f), P(6f, 19.6f), P(0f, 18.8f), P(-6f, 19.6f)), hair, line = 0.7f, depth = 1.2f)
            3 -> { d.solid(lp(P(-7f, 18.3f), P(0f, 16.8f), P(7f, 18.3f), P(5f, 19.5f), P(0f, 18.6f), P(-5f, 19.5f)), hair, line = 0.7f, depth = 1f)
                d.solid(lp(P(-5f, 26f), P(0f, 25f), P(5f, 26f), P(3.5f, cy + 3f), P(0f, cy + 4.5f), P(-3.5f, cy + 3f)), hair, line = 0.8f, depth = 1.5f) }
            4, 5 -> { val ext = if (t == 5) 6f else 2f
                d.solid(lp(P(-cx, 2f), P(-cx * 0.95f, 16f), P(-cx * 0.6f, cy + ext * 0.6f), P(0f, cy + ext + 2f), P(cx * 0.6f, cy + ext * 0.6f), P(cx * 0.95f, 16f), P(cx, 2f),
                    P(cx * 0.8f, 10f), P(8f, 18f), P(4f, 24.5f), P(0f, 25f), P(-4f, 24.5f), P(-8f, 18f), P(-cx * 0.8f, 10f)), hair, line = 1f, depth = 3f)
                d.solid(lp(P(-8f, 18.5f), P(0f, 16.6f), P(8f, 18.5f), P(5f, 19.8f), P(0f, 18.9f), P(-5f, 19.8f)), hair, line = 0.6f, depth = 1f)
                if (t == 5) for (k in 0..4) d.stroke(Path.line(P(fx(sk, -9f + k * 4.5f), cy - 2f), P(fx(sk, -9.5f + k * 4.6f), cy + 4f)).map { at(sk, it) }, Col.shade(hair, 0.4f), 0.7f) }
            6 -> d.solid(lp(P(-cx, 2f), P(-cx * 0.96f, 18f), P(-cx * 0.55f, cy), P(0f, cy + 2.5f), P(cx * 0.55f, cy), P(cx * 0.96f, 18f), P(cx, 2f),
                P(cx * 0.9f, 4f), P(cx * 0.8f, 18f), P(cx * 0.4f, cy - 3f), P(0f, cy - 1.5f), P(-cx * 0.4f, cy - 3f), P(-cx * 0.8f, 18f), P(-cx * 0.9f, 4f)), hair, line = 0.9f, depth = 2f)
        }
    }

    private fun dailyGlasses(d: Drawing, sk: Sk, look: AvatarLook) {
        val t = look.glasses.coerceIn(0, 3); if (t == 0) return
        val frame = Col.rgb(0x2A2523)
        val lens = Col.of(220, 235, 245, 46)
        val eyes = listOf(-1f, 1f).map { s -> P(fx(sk, s * 9.4f), 1.5f) to (if (sk.q && s > 0) 0.8f else 1f) }
        for ((c, k) in eyes) {
            val p = when (t) {
                1 -> Path.ellipse(c, 6.6f * k, 6.2f)
                2 -> Path.roundRect(c.x - 7.4f * k, c.y - 5f, c.x + 7.4f * k, c.y + 5.2f, 1.8f)
                else -> Path.smooth(listOf(c + P(-7f * k, -2f), c + P(-3f * k, -5.4f), c + P(7.6f * k, -6.6f), c + P(6.6f * k, 3.2f), c + P(0f, 5.6f), c + P(-6.4f * k, 3.4f)), true)
            }.map { at(sk, it) }
            d.fill(p, lens); d.stroke(p, frame, 1.5f)
        }
        d.stroke(Path.smooth(listOf(eyes[0].first + P(6.4f, -1.2f), P(fx(sk, 0f), -0.6f), eyes[1].first + P(-6.4f * eyes[1].second, -1.2f)), false).map { at(sk, it) }, frame, 1.3f)
        val earSide = if (sk.q) eyes[0].first + P(-7f, -1f) else eyes[0].first + P(-7f, -1f)
        d.stroke(Path.line(earSide, P(if (sk.q) skull(sk, -cheekX(sk, look)) + 4f else -cheekX(sk, look), 1f)).map { at(sk, it) }, frame, 1.3f)
    }
}

// ====================================================================================================== pelo

object Hair {
    private fun style(look: AvatarLook) = Looks.hairStyles[look.hair.coerceIn(0, Looks.hairStyles.lastIndex)]
    fun color(look: AvatarLook) = Looks.hairColors[look.hairColor.coerceIn(0, Looks.hairColors.lastIndex)].color

    /** Región que tapa el casco o la gorra: el pelo de encima se recorta (no atraviesa la pieza). */
    fun mask(sk: Sk, head: Gear?): Path? {
        val brim = GearArt.brimY(head) ?: return null
        return Path.rect(-90f, -140f, 90f, brim).map { Face.at(sk, it) }
    }

    private fun contour(sk: Sk, st: HairStyle, a0: Float, a1: Float, n: Int, cover: Float, center: P = P(0f, -2f), lift: Float = 0f): List<P> {
        val pts = ArrayList<P>()
        for (k in 0..n) {
            val t = k / n.toFloat(); val th = a0 + (a1 - a0) * t
            val s = sin(th); val c = cos(th)
            val sideK = st.sides + (1f - st.sides) * (s * s).let { if (th > PI) it else it }
            val cov = cover * (if (s < 0) (st.sides + (1 - st.sides) * s * s) else st.sides)
            var rx = 25.6f + cov * 0.95f; var ry = 30.5f + cov
            val mod = when (st.tex) {
                Tex.WAVY -> 1.5f * sin(th * 7f)
                Tex.CURLY -> 2.6f * abs(sin(th * 9f))
                Tex.COILY -> 2.2f * abs(sin(th * 15f))
                else -> 0f
            }
            rx += mod; ry += mod
            var pnt = P(center.x + c * rx, center.y + s * ry - (if (s < -0.5f) lift * (-s - 0.5f) * 2f else 0f))
            pnt = P(Face.skull(sk, pnt.x), pnt.y)
            pts += pnt
            if (sideK < -9f) pts += pnt
        }
        return pts
    }

    private fun hairline(sk: Sk, st: HairStyle, look: AvatarLook): List<P> {
        val cx = Face.cheekX(sk, look)
        val burn = if (st.sides < 0.5f) 0f else 6f
        return listOf(P(Face.skull(sk, cx * 0.96f), burn), P(Face.skull(sk, cx * 0.92f), -6f), P(Face.fx(sk, cx * 0.5f), -16f), P(Face.fx(sk, 0f), -17.5f),
            P(Face.fx(sk, -cx * 0.5f), -16f), P(Face.skull(sk, -cx * 0.92f), -6f), P(Face.skull(sk, -cx * 0.96f), burn))
    }

    fun back(d: Drawing, sk: Sk, look: AvatarLook, head: Gear?) {
        val st = style(look); if (st.bald) return
        val col = Col.shade(color(look), 0.12f)
        val m = mask(sk, head)
        val body = Drawing()
        fun L(q: P) = Face.at(sk, q)
        // Melena trasera.
        if (st.length > 0.2f || st.tie == Tie.HALF_UP) {
            val len = if (st.length <= 0.5f) -2f + st.length * 64f else 30f + (st.length - 0.5f) * 72f
            val w = 27f * (1.04f + st.volume)
            val side = ArrayList<P>()
            val nTip = 6
            side += P(-26f, -20f)
            for (k in 1..6) { val t = k / 6f; val y = -20f + (len + 20f) * t
                val wob = when (st.tex) { Tex.WAVY -> 2.6f * sin(t * 9f); Tex.CURLY -> 3f * abs(sin(t * 12f)); else -> 0f }
                side += P(-w * (0.95f + 0.1f * t) - wob, y) }
            val bottom = ArrayList<P>()
            for (k in 0..nTip * 2) { val t = k / (nTip * 2f); val x = -w * 1.02f + 2 * w * 1.02f * t
                val y = len + (if (k % 2 == 0) 0f else -(if (st.tex == Tex.STRAIGHT) 7f else 4f)) + (if (st.tex == Tex.CURLY) 2f * sin(t * 30f) else 0f)
                bottom += P(x, y) }
            val right = side.reversed().map { P(-it.x, it.y) }
            val pts = (side + bottom + right).map { P(Face.skull(sk, it.x) - (if (sk.q) 6f else 0f), it.y) }.map { L(it) }
            body.solid(Path.smooth(pts, true), col, line = 1.3f, depth = 6f)
            // Mechones: líneas de las puntas.
            for (k in 0..4) { val x = -w * 0.8f + k * w * 0.4f
                body.stroke(Path.smooth(listOf(P(x * 0.8f, len * 0.4f), P(x * 0.95f, len * 0.75f), P(x, len - 3f)).map { L(P(Face.skull(sk, it.x) - (if (sk.q) 6f else 0f), it.y)) }, false),
                    Col.shade(col, 0.5f), 0.8f) }
        }
        when (st.tie) {
            Tie.AFRO -> {
                val pts = contour(sk, st, PI.toFloat() * 0.62f, PI.toFloat() * 2.38f, 64, st.cover, P(0f, -8f)).map { L(it) }
                body.solid(Path.smooth(pts, true), col, line = 1.4f, depth = 7f)
            }
            Tie.PONY_HIGH, Tie.PONY_LOW -> {
                val high = st.tie == Tie.PONY_HIGH
                val base = if (sk.q) P(-30f, if (high) -26f else 10f) else P(24f, if (high) -28f else 12f)
                val dir = if (sk.q) -1f else 1f
                val tail = listOf(base + P(-3f * dir, -4f), base + P(10f * dir, 2f), base + P(14f * dir, 24f), base + P(9f * dir, if (high) 52f else 44f),
                    base + P(4f * dir, if (high) 46f else 40f), base + P(4f * dir, 20f), base + P(-1f * dir, 6f))
                body.solid(Path.smooth(tail.map { L(it) }, true), col, line = 1.3f, depth = 4f)
                body.fill(Path.ellipse(L(base + P(2f * dir, 1f)), 4f, 3f), Col.rgb(0x3A3A3A))
            }
            Tie.BUN_LOW -> { val c = if (sk.q) P(-30f, 14f) else P(0f, 20f)
                if (sk.q || true) body.solid(Path.circle(L(c), 11f), col, line = 1.3f, depth = 4f) }
            Tie.HALF_UP -> body.solid(Path.circle(L(if (sk.q) P(-28f, -24f) else P(0f, -40f)), 8f), col, line = 1.2f, depth = 3f)
            else -> Unit
        }
        if (m != null) d.group(clipOut = m) { ops += body.ops } else d.ops += body.ops
    }

    fun front(d: Drawing, sk: Sk, look: AvatarLook, head: Gear?) {
        val st = style(look); if (st.bald) return
        val col = color(look)
        val ink = Col.shade(col, 0.5f)
        val m = mask(sk, head)
        val out = Drawing()
        fun L(q: P) = Face.at(sk, q)
        if (st.tex == Tex.BUZZ) {
            val cap = contour(sk, st, PI.toFloat() * 0.92f, PI.toFloat() * 2.08f, 24, 0.6f) + hairline(sk, st, look)
            out.fill(Path.smooth(cap.map { L(it) }, true), Col.of(Col.r(col), Col.g(col), Col.b(col), 150))
        } else if (st.tie == Tie.HIGH_TOP) {
            val cx = 26f
            val pts = listOf(P(-cx * 0.98f, 2f), P(-cx * 1.02f, -20f), P(-cx * 1.0f, -38f), P(-cx * 0.82f, -49f), P(0f, -51f), P(cx * 0.82f, -49f), P(cx * 1.0f, -38f),
                P(cx * 1.02f, -20f), P(cx * 0.98f, 2f)).map { P(Face.skull(sk, it.x), it.y) } + hairline(sk, st, look).drop(1).dropLast(1)
            out.solid(Path.smooth(pts.map { L(it) }, true), col, line = 1.4f, depth = 6f)
            for (k in 0..6) out.fill(Path.circle(L(P(Face.skull(sk, -20f + k * 6.6f), -49f + (k % 2) * 2f)), 3f), Col.light(col, 0.06f))
        } else if (st.tie != Tie.AFRO) {
            val outer = contour(sk, st, PI.toFloat() * (if (st.sides > 0.5f) 0.9f else 0.97f), PI.toFloat() * (if (st.sides > 0.5f) 2.1f else 2.03f), 40, st.cover,
                lift = if (st.fringe == Fringe.QUIFF) 9f else 0f)
            val line = hairline(sk, st, look)
            val capPath = Path.smooth((outer + line).map { L(it) }, true)
            // Volumen sin «casco»: contorno exterior con línea de tinta, borde de la frente con un trazo fino del propio pelo.
            out.solid(capPath, col, line = 0f, depth = 5f)
            out.stroke(Path.smooth(outer.map { L(it) }, false), ink, 1.3f)
            out.stroke(Path.smooth(line.map { L(it) }, false), Col.shade(col, 0.35f), 0.8f)
            out.group(clip = capPath) {
                for (k in 0..7) { val th = PI.toFloat() * (1.12f + k * 0.11f)
                    val a0 = P(Face.skull(sk, cos(th) * 12f), -4f + sin(th) * 16f); val b0 = P(Face.skull(sk, cos(th) * 30f), -2f + sin(th) * 36f)
                    stroke(Path.line(L(a0), L(b0)), Col.shade(col, 0.28f), 0.7f) }
            }
            if (st.sides < 0.5f) { // degradado: sombra translúcida sobre el lateral
                val cx = Face.cheekX(sk, look)
                out.fill(Path.smooth(listOf(P(-cx * 1.04f, -8f), P(-cx * 1.06f, 8f), P(-cx * 0.94f, 10f), P(-cx * 0.9f, -6f)).map { L(P(Face.skull(sk, it.x), it.y)) }, true),
                    Col.of(Col.r(col), Col.g(col), Col.b(col), 120))
            }
        } else {
            // Afro: frente con línea del pelo y textura sobre la masa trasera.
            val cap = contour(sk, st, PI.toFloat() * 0.95f, PI.toFloat() * 2.05f, 40, 6f) + hairline(sk, st, look)
            out.fill(Path.smooth(cap.map { L(it) }, true), col)
            for (k in 0..14) { val th = PI.toFloat() * (0.95f + 1.1f * k / 14f)
                out.fill(Path.circle(L(P(Face.skull(sk, cos(th) * 34f), -8f + sin(th) * 40f)), 2.2f), Col.light(col, 0.07f)) }
        }
        // Flequillos.
        when (st.fringe) {
            Fringe.STRAIGHT -> { val tips = (0..10).map { k -> P(-22f + k * 4.4f, if (k % 2 == 0) -6f else -9.5f) }
                out.solid(Path.smooth(listOf(P(-23f, -24f), P(0f, -28f), P(23f, -24f)) + tips.reversed().map { P(Face.fx(sk, it.x), it.y) }, true).map { L(it) }, col, line = 1.2f, depth = 3f) }
            Fringe.SIDE_LONG -> out.solid(Path.smooth(listOf(P(-22f, -26f), P(4f, -30f), P(24f, -16f), P(26f, -2f), P(18f, -10f), P(6f, -13f), P(-10f, -15f)).map { L(P(Face.fx(sk, it.x), it.y)) }, true), col, line = 1.2f, depth = 3f)
            Fringe.SIDE_SHORT -> out.solid(Path.smooth(listOf(P(-20f, -24f), P(2f, -29f), P(20f, -20f), P(16f, -14f), P(4f, -17f), P(-10f, -17f)).map { L(P(Face.fx(sk, it.x), it.y)) }, true), col, line = 1.2f, depth = 3f)
            Fringe.CURTAIN -> for (s in listOf(-1f, 1f)) out.solid(Path.smooth(listOf(P(0f, -27f), P(s * 14f, -22f), P(s * 25f, -6f), P(s * 23f, 2f), P(s * 15f, -12f), P(s * 3f, -19f)).map { L(P(Face.fx(sk, it.x), it.y)) }, true), col, line = 1.1f, depth = 3f)
            Fringe.QUIFF -> out.stroke(Path.smooth(listOf(P(-14f, -30f), P(-2f, -42f), P(14f, -40f)).map { L(P(Face.fx(sk, it.x), it.y)) }, false), ink, 1f)
            Fringe.CREST -> for (k in 0..5) { val x = -10f + k * 4f
                out.solid(Path.poly(P(x - 3f, -30f), P(x + 1f, -40f - (k % 2) * 3f), P(x + 3.5f, -30f)).map { L(P(Face.fx(sk, it.x), it.y)) }, col, line = 0.8f, depth = 1f) }
            Fringe.PART -> out.stroke(Path.smooth(listOf(P(-6f, -18f), P(-8f, -28f), P(-10f, -34f)).map { L(P(Face.fx(sk, it.x), it.y)) }, false), Col.shade(col, 0.55f), 1.2f)
            Fringe.CURLS -> for (k in 0..6) out.solid(Path.circle(L(P(Face.fx(sk, -18f + k * 6f), -17f + (k % 2) * 2.5f)), 4.3f), col, line = 0.9f, depth = 1.5f)
            Fringe.SHORT -> for (k in 0..4) out.stroke(Path.line(P(-12f + k * 6f, -22f), P(-10f + k * 6f, -17f)).map { L(P(Face.fx(sk, it.x), it.y)) }, ink, 0.9f)
            Fringe.NONE -> Unit
        }
        if (st.tie == Tie.CORNROWS) for (k in 0..5) { val x = -15f + k * 6f
            out.stroke(Path.smooth(listOf(P(x * 0.9f, -17f), P(x, -26f), P(x * 1.1f, -32f)).map { L(P(Face.skull(sk, it.x), it.y)) }, false), ink, 1.1f)
            for (j in 0..2) out.stroke(Path.line(P(x * 0.95f - 1.5f, -19f - j * 5f), P(x * 0.95f + 1.5f, -21f - j * 5f)).map { L(P(Face.skull(sk, it.x), it.y)) }, Col.light(col, 0.15f), 0.7f) }
        // Mechones finales: algunas puntas dibujadas en el contorno.
        if (st.tex == Tex.STRAIGHT && st.cover > 2f && st.tie != Tie.CORNROWS) for (k in 0..3) {
            val th = PI.toFloat() * (1.15f + k * 0.22f)
            val a = P(cos(th) * 20f, -2f + sin(th) * 25f); val b = P(cos(th) * 27f, -2f + sin(th) * 32f)
            out.stroke(Path.line(P(Face.skull(sk, a.x), a.y), P(Face.skull(sk, b.x), b.y)).map { L(it) }, ink, 0.7f)
        }
        if (m != null) d.group(clipOut = m) { ops += out.ops } else d.ops += out.ops
    }

    /** Lo que queda por delante del casco o de los hombros: moño alto, trenzas delanteras. */
    fun overHeadwear(d: Drawing, sk: Sk, look: AvatarLook, head: Gear?) {
        val st = style(look); if (st.bald) return
        val col = color(look)
        fun L(q: P) = Face.at(sk, q)
        when (st.tie) {
            Tie.BUN_HIGH -> if (GearArt.brimY(head) == null) {
                val c = L(P(Face.skull(sk, -2f), -40f))
                d.solid(Path.circle(c, 11f), col, line = 1.3f, depth = 4f)
                d.stroke(Path.smooth(listOf(c + P(-7f, -2f), c + P(0f, -6f), c + P(7f, -1f)), false), Col.shade(col, 0.5f), 0.9f)
            }
            Tie.BRAIDS_TWO, Tie.BRAID_ONE -> {
                val sides = if (st.tie == Tie.BRAIDS_TWO) (if (sk.q) listOf(-1f) else listOf(-1f, 1f)) else listOf(-1f)
                for (s in sides) {
                    val start = L(P(Face.skull(sk, s * 22f), 10f))
                    val end = sk.sh[if (s < 0) 0 else 1] + sk.up * (-48f) + sk.right * (s * -6f)
                    val n = 7
                    for (k in 0 until n) {
                        val c = start.lerp(end, k / (n - 1f)) + P(if (k % 2 == 0) -1.6f else 1.6f, 0f)
                        d.solid(Path.ellipse(c, 5.6f - k * 0.25f, 5.2f), col, line = 1f, depth = 2f)
                    }
                    d.fill(Path.ellipse(end + P(0f, 6f), 3f, 2f), Col.rgb(0x3A3A3A))
                    d.solid(Path.poly(end + P(-3f, 7f), end + P(3f, 7f), end + P(4f, 15f), end + P(-4f, 15f)), col, line = 0.8f, depth = 1f)
                }
            }
            else -> Unit
        }
    }
}
