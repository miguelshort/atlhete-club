package app.fuckrun.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.data.AppSettings
import app.fuckrun.data.RewardsRepository
import app.fuckrun.domain.Achievements
import app.fuckrun.domain.Rewards
import app.fuckrun.domain.Sport
import app.fuckrun.domain.SportProgress
import app.fuckrun.domain.art.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch

private val tabs = listOf("face" to "Rostro", "hair" to "Pelo", "body" to "Cuerpo", "clothes" to "Ropa", "acc" to "Accesorios", "shop" to "Tienda", "goals" to "Logros")

private fun Sport.pose() = when (this) { Sport.RUN -> ArtPose.RUN; Sport.HIKE -> ArtPose.HIKE; Sport.BIKE -> ArtPose.BIKE; Sport.WALK -> ArtPose.WALK }

/**
 * Vestidor. El avatar 2D ocupa la parte superior; al elegir Rostro o Pelo se acerca el encuadre y al volver se ve el
 * conjunto entero. Todo se PRUEBA sobre el propio avatar: «Equipar» guarda, «Deshacer» vuelve a lo equipado y «Quitar»
 * retira una pieza. Una prenda nueva queda en el inventario hasta que la persona decide ponérsela. Gastar puntos y
 * equipar son acciones distintas.
 */
@Composable
fun WardrobeScreen(nav: NavController, tab0: String) {
    val g = FuckrunApp.graph
    val ctx = LocalContext.current
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val settings0 by g.profile.settings.collectAsStateWithLifecycle<AppSettings?>(null)
    val settings = settings0 ?: return
    val balance by g.rewards.balance.collectAsStateWithLifecycle(0)
    val pendingPts by g.rewards.pendingPoints.collectAsStateWithLifecycle(0)
    val pendingItems by g.rewards.pendingItems.collectAsStateWithLifecycle(0)
    val owned by g.rewards.owned.collectAsStateWithLifecycle(emptySet())
    val replay by g.rewards.replay.collectAsStateWithLifecycle()
    LaunchedEffect(owned) { runCatching { g.rewards.refresh() } }
    var tab by rememberSaveable { mutableStateOf(if (tab0 == "look") "face" else tab0) }
    var look by remember(settings0 == null) { mutableStateOf(settings.avatarLook) }
    var outfit by remember(settings0 == null) { mutableStateOf(settings.avatarOutfit) }
    var view by rememberSaveable { mutableStateOf(ArtView.THREE_QUARTER) }
    var pose by rememberSaveable { mutableStateOf(ArtPose.IDLE) }
    var focusGear by remember { mutableStateOf<String?>(null) }
    val motion = rememberAvatarMotion()
    val zoom by animateFloatAsState(if (tab == "face" || tab == "hair") 1f else 0f, tween(if (LocalReduceMotion.current) 0 else 320), label = "zoom")
    val dirty = look != settings.avatarLook || outfit != settings.avatarOutfit
    fun tryOn(gr: Gear) { outfit = outfit.with(gr); focusGear = gr.id; if (gr.slot.group == Slot.Group.BIKE) pose = ArtPose.BIKE }
    fun equip() = scope.launch {
        g.profile.update { it.copy(look = look, outfit = outfit) }
        PortraitCache.save(ctx, look, outfit)
    }
    val available = { gr: Gear -> gr.price is GearPrice.Free || gr.id in owned }

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Vestidor", style = T.ScreenTitle, modifier = Modifier.weight(1f))
            Row(Modifier.clip(RoundedCornerShape(50)).background(C.Amber.copy(alpha = 0.16f)).padding(horizontal = 12.dp, vertical = 8.dp)
                .semantics(mergeDescendants = true) { contentDescription = "Saldo: $balance puntos" }, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Stars, null, tint = C.Amber, modifier = Modifier.size(18.dp)); Text(" $balance", style = T.Body.copy(fontFeatureSettings = "tnum"))
            }
            Spacer(Modifier.width(8.dp))
            RoundIconButton(Icons.Rounded.Close, "Cerrar") { nav.popBackStack() }
        }
        if ((pendingPts != 0 || pendingItems > 0) && g.accountUid != null)
            Text("Pendiente de copiar en tu cuenta: ${if (pendingPts != 0) "$pendingPts puntos" else ""}${if (pendingPts != 0 && pendingItems > 0) " y " else ""}${if (pendingItems > 0) "$pendingItems piezas" else ""}",
                style = T.Label, modifier = Modifier.padding(horizontal = 20.dp))

        // Probador.
        Box(Modifier.fillMaxWidth().height(300.dp)) {
            InteractiveAvatar(look, outfit, view, { view = it }, Modifier.fillMaxSize(), pose, motion, zoom)
            Column(Modifier.align(Alignment.CenterStart).padding(start = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(ArtView.FRONT to "Frente", ArtView.THREE_QUARTER to "Tres cuartos").forEach { (v, l) ->
                    Text(l, style = T.Label.copy(color = C.Text), modifier = Modifier.heightIn(min = 48.dp)
                        .liquid(RoundedCornerShape(50), if (view == v) C.Blue.copy(alpha = 0.18f) else C.Control, role = Role.RadioButton) { view = v }
                        .semantics { selected = view == v }.padding(horizontal = 12.dp, vertical = 14.dp))
                }
            }
            Column(Modifier.align(Alignment.CenterEnd).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                (listOf(null) + Sport.entries).forEach { s ->
                    val p = s?.pose() ?: ArtPose.IDLE
                    Box(Modifier.size(48.dp).liquid(CircleShape, if (pose == p) (s?.color ?: C.Blue).copy(alpha = 0.22f) else C.Control, role = Role.RadioButton,
                        onClickLabel = "Pose ${s?.label ?: "de reposo"}") { pose = p }.semantics { selected = pose == p; contentDescription = "Pose ${s?.label ?: "de reposo"}" },
                        contentAlignment = Alignment.Center) { Icon(s?.icon ?: Icons.Rounded.Accessibility, null, tint = s?.color ?: C.Text, modifier = Modifier.size(22.dp)) }
                }
            }
        }
        // Pestañas.
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            tabs.forEach { (k, l) ->
                Text(l, style = T.Body.copy(color = if (tab == k) C.Text else C.TextSec), modifier = Modifier.heightIn(min = 48.dp)
                    .liquid(RoundedCornerShape(24.dp), if (tab == k) C.Blue.copy(alpha = 0.18f) else C.Card, role = Role.Tab, glassLook = false) { tab = k }
                    .semantics { selected = tab == k }.padding(horizontal = 16.dp, vertical = 13.dp))
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (tab) {
                "face" -> {
                    Section("Tono de piel") { Swatches(Looks.skins, look.skin) { look = look.copy(skin = it) } }
                    Section("Contorno de cara") { Options(Looks.faces, look.face) { look = look.copy(face = it) } }
                    Section("Ojos") { Options(Looks.eyes, look.eyes) { look = look.copy(eyes = it) } }
                    Section("Color de ojos") { Swatches(Looks.irises, look.iris) { look = look.copy(iris = it) } }
                    Section("Cejas") { Options(Looks.brows, look.brows) { look = look.copy(brows = it) } }
                    Section("Nariz") { Options(Looks.noses, look.nose) { look = look.copy(nose = it) } }
                    Section("Boca") { Options(Looks.mouths, look.mouth) { look = look.copy(mouth = it) } }
                    Section("Pecas") { Options(listOf(Option("Sin pecas"), Option("Pocas"), Option("Algunas"), Option("Muchas")), (look.freckles * 3 + 0.4f).toInt().coerceIn(0, 3)) {
                        look = look.copy(freckles = it / 3f) } }
                    Section("Vello facial") { Options(Looks.facialHair, look.facialHair) { look = look.copy(facialHair = it) } }
                    Section("Gafas de diario") { Options(Looks.glasses, look.glasses) { look = look.copy(glasses = it) } }
                }
                "hair" -> {
                    Section("Peinado") {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Looks.hairStyles.forEachIndexed { i, st ->
                                Column(Modifier.width(92.dp).liquid(RoundedCornerShape(18.dp), if (look.hair == i) C.Blue.copy(alpha = 0.16f) else C.Card, role = Role.RadioButton,
                                    glassLook = false) { look = look.copy(hair = i) }.semantics { selected = look.hair == i }.padding(6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally) {
                                    Avatar(look.copy(hair = i), outfit, Modifier.size(72.dp), animated = false, portrait = true)
                                    Text(st.name, style = T.Label.copy(color = C.Text, fontSize = 12.sp), maxLines = 2)
                                }
                            }
                        }
                    }
                    Section("Color") { Swatches(Looks.hairColors, look.hairColor) { look = look.copy(hairColor = it) } }
                }
                "body" -> {
                    Section("Complexión") { Options(Looks.builds, look.build) { look = look.copy(build = it) } }
                    Section("Estatura relativa") { Options(Looks.heights, look.height) { look = look.copy(height = it) } }
                    Notice("La ropa se ajusta a hombros, cintura y largo de pierna de cada complexión.")
                }
                "clothes", "acc" -> {
                    if (tab == "clothes") SportSets(settings, outfit, onUse = { outfit = it }, onSave = { s -> scope.launch { g.profile.update { it.copy(sportOutfits = it.sportOutfits + (s to outfit)) } } },
                        onCopy = { from, to -> scope.launch { g.profile.update { st -> st.sportOutfits[from]?.let { st.copy(sportOutfits = st.sportOutfits + (to to it)) } ?: st } } })
                    val group = if (tab == "clothes") listOf(Slot.Group.CLOTHES) else listOf(Slot.Group.ACC, Slot.Group.BIKE)
                    val slots = Slot.entries.filter { it.group in group }
                    for (slot in slots) {
                        val items = GearCatalog.all.filter { it.slot == slot && available(it) }
                        if (items.isEmpty()) continue
                        Section(slot.label) {
                            GearRow(items, outfit, owned, focusGear) { gr -> if (outfit.isWearing(gr.id)) focusGear = gr.id else tryOn(gr) }
                            outfit.gear(slot)?.let { worn ->
                                if (focusGear == worn.id || slot in listOf(Slot.TOP, Slot.BOTTOM, Slot.SHOES)) TintEditor(worn, outfit.tintOf(worn)) { t -> outfit = outfit.withTint(worn, t) }
                                if (slot !in listOf(Slot.TOP, Slot.BOTTOM, Slot.SHOES)) PillButton("Quitar ${worn.name.lowercase()}", color = C.Control, textColor = C.Text,
                                    icon = Icons.Rounded.RemoveCircleOutline, modifier = Modifier.fillMaxWidth()) { outfit = outfit.without(slot) }
                            }
                        }
                    }
                    val locked = GearCatalog.all.count { it.slot.group in group && !available(it) }
                    if (locked > 0) Text("$locked piezas más se consiguen en Tienda y Logros.", style = T.Label)
                }
                "shop" -> ShopTab(owned, balance, outfit, onTry = { tryOn(it) }, onBuy = { item ->
                    val price = (item.price as GearPrice.Points).amount
                    sheet.confirm("¿Comprar ${item.name.lowercase()}?", "Gastarás $price puntos y te quedarán ${balance - price}. Comprar no la equipa: después podrás probarla y equiparla.",
                        "Comprar por $price puntos", C.Green, Icons.Rounded.ShoppingBag) {
                        scope.launch {
                            when (val r = g.rewards.buy(item)) {
                                is RewardsRepository.BuyResult.NotEnough -> sheet.dialog { Text("Te faltan ${r.missing} puntos", style = T.Section); Spacer(Modifier.height(8.dp))
                                    Text("Cada actividad medida de al menos 5 minutos suma 10 puntos, y cada marca mejorada 5 más.", style = T.Body)
                                    Spacer(Modifier.height(16.dp)); PillButton("Entendido", modifier = Modifier.fillMaxWidth()) { sheet.hide() } }
                                else -> Unit
                            }
                        }
                    }
                })
                "goals" -> GoalsTab(replay, owned, outfit, g.rewards.routesAvailable(), onTry = { tryOn(it) }, onEquip = { gr -> outfit = outfit.with(gr); equip() })
            }
            Spacer(Modifier.height(12.dp))
        }
        // Acciones del probador.
        if (dirty) Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("Deshacer", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Undo, modifier = Modifier.weight(1f)) {
                look = settings.avatarLook; outfit = settings.avatarOutfit; focusGear = null }
            PillButton("Equipar", color = C.Green, icon = Icons.Rounded.Check, modifier = Modifier.weight(1f)) { equip() }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(title, style = T.BodyStrong); content() }
}

/** Muestras de color con nombre accesible. */
@Composable
fun Swatches(list: List<Swatch>, current: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEachIndexed { i, sw ->
            val sel = i == current
            Box(Modifier.size(48.dp).clip(CircleShape).background(Color(sw.color.toInt()))
                .then(if (sel) Modifier.border(3.dp, C.Blue, CircleShape) else Modifier.border(1.dp, C.Border, CircleShape))
                .liquid(CircleShape, Color.Transparent, role = Role.RadioButton, glassLook = false) { onPick(i) }
                .semantics { contentDescription = sw.name + (if (sw.note.isNotEmpty()) ", matiz ${sw.note}" else ""); selected = sel },
                contentAlignment = Alignment.Center) {
                if (sel) Icon(Icons.Rounded.Check, null, tint = if (app.fuckrun.domain.art.Col.lum(sw.color) > 0.6) Color(0xFF15171C) else Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun Options(list: List<Option>, selected: Int, onPick: (Int) -> Unit) {
    ChoiceChips(list.indices.toList(), { list[it].name }, { it == selected }) { onPick(it) }
}

@Composable
private fun GearRow(items: List<Gear>, outfit: Outfit, owned: Set<String>, focus: String?, onTap: (Gear) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { gr ->
            val worn = outfit.isWearing(gr.id)
            Column(Modifier.width(112.dp).liquid(RoundedCornerShape(20.dp), if (worn) C.Blue.copy(alpha = 0.16f) else C.Card, role = Role.RadioButton, glassLook = false) { onTap(gr) }
                .semantics { selected = worn; stateDescription = if (worn) "Puesta" else "Probar" }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                GearThumb(gr, Modifier.size(80.dp), outfit.tintOf(gr))
                Text(gr.name, style = T.Label.copy(color = C.Text, fontSize = 12.sp), maxLines = 2)
                if (worn) Text("Puesta", style = T.Label.copy(color = C.Blue, fontSize = 11.sp))
            }
        }
    }
}

@Composable
private fun TintEditor(gr: Gear, t: Tint, onTint: (Tint) -> Unit) {
    Text("Color principal de ${gr.name.lowercase()}", style = T.Label)
    Swatches(GearCatalog.colors, t.main) { onTint(t.copy(main = it)) }
    Text("Acento", style = T.Label)
    Swatches(GearCatalog.colors, t.accent) { onTint(t.copy(accent = it)) }
}

/** Un conjunto guardado para cada deporte, que se puede usar o copiar a otro. */
@Composable
private fun SportSets(settings: AppSettings, outfit: Outfit, onUse: (Outfit) -> Unit, onSave: (Sport) -> Unit, onCopy: (Sport, Sport) -> Unit) {
    val sheet = LocalSheet.current
    FCard {
        Text("Conjuntos por deporte", style = T.BodyStrong)
        Spacer(Modifier.height(8.dp))
        Sport.entries.forEach { s ->
            val saved = settings.outfitFor(s)
            Row(Modifier.fillMaxWidth().heightIn(min = 52.dp), verticalAlignment = Alignment.CenterVertically) {
                SportBadge(s, 36.dp); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text(s.label, style = T.Body); Text(if (saved == null) "Sin conjunto guardado" else if (saved == outfit) "Es el que llevas" else "Guardado", style = T.Label) }
                if (saved != null && saved != outfit) Text("Usar", style = T.Body.copy(color = C.Blue), modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), glassLook = false) { onUse(saved) }.padding(12.dp))
                Text("Guardar", style = T.Body.copy(color = C.Blue), modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), glassLook = false) { onSave(s) }.padding(12.dp))
                if (saved != null) RoundIconButton(Icons.Rounded.ContentCopy, "Copiar el conjunto de ${s.label} a otro deporte", bg = Color.Transparent) {
                    sheet.pick("Copiar a", Sport.entries.filter { it != s }, { it.label }, null, icon = { it.icon }, tint = { it.color }) { to -> onCopy(s, to) }
                }
            }
        }
    }
}

@Composable
private fun ShopTab(owned: Set<String>, balance: Int, outfit: Outfit, onTry: (Gear) -> Unit, onBuy: (Gear) -> Unit) {
    Text("Artículos básicos que se compran con los puntos de tus actividades.", style = T.Label)
    GearCatalog.shop.forEach { item ->
        val price = (item.price as GearPrice.Points).amount
        val mine = item.id in owned
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(C.Card).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            GearThumb(item, Modifier.size(64.dp)); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, style = T.BodyStrong)
                Text(when { outfit.isWearing(item.id) -> "Equipada"; mine -> "En tu inventario"; balance >= price -> "$price puntos"
                    else -> "$price puntos · te faltan ${price - balance}" }, style = T.Label)
                Text(item.sport?.label ?: "", style = T.Label.copy(color = item.sport?.color ?: C.TextSec))
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Probar", style = T.Body.copy(color = C.Blue), modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), glassLook = false) { onTry(item) }.padding(12.dp))
                if (!mine) PillButton("Comprar", color = if (balance >= price) C.Green else C.Control, textColor = if (balance >= price) C.OnColor else C.TextSec) { onBuy(item) }
            }
        }
    }
}

@Composable
private fun GoalsTab(replay: Rewards.Replay?, owned: Set<String>, outfit: Outfit, routes: Boolean, onTry: (Gear) -> Unit, onEquip: (Gear) -> Unit) {
    var sport by rememberSaveable { mutableStateOf(Sport.RUN) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
        Sport.entries.forEach { s ->
            Row(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(24.dp), if (s == sport) s.color.copy(alpha = 0.2f) else C.Card, role = Role.Tab, glassLook = false) { sport = s }
                .semantics { selected = s == sport }.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(s.icon, null, tint = s.color, modifier = Modifier.size(22.dp)); Text(" ${s.label}", style = T.Body)
            }
        }
    }
    val prog = replay?.of(sport) ?: SportProgress()
    val list = Achievements.all.filter { it.sport == sport }
    val got = list.count { it.id in owned }
    Text("$got de ${list.size} piezas conseguidas en ${sport.label}", style = T.Label)
    list.forEach { a ->
        val gr = GearCatalog.byId(a.id) ?: return@forEach
        val mine = a.id in owned
        val frac = Rewards.fraction(a, prog, routes)
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(C.Card).padding(12.dp)
            .semantics(mergeDescendants = true) { stateDescription = if (mine) "Conseguida" else Rewards.progressText(a, prog, routes) }, verticalAlignment = Alignment.CenterVertically) {
            GearThumb(gr, Modifier.size(64.dp), alpha = if (mine) 1f else 0.45f); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(gr.name, style = T.BodyStrong)
                Text("${a.id} · ${a.goal}", style = T.Label)
                if (!mine) {
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(C.Control)) {
                        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(sport.color))
                    }
                    Text(Rewards.progressText(a, prog, routes), style = T.Label.copy(fontFeatureSettings = "tnum"))
                }
            }
            if (mine) Column(horizontalAlignment = Alignment.End) {
                Text("Probar", style = T.Body.copy(color = C.Blue), modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), glassLook = false) { onTry(gr) }.padding(12.dp))
                if (!outfit.isWearing(gr.id)) PillButton("Equipar", color = C.Green) { onEquip(gr) } else Text("Equipada", style = T.Label)
            }
        }
    }
}
