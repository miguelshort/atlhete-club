@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.fuckrun.ui.components

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester

// ---------- Material de vidrio (ver Glass.kt) ----------

/** Espacio que hay que reservar al final del contenido para que la cápsula no tape el último control. */
val LocalNavPadding = compositionLocalOf { 0.dp }
/** Ajuste del sistema «Quitar animaciones»: sin deformación ni estiramientos; solo tinte y contraste breves. */
val LocalReduceMotion = staticCompositionLocalOf { false }

/** Superficie de cristal regular (barra, paneles y menús): muestrea la escena compartida. */
fun Modifier.glass(shape: Shape, probe: GlassProbe? = null, blur: Dp = 32.dp, extraTint: () -> Float = { 0f }): Modifier =
    composed { liquidGlass({ shape }, C.Surface, GlassKind.REGULAR, blur = blur, extraTint = extraTint, probe = probe) }

/** Franja suave de salida de contenido bajo las cabeceras. Solo afecta al área desplazable. */
fun Modifier.topFade(height: Dp, enabled: Boolean) = if (!enabled) this else this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val h = height.toPx()
        drawRect(
            brush = Brush.verticalGradient(0f to Color.Transparent, 1f to Color.Black, startY = 0f, endY = h),
            size = Size(size.width, h), blendMode = BlendMode.DstIn,
        )
    }

// ---------- Respuesta táctil común ----------

private class AnchorBox { var rect: Rect = Rect.Zero; var lastClick = 0L }

/**
 * Componente táctil común (botones, pestañas, opciones de menú, selectores, interruptores y tarjetas).
 *  - Reposo: cápsula con volumen en el borde y el texto quieto.
 *  - Al posar el dedo: el lado tocado cede 1–3 dp y se ensancha hacia ese lado (en el centro, simétrico) con el
 *    extremo opuesto anclado; el reflejo se concentra junto al dedo y la refracción sigue la nueva silueta.
 *    Entrada de 85 ms desde el primer fotograma.
 *  - Al mantener: conserva el ensanchamiento; el brillo sigue al dedo si se mueve dentro; el tinte se intensifica.
 *  - Al soltar: contorno, refracción y luz vuelven juntos con un muelle amortiguado de ~170 ms; la acción se dispara
 *    una sola vez. Si el gesto pasa a ser desplazamiento o se cancela, recupera la forma y no hace nada.
 *  - El área táctil y la maquetación de los vecinos no cambian; icono y texto no se mueven.
 *  - Movimiento reducido: sin deformación; solo un cambio breve de tinte y contraste.
 *  - Registra su posición para que los menús nazcan del control y devuelve el foco al cerrarlos.
 *
 * @param glassLook false = superficie normal del tema (listas y tarjetas de lectura) con la misma respuesta táctil.
 * @param pressTint selección translúcida que cede hacia el dedo (filas de menú).
 */
fun Modifier.liquid(
    shape: Shape? = null,
    color: Color = Color.Transparent,
    enabled: Boolean = true,
    role: Role? = Role.Button,
    onClickLabel: String? = null,
    pressTint: Color? = null,
    glassLook: Boolean = true,
    probe: GlassProbe? = null,
    /** Ajuste del tinte (negativo = deja ver más fondo, p. ej. el selector cerrado). */
    tintBias: Float = 0f,
    onClick: () -> Unit,
): Modifier = composed {
    val sheet = LocalSheet.current
    val reduce = LocalReduceMotion.current
    val src = remember { MutableInteractionSource() }
    val box = remember { AnchorBox() }
    val focus = remember { FocusRequester() }
    val press = rememberLiquidPress()
    val click by rememberUpdatedState(onClick)
    val shp = shape ?: RectangleShape
    val isAction = color.alpha >= 0.95f && color != C.Control && color != C.Card && color != C.Surface && color != C.Bg
    val glassy = glassLook && shape != null && color.alpha > 0f
    val hidden = { sheet.entry?.let { it.kind == PanelKind.MENU && it.anchor == box.rect } == true }
    this
        .onGloballyPositioned { box.rect = it.boundsInRoot() }
        .then(if (glassy) Modifier.liquidGlass({ shp }, color, if (isAction) GlassKind.TINTED else GlassKind.REGULAR, press, probe = probe,
            blur = if (isAction) 20.dp else 30.dp, extraTint = { tintBias }, hidden = hidden) else Modifier)
        .drawBehind {
            if (glassy && pressTint == null) return@drawBehind
            val r = pressedBounds(size, press, density, reduce)
            val outline = shp.createOutline(r.size, layoutDirection, this)
            translate(r.left, r.top) {
                if (!glassy && color.alpha > 0f) drawOutline(outline, color)
                val k = press.anim.value
                if (k > 0.01f) {
                    if (pressTint != null) drawOutline(outline, pressTint.copy(alpha = 0.22f * k))
                    if (!glassy) {
                        val c = if (press.touch.isSpecified) press.touch - r.topLeft else Offset(r.width / 2, r.height / 2)
                        drawOutline(outline, Brush.radialGradient(listOf(C.Text.copy(alpha = 0.10f * k), Color.Transparent), center = c,
                            radius = r.size.maxDimension.coerceAtLeast(1f) * 0.8f))
                    }
                }
            }
        }
        .liquidGesture(press, enabled)
        .focusRequester(focus)
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = role, onClickLabel = onClickLabel) {
            val now = SystemClock.uptimeMillis()
            if (now - box.lastClick < 350) return@clickable
            box.lastClick = now
            sheet.anchorAt(box.rect, focus)
            click()
        }
}

/** Sustituto de clickable para superficies que ya pintan su fondo: misma respuesta táctil y anclaje de menús. */
fun Modifier.tap(enabled: Boolean = true, role: Role? = null, onClickLabel: String? = null, onClick: () -> Unit): Modifier =
    liquid(shape = null, color = Color.Transparent, enabled = enabled, role = role, onClickLabel = onClickLabel, onClick = onClick)

// ---------- Navegación inferior flotante ----------

data class NavItem(val route: String, val label: String, val icon: ImageVector)

/**
 * Cápsula flotante común con Inicio, Rutas, Club, Rutinas y Progreso: cinco iconos con su nombre y UNA lente de
 * selección dentro. Al cambiar de pestaña, el borde que va hacia la nueva llega antes que el otro, así que la lente se
 * estira hacia la elegida y se asienta bajo su símbolo; los iconos no se mueven. El contenido pasa por detrás.
 * Movimiento reducido: sin estiramiento, un breve cambio de tinte y contraste.
 */
@Composable
fun FloatingNavBar(items: List<NavItem>, current: String?, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(34.dp)
    val reduce = LocalReduceMotion.current
    var barW by remember { mutableStateOf(0f) }
    val idx = items.indexOfFirst { it.route == current }
    val lensL = remember { Animatable(-1f) }
    val lensR = remember { Animatable(-1f) }
    val flash = remember { Animatable(0f) }
    val probe = remember { GlassProbe() }
    val ink = rememberGlassInk(probe, C.Text)
    val sel = C.Blue
    LaunchedEffect(idx, barW) {
        if (idx < 0 || barW <= 0f) return@LaunchedEffect
        val itemW = barW / items.size
        val l = idx * itemW; val r = l + itemW
        if (lensL.value < 0f || reduce) {
            lensL.snapTo(l); lensR.snapTo(r)
            if (reduce) { flash.snapTo(1f); flash.animateTo(0f, tween(220)) }
            return@LaunchedEffect
        }
        val movingRight = l > lensL.value
        val fast = spring<Float>(dampingRatio = 0.8f, stiffness = 1400f)
        val slow = spring<Float>(dampingRatio = 0.8f, stiffness = 380f)
        launch { lensL.animateTo(l, if (movingRight) slow else fast) }
        launch { lensR.animateTo(r, if (movingRight) fast else slow) }
    }
    Box(
        modifier
            .padding(horizontal = 14.dp)
            .fillMaxWidth()
            .heightIn(min = 70.dp)
            .glass(shape, probe)
            .padding(6.dp)
            .onSizeChanged { barW = it.width.toFloat() }
            .drawBehind {
                if (idx >= 0 && lensL.value >= 0f) {
                    val inset = 2.dp.toPx()
                    val tl = Offset(lensL.value + inset, 0f)
                    val sz = Size((lensR.value - lensL.value - 2 * inset).coerceAtLeast(0f), size.height)
                    val cr = CornerRadius(28.dp.toPx())
                    drawRoundRect(sel.copy(alpha = 0.16f + 0.14f * flash.value), tl, sz, cr)
                    drawRoundRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (C.isDark) 0.16f else 0.5f), Color.Transparent), tl.y, tl.y + sz.height * 0.6f),
                        tl, sz, cr, style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
                }
            },
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            items.forEach { item ->
                val selected = item.route == current
                Column(
                    Modifier.weight(1f).heightIn(min = 58.dp)
                        .liquid(RoundedCornerShape(28.dp), Color.Transparent, role = Role.Tab, onClickLabel = item.label, glassLook = false) { onSelect(item.route) }
                        .semantics { this.selected = selected }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Icon(item.icon, null, tint = if (selected) sel else ink.copy(alpha = 0.78f), modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(2.dp))
                    Text(item.label, style = T.Label.copy(fontSize = 11.sp, color = if (selected) ink else ink.copy(alpha = 0.78f)), maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

// ---------- Menús anclados, diálogos y páginas ----------

enum class PanelKind { MENU, DIALOG, PAGE }

class PanelEntry(val kind: PanelKind, val anchor: Rect?, val title: String?, val content: @Composable ColumnScope.() -> Unit)

/**
 * Capa raíz de paneles (comparte coordenadas y escena con los controles):
 *  - show/pick: menú que CRECE DESDE el control pulsado (mismo contorno, borde junto al disparador anclado) hacia el lado
 *    con espacio: debajo si cabe, encima si no; desde un lateral, hacia dentro; respetando teclado y márgenes.
 *  - dialog/confirm: diálogo centrado, solo para confirmaciones.
 *  - page: formulario extenso a pantalla completa.
 * Atrás o un toque fuera reproducen el retorno (desde el fotograma en que esté) y el foco vuelve al control.
 */
class SheetController {
    private var lastAnchor: Rect? = null
    private var lastFocus: FocusRequester? = null
    private var anchorTime = 0L
    var entry by mutableStateOf<PanelEntry?>(null)
        private set
    private var returnFocus: FocusRequester? = null

    fun anchorAt(r: Rect, focus: FocusRequester? = null) { lastAnchor = r; lastFocus = focus; anchorTime = SystemClock.uptimeMillis() }
    /** Control desde el que está abierto el menú actual (para girar su chevrón). */
    val openAnchor: Rect? get() = entry?.takeIf { it.kind == PanelKind.MENU }?.anchor
    private fun fresh(): Rect? = lastAnchor?.takeIf { SystemClock.uptimeMillis() - anchorTime < 2500 && it.width > 0f }

    fun show(c: @Composable ColumnScope.() -> Unit) { val a = fresh(); returnFocus = if (a != null) lastFocus else null; entry = PanelEntry(PanelKind.MENU, a, null, c) }
    fun dialog(c: @Composable ColumnScope.() -> Unit) { returnFocus = lastFocus; entry = PanelEntry(PanelKind.DIALOG, null, null, c) }
    fun page(title: String, c: @Composable ColumnScope.() -> Unit) { returnFocus = lastFocus; entry = PanelEntry(PanelKind.PAGE, null, title, c) }
    fun hide() { entry = null }
    internal fun restoreFocus() { runCatching { returnFocus?.requestFocus() }; returnFocus = null }

    fun confirm(title: String, message: String, confirmLabel: String, color: Color, icon: ImageVector? = null, onConfirm: () -> Unit) = dialog {
        Text(title, style = T.Section, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(8.dp))
        Text(message, style = T.Body.copy(color = C.TextSec))
        Spacer(Modifier.height(20.dp))
        PillButton(confirmLabel, color = color, icon = icon, modifier = Modifier.fillMaxWidth()) { hide(); onConfirm() }
        Spacer(Modifier.height(10.dp))
        PillButton("Cancelar", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { hide() }
    }

    fun <O> pick(
        title: String, options: List<O>, label: (O) -> String, selected: O?,
        icon: ((O) -> ImageVector?)? = null, tint: ((O) -> Color)? = null, subtitle: ((O) -> String?)? = null,
        onPick: (O) -> Unit,
    ) = show {
        MenuTitle(title)
        options.forEach { o ->
            MenuRow(label(o), icon?.invoke(o), tint?.invoke(o) ?: C.Text, selected = o == selected, subtitle = subtitle?.invoke(o)) { onPick(o); hide() }
        }
    }
}

val LocalSheet = staticCompositionLocalOf { SheetController() }

@Composable
fun MenuTitle(text: String) {
    Text(text, style = T.Label, modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 4.dp).semantics { heading() })
}

/** Fila de menú: pictograma grande, nombre corto y marca de selección. Selección azul translúcida al pulsar. ≥ 52 dp. */
@Composable
fun MenuRow(label: String, icon: ImageVector? = null, tint: Color = C.Text, selected: Boolean = false, subtitle: String? = null, onClick: () -> Unit) {
    val ink = LocalGlassInk.current.takeIf { it != Color.Unspecified } ?: C.Text
    Row(
        Modifier.fillMaxWidth().heightIn(min = 54.dp)
            .liquid(RoundedCornerShape(18.dp), if (selected) C.Blue.copy(alpha = 0.14f) else Color.Transparent, role = Role.RadioButton,
                pressTint = C.Blue, glassLook = false, onClick = onClick)
            .semantics { this.selected = selected }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = if (tint == C.Text) ink else tint, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(label, style = T.BodyStrong.copy(color = ink))
            if (subtitle != null) Text(subtitle, style = T.Label.copy(color = ink.copy(alpha = 0.7f)))
        }
        if (selected) Icon(Icons.Rounded.Check, "Seleccionado", tint = C.Blue, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun SheetHost(controller: SheetController) {
    val entry = controller.entry
    var shown by remember { mutableStateOf<PanelEntry?>(null) }
    val progress = remember { Animatable(0f) }
    val reduce = LocalReduceMotion.current
    LaunchedEffect(entry) {
        if (entry != null) {
            if (shown !== entry) { shown = entry; progress.snapTo(0f) }
            // Apertura de 220 ms desde el fotograma actual (si se reabre a media salida, continúa desde ahí).
            if (reduce) progress.snapTo(1f)
            else if (entry.kind == PanelKind.MENU) progress.animateTo(1f, tween(220, easing = androidx.compose.animation.core.FastOutSlowInEasing))
            else progress.animateTo(1f, spring(dampingRatio = 0.82f, stiffness = 650f))
        } else if (shown != null) {
            // Cierre a media apertura: invierte la transición desde el fotograma alcanzado.
            if (reduce) progress.snapTo(0f) else progress.animateTo(0f, tween(180))
            shown = null
            controller.restoreFocus()
        }
    }
    BackHandler(enabled = entry != null) { controller.hide() }
    val s = shown ?: return
    val p = { progress.value.coerceIn(0f, 1f) }
    // Menús: sin capa negra (el contenido sigue en su sitio detrás del panel). Diálogos: velo suave.
    Box(Modifier.fillMaxSize()
        .then(if (s.kind == PanelKind.DIALOG) Modifier.graphicsLayer { alpha = p() }.background(C.Scrim) else Modifier)
        .pointerInput(s) { detectTapGestures { controller.hide() } })
    when (s.kind) {
        PanelKind.MENU -> AnchoredPanel(s, p)
        PanelKind.DIALOG -> CenteredPanel(s, p)
        PanelKind.PAGE -> PagePanel(s, p) { controller.hide() }
    }
}

/** Contorno intermedio entre el botón (k = 0) y el panel completo (k = 1). */
private fun morphRect(from: Rect?, size: Size, k: Float): Rect {
    if (from == null) return Rect(0f, 0f, size.width, size.height)
    val kk = k.coerceIn(0f, 1f)
    fun lerp(a: Float, b: Float) = a + (b - a) * kk
    return Rect(lerp(from.left, 0f), lerp(from.top, 0f), lerp(from.right, size.width), lerp(from.bottom, size.height))
}

private class MorphShape(private val from: Rect?, private val k: Float, private val endRadius: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: androidx.compose.ui.unit.LayoutDirection, density: androidx.compose.ui.unit.Density): Outline {
        val r = morphRect(from, size, k)
        val radius = if (from == null) endRadius else from.height / 2f + (endRadius - from.height / 2f) * k.coerceIn(0f, 1f)
        return Outline.Rounded(androidx.compose.ui.geometry.RoundRect(r, CornerRadius(radius.coerceAtMost(minOf(r.width, r.height) / 2f))))
    }
}

/**
 * Panel de cristal único. En los menús, el MISMO contorno parte del rectángulo del disparador y crece hasta envolver las
 * opciones; mientras crece aumentan la difusión central y la sombra, y las filas entran en el espacio recién abierto.
 */
@Composable
private fun PanelSurface(modifier: Modifier, padding: Dp, from: Rect?, progress: () -> Float, content: @Composable ColumnScope.() -> Unit) {
    val endR = with(LocalDensity.current) { 28.dp.toPx() }
    val probe = remember { GlassProbe() }
    val ink = rememberGlassInk(probe, C.Text)
    Column(
        modifier
            .liquidGlass(
                shapeOf = { r -> RoundedCornerShape(minOf(endR, r.height / 2f)) },
                tint = C.Surface, kind = GlassKind.REGULAR,
                blur = 36.dp, extraTint = { 0.12f * progress() }, shadow = { 0.6f + 0.8f * progress() }, probe = probe,
                bounds = { sz -> morphRect(from, sz, progress()) },
            )
            .graphicsLayer { clip = true; shape = MorphShape(from, progress(), endR); alpha = if (from == null) progress() else 1f }
            // Absorbe toques dentro del panel para que no lo cierren.
            .pointerInput(Unit) { detectTapGestures { } }
            .semantics { paneTitle = "Menú" }
            .verticalScroll(rememberScrollState())
            .padding(padding)
            .graphicsLayer { alpha = if (from == null) 1f else ((progress() - 0.25f) / 0.6f).coerceIn(0f, 1f) },
    ) { CompositionLocalProvider(LocalGlassInk provides ink) { content() } }
}

/** Mide los límites del control y coloca el panel debajo, encima o hacia dentro, dentro de los márgenes seguros. */
@Composable
private fun AnchoredPanel(e: PanelEntry, progress: () -> Float) {
    val d = LocalDensity.current
    val insets = WindowInsets.safeDrawing
    var from by remember { mutableStateOf<Rect?>(null) }
    Layout(
        content = { PanelSurface(Modifier, 8.dp, from, progress, e.content) },
        modifier = Modifier.fillMaxSize(),
    ) { measurables, cons ->
        val w = cons.maxWidth; val h = cons.maxHeight
        val margin = 12.dp.roundToPx(); val gap = 0
        val top = insets.getTop(d) + margin
        val bottom = h - insets.getBottom(d) - margin
        val a = e.anchor ?: Rect(w / 2f, h / 2f, w / 2f, h / 2f)
        val spaceBelow = bottom - a.top.toInt()
        val spaceAbove = a.bottom.toInt() - top
        val maxW = (w - 2 * margin).coerceAtLeast(1)
        val desiredW = maxOf(a.width.toInt(), 264.dp.roundToPx()).coerceAtMost(360.dp.roundToPx()).coerceAtMost(maxW)
        val maxH = maxOf(spaceBelow, spaceAbove, 180.dp.roundToPx()).coerceAtMost((bottom - top).coerceAtLeast(1))
        val pl = measurables.first().measure(Constraints(minWidth = desiredW, maxWidth = desiredW, minHeight = 0, maxHeight = maxH))
        // El borde junto al disparador se conserva: el panel cubre el botón y gana espacio hacia el lado disponible.
        val below = e.anchor == null || pl.height <= spaceBelow || spaceBelow >= spaceAbove
        val rawY = when {
            e.anchor == null -> (h - pl.height) / 2
            below -> a.top.toInt() - gap
            else -> a.bottom.toInt() + gap - pl.height
        }
        val y = rawY.coerceAtMost(bottom - pl.height).coerceAtLeast(top)
        val alignRight = a.center.x > w / 2f
        val rawX = if (e.anchor == null) (w - pl.width) / 2 else if (alignRight) a.right.toInt() - pl.width else a.left.toInt()
        val x = rawX.coerceAtMost(w - margin - pl.width).coerceAtLeast(margin)
        val f = e.anchor?.let { Rect(it.left - x, it.top - y, it.right - x, it.bottom - y) }
        if (f != from) from = f
        layout(w, h) { pl.place(x, y) }
    }
}

@Composable
private fun CenteredPanel(e: PanelEntry, progress: () -> Float) {
    Box(Modifier.fillMaxSize().safeDrawingPadding().padding(24.dp), contentAlignment = Alignment.Center) {
        PanelSurface(Modifier.widthIn(max = 420.dp).fillMaxWidth().graphicsLayer {
            val k = progress(); scaleX = 0.94f + 0.06f * k; scaleY = 0.94f + 0.06f * k
        }, 22.dp, null, progress, e.content)
    }
}

@Composable
private fun PagePanel(e: PanelEntry, progress: () -> Float, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().graphicsLayer { val k = progress(); alpha = k; translationY = (1f - k) * 48.dp.toPx() }
        .background(C.Bg).pointerInput(Unit) { detectTapGestures { } }.statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(e.title ?: "", style = T.ScreenTitle, modifier = Modifier.weight(1f).semantics { heading() })
            RoundIconButton(Icons.Rounded.Close, "Cerrar", onClick = onClose)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp), content = e.content)
    }
}

// ---------- Botones y bloques ----------

@Composable
fun PillButton(
    text: String, modifier: Modifier = Modifier, color: Color = C.Blue, textColor: Color = C.OnColor,
    icon: ImageVector? = null, enabled: Boolean = true, big: Boolean = false, onClick: () -> Unit,
) {
    Row(
        modifier.heightIn(min = if (big) 64.dp else 52.dp)
            .liquid(RoundedCornerShape(percent = 50), if (enabled) color else C.Control.copy(alpha = 0.6f), enabled = enabled, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) { Icon(icon, null, tint = if (enabled) textColor else C.TextSec, modifier = Modifier.size(if (big) 28.dp else 22.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, style = (if (big) T.BodyStrong.copy(fontSize = 19.sp) else T.BodyStrong).copy(color = if (enabled) textColor else C.TextSec),
            textAlign = TextAlign.Center)
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, description: String, modifier: Modifier = Modifier, bg: Color = C.Control, tint: Color = C.Text, onClick: () -> Unit) {
    Box(modifier.size(48.dp).liquid(CircleShape, bg, onClickLabel = description, onClick = onClick).semantics { contentDescription = description },
        contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
    }
}

@Composable
fun CircleAction(icon: ImageVector, label: String, tint: Color = C.Text, bg: Color = C.Control, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(80.dp)) {
        Box(Modifier.size(54.dp).liquid(CircleShape, bg, onClick = onClick).semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = T.Label.copy(color = C.Text), textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
fun FCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, color: Color = C.Card, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.liquid(shape, color, glassLook = false, onClick = onClick) else Modifier.clip(shape).background(color))
            .padding(18.dp),
        content = content,
    )
}

@Composable
fun ListRow(title: String, subtitle: String? = null, leading: ImageVector? = null, leadingTint: Color = C.Text,
            trailing: ImageVector? = Icons.Rounded.ChevronRight, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp)
            .then(if (onClick != null) Modifier.liquid(RoundedCornerShape(16.dp), Color.Transparent, onClick = onClick) else Modifier)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(if (leadingTint == C.Text) C.Control else leadingTint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center) { Icon(leading, null, tint = leadingTint, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = T.BodyStrong)
            if (subtitle != null) Text(subtitle, style = T.Label)
        }
        if (trailing != null && onClick != null) Icon(trailing, null, tint = C.TextSec)
    }
}

@Composable
fun Stat(label: String, value: String, unit: String? = null, modifier: Modifier = Modifier, big: Boolean = false) {
    Column(modifier) {
        Text(label, style = T.Label)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, style = if (big) T.HomeFigure else T.Number)
            if (unit != null) { Spacer(Modifier.width(4.dp)); Text(unit, style = T.Label, modifier = Modifier.padding(bottom = 3.dp)) }
        }
    }
}

@Composable
fun Tag(text: String, color: Color = C.Control, textColor: Color = C.Text) {
    Text(text, style = T.Label.copy(color = textColor), modifier = Modifier.clip(RoundedCornerShape(50)).background(color).padding(horizontal = 10.dp, vertical = 4.dp))
}

/** Nombre visible de la marca, en Inter Regular. (La silueta del logotipo antiguo no se puede aislar: ver docs/MARCA.md.) */
@Composable
fun BrandName(modifier: Modifier = Modifier, size: Int = 24) {
    Text("Athlete Club", style = T.Section.copy(fontSize = size.sp), modifier = modifier.semantics { heading() })
}

@Composable
fun <O> ChoiceChips(options: List<O>, label: (O) -> String, isSelected: (O) -> Boolean, onToggle: (O) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            val sel = isSelected(o)
            Box(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), if (sel) C.Text else C.Control, role = Role.Checkbox) { onToggle(o) }
                .semantics { selected = sel }.padding(horizontal = 16.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
                Text(label(o), style = T.Body.copy(color = if (sel) C.Bg else C.Text))
            }
        }
    }
}

/**
 * Pantalla con cabecera fija y lista desplazable. La lista reserva espacio para la cápsula inferior
 * y aplica la difuminación superior solo cuando hay contenido saliendo por arriba.
 */
@Composable
fun ScreenScaffold(
    title: String?,
    header: (@Composable RowScope.() -> Unit)? = null,
    state: LazyListState = rememberLazyListState(),
    content: LazyListScope.() -> Unit,
) {
    val fade = 32.dp
    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (title != null) Text(title, style = T.ScreenTitle, modifier = Modifier.weight(1f).semantics { heading() }) else Spacer(Modifier.weight(1f))
            header?.invoke(this)
        }
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize().topFade(fade, state.canScrollBackward),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = LocalNavPadding.current + 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
fun SectionTitle(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = T.Section, modifier = Modifier.weight(1f).semantics { heading() })
        if (action != null && onAction != null) Text(action, style = T.BodyStrong.copy(color = C.Blue),
            modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), onClick = onAction).padding(horizontal = 10.dp, vertical = 12.dp))
    }
}

@Composable
fun Notice(text: String, color: Color = C.Control, icon: ImageVector = Icons.Rounded.Info, textColor: Color = C.Text) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(color).padding(14.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = textColor, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(color = textColor, fontSize = 14.sp))
    }
}

/** Indicación de un solo paso para funciones secundarias. Se puede cerrar y volver a abrir desde «?». */
@Composable
fun Hint(text: String, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Blue.copy(alpha = 0.12f)).padding(start = 14.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Lightbulb, null, tint = C.Blue, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(fontSize = 14.sp), modifier = Modifier.weight(1f))
        RoundIconButton(Icons.Rounded.Close, "Cerrar ayuda", bg = Color.Transparent, tint = C.TextSec, onClick = onClose)
    }
}

@Composable
fun rememberNavHeight(onHeight: (Dp) -> Unit): Modifier {
    val d = LocalDensity.current
    return Modifier.onSizeChanged { onHeight(with(d) { it.height.toDp() }) }
}

/**
 * Interruptor de cristal: la pieza se ensancha mientras se pulsa y recupera su forma al llegar al estado elegido.
 * Objetivo táctil de 48 dp y semántica de interruptor para TalkBack.
 */
@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit, label: String) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val reduce = LocalReduceMotion.current
    val pos by animateFloatAsState(if (checked) 1f else 0f, if (reduce) tween(0) else spring(dampingRatio = 0.75f, stiffness = 700f), label = "pos")
    val wide by animateFloatAsState(if (pressed && !reduce) 1f else 0f, if (pressed) tween(90) else spring(dampingRatio = 0.78f, stiffness = 1000f), label = "wide")
    val track = if (checked) C.Green else C.Control
    val thumb = Color.White
    val edge = C.EdgeTop
    Box(Modifier.size(width = 60.dp, height = 48.dp)
        .toggleable(value = checked, interactionSource = src, indication = null, role = Role.Switch, onValueChange = onChange)
        .semantics { contentDescription = label }
        .drawBehind {
            val h = 30.dp.toPx(); val w = 52.dp.toPx()
            val top = (size.height - h) / 2; val left = (size.width - w) / 2
            drawRoundRect(track, Offset(left, top), Size(w, h), CornerRadius(h / 2))
            val tw = 26.dp.toPx() + 10.dp.toPx() * wide; val th = 26.dp.toPx() - 1.dp.toPx() * wide
            val tx = left + 2.dp.toPx() + (w - 4.dp.toPx() - tw) * pos
            val ty = top + (h - th) / 2
            drawRoundRect(Color.Black.copy(alpha = 0.18f), Offset(tx, ty + 1.5.dp.toPx()), Size(tw, th), CornerRadius(th / 2))
            drawRoundRect(thumb, Offset(tx, ty), Size(tw, th), CornerRadius(th / 2))
            drawRoundRect(Brush.verticalGradient(listOf(edge, Color.Transparent), ty, ty + th / 2), Offset(tx, ty), Size(tw, th), CornerRadius(th / 2),
                style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
        })
}
