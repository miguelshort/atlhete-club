package app.fuckrun.domain

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

/** Resultados por familia de meta: justo por debajo del umbral, en él y por encima. */
class AchievementsTest {
    private val d0 = LocalDate.of(2026, 11, 2)   // lunes
    private var n = 0
    private fun s(sport: Sport, km: Double?, min: Double, k1: Long? = null, day: Int = n, measured: Boolean = true, planned: String? = null,
                  route: String? = null, covered: Boolean = false, id: String? = null): SessionFacts {
        n++
        return SessionFacts(id ?: "s$n", sport, 1_000_000L + day * 86_400_000L + n, d0.plusDays(day.toLong()), measured, (min * 60_000).toLong(),
            km?.times(1000.0), k1, planned, route, covered)
    }
    private fun reached(h: List<SessionFacts>, routes: Boolean = true) = Rewards.replay(h, routes).reached.keys

    @Test fun ninetySixAchievementsMatchTheCatalog() {
        assertEquals(96, Achievements.all.size)
        assertEquals(Achievements.all.map { it.id }.toSet(), app.fuckrun.domain.art.GearCatalog.achievements.map { it.id }.toSet())
    }

    @Test fun pace1kExample() {
        // 6:12 y después 6:05 min/km: la primera fija la referencia; la segunda desbloquea COR-23.
        val a = s(Sport.RUN, 3.0, 20.0, 372_000)
        val b = s(Sport.RUN, 3.0, 20.0, 365_000)
        val r = Rewards.replay(listOf(a, b))
        assertTrue("COR-23" !in r.sessions[a.syncId]!!.unlocked)
        assertTrue("COR-23" in r.sessions[b.syncId]!!.unlocked)
        assertEquals(10 + 5, r.sessions[b.syncId]!!.points)
        // Reabrir el resumen u obtener otra vez 6:05 no duplica la pieza ni los puntos.
        val c = s(Sport.RUN, 3.0, 20.0, 365_000)
        val r2 = Rewards.replay(listOf(a, b, c))
        assertEquals(b.syncId, r2.reached["COR-23"])
        assertEquals(10, r2.sessions[c.syncId]!!.points)
        assertEquals(r.sessions[b.syncId]!!.entries, Rewards.replay(listOf(b, a)).sessions[b.syncId]!!.entries)
    }

    @Test fun displayedPrecisionTiesDoNotReward() {
        val a = s(Sport.RUN, 5.004, 30.0, 300_200)
        val b = s(Sport.RUN, 5.0049, 30.0002, 300_400)   // 5,00 km · 30:00 · 5:00 min/km: iguales a la vista
        val r = Rewards.replay(listOf(a, b))
        assertEquals(10, r.sessions[b.syncId]!!.points)
        assertTrue(r.sessions[b.syncId]!!.changes.isEmpty())
    }

    @Test fun sumKmWithoutRecord() {
        // Excursiones que suben el acumulado de 24,9 a 25,1 km: aparece SEN-06 aunque no haya marca nueva.
        val h = listOf(s(Sport.HIKE, 12.5, 150.0), s(Sport.HIKE, 12.4, 140.0))
        assertFalse("SEN-06" in reached(h))
        val last = s(Sport.HIKE, 0.2, 6.0)
        val r = Rewards.replay(h + last)
        assertTrue("SEN-06" in r.sessions[last.syncId]!!.unlocked)
        assertTrue(r.sessions[last.syncId]!!.changes.none { !it.isReference })
    }

    @Test fun sessionsFamily() {
        val two = (1..2).map { s(Sport.BIKE, 5.0, 20.0) }
        assertFalse("BIC-02" in reached(two))
        assertTrue("BIC-02" in reached(two + s(Sport.BIKE, 5.0, 20.0)))
        assertTrue("BIC-02" in reached(two + (1..2).map { s(Sport.BIKE, 5.0, 20.0) }))
        assertTrue("BIC-01" in reached(two))
    }

    @Test fun singleKmFamily() {
        assertFalse("CAM-10" in reached(listOf(s(Sport.WALK, 2.99, 40.0))))
        assertTrue("CAM-10" in reached(listOf(s(Sport.WALK, 3.0, 40.0))))
        assertTrue("CAM-10" in reached(listOf(s(Sport.WALK, 3.4, 40.0))))
        assertFalse("CAM-11" in reached(listOf(s(Sport.WALK, 3.4, 40.0))))
    }

    @Test fun minutesFamilyCountsWithoutGps() {
        // Tiempo válido y GPS insuficiente: cuenta para tiempo y constancia, no para distancia.
        val h = listOf(s(Sport.RUN, null, 59.0))
        assertFalse("COR-12" in reached(h))
        val r = Rewards.replay(h + s(Sport.RUN, null, 1.0 + 5.0))
        assertTrue("COR-12" in r.reached)
        assertTrue("COR-02" !in r.reached && "COR-01" in r.reached)
        assertEquals(0.0, r.of(Sport.RUN).sumKm, 0.0)
    }

    @Test fun manualAndShortSessionsDoNotCount() {
        val r = Rewards.replay(listOf(s(Sport.RUN, 10.0, 60.0, measured = false), s(Sport.RUN, 1.0, 4.9)))
        assertTrue(r.reached.isEmpty())
        assertEquals(0, r.of(Sport.RUN).sessions)
        assertTrue(r.sessions.values.all { it.points == 0 })
    }

    @Test fun weeksFamilyCountsDistinctWeeksNotConsecutive() {
        val h = listOf(s(Sport.WALK, 1.0, 10.0, day = 0), s(Sport.WALK, 1.0, 10.0, day = 6), s(Sport.WALK, 1.0, 10.0, day = 14))
        assertFalse("CAM-15" in reached(h))       // lunes y domingo de la misma semana
        assertTrue("CAM-15" in reached(h + s(Sport.WALK, 1.0, 10.0, day = 40)))
    }

    @Test fun plannedCountsOnce() {
        val h = listOf(s(Sport.HIKE, 3.0, 30.0, planned = "p1"), s(Sport.HIKE, 3.0, 30.0, planned = "p1"))
        assertFalse("SEN-17" in reached(h))
        assertTrue("SEN-17" in reached(h + s(Sport.HIKE, 3.0, 30.0, planned = "p2")))
    }

    @Test fun improvementsFamily() {
        val h = listOf(s(Sport.BIKE, 10.0, 30.0), s(Sport.BIKE, 11.0, 29.0), s(Sport.BIKE, 12.0, 28.0))
        val r = Rewards.replay(h)
        assertTrue("BIC-19" in r.reached); assertFalse("BIC-20" in r.reached)
        assertEquals("2 de 3 mejoras de distancia", Rewards.progressText(Achievements.byId("BIC-20")!!, r.of(Sport.BIKE)))
        assertTrue("BIC-20" in reached(h + s(Sport.BIKE, 13.0, 28.0)))
    }

    @Test fun routesAndAlternative() {
        val h = listOf(s(Sport.HIKE, 5.0, 60.0, route = "a", covered = true), s(Sport.HIKE, 5.0, 60.0, route = "a", covered = true),
            s(Sport.HIKE, 5.0, 60.0, route = "b", covered = false), s(Sport.HIKE, 5.0, 60.0, route = "c", covered = true))
        assertFalse("SEN-23" in reached(h))
        assertTrue("SEN-23" in reached(h + s(Sport.HIKE, 5.0, 60.0, route = "d", covered = true)))
        // Sin catálogo en el municipio: 4 semanas activas.
        val weeks = (0..3).map { s(Sport.HIKE, 2.0, 20.0, day = it * 7) }
        assertFalse("SEN-23" in reached(weeks.take(3), routes = false))
        assertTrue("SEN-23" in reached(weeks, routes = false))
        assertFalse("SEN-23" in reached(weeks, routes = true))
    }

    @Test fun importedOldActivitiesReplayInDateOrder() {
        val late = s(Sport.RUN, 4.0, 25.0, 330_000, day = 10)
        val early = s(Sport.RUN, 3.0, 20.0, 360_000, day = 1)
        val r = Rewards.replay(listOf(late, early))
        assertTrue(r.sessions[early.syncId]!!.changes.all { it.isReference })
        assertEquals(10 + 3 * 5, r.sessions[late.syncId]!!.points)
    }

    @Test fun progressTexts() {
        val r = Rewards.replay(listOf(s(Sport.HIKE, 18.0, 200.0)))
        assertEquals("18 de 25 km en Sendero", Rewards.progressText(Achievements.byId("SEN-06")!!, r.of(Sport.HIKE)))
        assertEquals("0 de 1 mejora de ritmo en 1 km", Rewards.progressText(Achievements.byId("COR-23")!!, Rewards.replay(emptyList()).of(Sport.RUN)))
    }

    @Test fun routeCoverage() {
        val route = (0..100).map { RouteCoverage.Pt(40.0 + it * 0.0001, -3.0) }   // ≈ 1,1 km
        val full = route.map { RouteCoverage.Pt(it.lat, it.lon + 0.0001) }      // a ~8 m
        assertTrue(RouteCoverage.fraction(route, full) > 0.95)
        assertTrue(RouteCoverage.fraction(route, full.reversed()) > 0.95)           // sentido inverso
        assertFalse(RouteCoverage.fraction(route, full.reversed(), bidirectional = false) >= 0.8)
        assertTrue(RouteCoverage.fraction(route, full.take(70)) < RouteCoverage.REQUIRED)
        assertTrue(RouteCoverage.fraction(route, full.take(85)) >= RouteCoverage.REQUIRED)
        assertEquals(0.0, RouteCoverage.fraction(route, route.map { RouteCoverage.Pt(it.lat, it.lon + 0.01) }), 0.0)
        assertEquals(0.0, RouteCoverage.fraction(listOf(route[0], route[0]), full), 0.0)
    }
}
