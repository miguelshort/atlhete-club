package app.fuckrun.domain.art

import app.fuckrun.domain.Sport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Comprueba el catálogo ilustrado y, si se pasa -Dart.out=<carpeta>, exporta las láminas (hoja de modelo, control de
 * calidad e inventario por deporte) a partir de las mismas piezas que equipa la app.
 */
class ArtSheetsTest {
    private val out: File? = System.getProperty("art.out")?.let { File(it).apply { mkdirs() } }

    @Test fun catalogHas96UniqueAchievementPieces() {
        val ids = GearCatalog.achievements.map { it.id }
        assertEquals(96, ids.size)
        assertEquals(96, ids.toSet().size)
        for (s in Sport.entries) assertEquals(24, GearCatalog.achievements.count { it.sport == s })
        // Ninguna pieza de logro repite nombre (las de una familia se distinguen por corte, construcción o función).
        assertEquals(96, GearCatalog.achievements.map { it.name }.toSet().size)
    }

    @Test fun everyPieceHasItsOwnDrawing() {
        val seen = HashSet<String>()
        for (g in GearCatalog.all) {
            val dr = GearArt.thumbnail(g)
            assertNotNull("sin dibujo: ${g.id}", dr.bounds())
            val sig = svg(dr)
            assertTrue("dibujo repetido: ${g.id}", seen.add(sig))
        }
    }

    @Test fun everyPieceShowsOnTheBody() {
        for (g in GearCatalog.all) {
            val pose = if (g.slot.group == Slot.Group.BIKE) ArtPose.BIKE else ArtPose.IDLE
            val base = svg(Figure.draw(Scene(AvatarLook.DEFAULT, Outfit.DEFAULT, pose = pose)).first)
            val worn = svg(Figure.draw(Scene(AvatarLook.DEFAULT, Outfit.DEFAULT.with(g), pose = pose)).first)
            assertTrue("no cambia el cuerpo: ${g.id}", worn != base || Outfit.DEFAULT.isWearing(g.id))
        }
    }

    @Test fun identityOptionsAreComplete() {
        assertEquals(12, Looks.skins.size); assertEquals(6, Looks.faces.size); assertEquals(6, Looks.eyes.size); assertEquals(8, Looks.irises.size)
        assertEquals(6, Looks.brows.size); assertEquals(5, Looks.noses.size); assertEquals(6, Looks.mouths.size)
        assertEquals(7, Looks.facialHair.size); assertEquals(4, Looks.glasses.size)
        assertEquals(25, Looks.hairStyles.size); assertEquals(12, Looks.hairColors.size); assertEquals(4, Looks.builds.size); assertEquals(3, Looks.heights.size)
        assertEquals(3, Looks.skins.map { it.note }.toSet().size)
    }

    @Test fun oldIdsAreTranslated() {
        assertEquals("BIC-23", GearCatalog.translate("glasses_bike"))
        assertEquals("COR-23", GearCatalog.translate("headband_run"))
        val old = Outfit(top = "top_bicolor", bottom = "bottom_stripe", longLegs = true, shoes = "shoes_relief", accessories = mapOf("HEAD" to "headband_run"))
        val m = old.migrated()
        assertEquals("tee_raglan", m.items["TOP"]); assertEquals("stripe_long", m.items["BOTTOM"]); assertEquals("shoe_trail", m.items["SHOES"])
        assertEquals("COR-23", m.items["HEAD"])
        assertEquals(19, AvatarLook(hair = 3).migrated().hair)
    }

    @Test fun sheets() {
        val dir = out ?: return
        modelSheet(dir); qaSheet(dir); hairSheet(dir)
        for (s in Sport.entries) inventory(dir, s)
    }

    private fun svg(dr: Drawing): String { val a = StringBuilder(); val b = StringBuilder(); SvgExport.ops(a, b, dr.ops); return a.toString().replace(Regex("url\\(#[cm]\\d+\\)"), "") }

    // ---------------------------------------------------------------- láminas

    private val people = listOf(
        AvatarLook(skin = 9, face = 2, eyes = 0, iris = 0, brows = 3, nose = 3, mouth = 0, hair = 15, hairColor = 0, build = 2, height = 2, facialHair = 4, v = 2),
        AvatarLook(skin = 1, face = 3, eyes = 3, iris = 6, brows = 1, nose = 4, mouth = 4, freckles = 0.8f, hair = 19, hairColor = 7, build = 0, height = 1, v = 2),
        AvatarLook(skin = 6, face = 4, eyes = 5, iris = 1, brows = 4, nose = 1, mouth = 1, hair = 2, hairColor = 1, build = 1, height = 0, glasses = 2, v = 2),
        AvatarLook(skin = 11, face = 0, eyes = 1, iris = 0, brows = 2, nose = 0, mouth = 5, hair = 17, hairColor = 0, build = 3, height = 1, v = 2),
    )

    private fun outfit(vararg ids: String) = ids.fold(Outfit.DEFAULT) { o, id -> o.with(GearCatalog.byId(id)!!) }
    private val sportOutfits = mapOf(
        Sport.RUN to outfit("COR-04", "COR-13", "COR-20", "COR-23", "COR-14", "COR-02"),
        Sport.HIKE to outfit("SEN-03", "SEN-07", "SEN-10", "SEN-06", "SEN-04", "SEN-02", "SEN-11"),
        Sport.BIKE to outfit("BIC-03", "BIC-04", "BIC-10", "BIC-07", "BIC-23", "BIC-06", "BIC-01", "BIC-05", "BIC-09", "BIC-12"),
        Sport.WALK to outfit("CAM-03", "CAM-11", "CAM-07", "CAM-15", "CAM-10", "CAM-05"),
    )
    private fun poseOf(s: Sport) = when (s) { Sport.RUN -> ArtPose.RUN; Sport.HIKE -> ArtPose.HIKE; Sport.BIKE -> ArtPose.BIKE; Sport.WALK -> ArtPose.WALK }

    private fun fig(sb: StringBuilder, defs: StringBuilder, s: Scene, x: Float, y: Float, w: Float, h: Float, portrait: Boolean = false) {
        val (dr, sk) = Figure.draw(s)
        val v = Figure.viewport(s.pose, portrait, sk)
        SvgExport.cell(sb, defs, dr, floatArrayOf(v.l, v.t, v.l + v.w, v.t + v.h), x, y, w, h)
    }

    private fun write(dir: File, name: String, svg: String) = File(dir, name).writeText(svg)

    private fun modelSheet(dir: File) {
        val sb = StringBuilder(); val defs = StringBuilder()
        SvgExport.text(sb, 40f, 50f, "Athlete Club · hoja de modelo del avatar 2D", 26f, anchor = "start")
        SvgExport.text(sb, 40f, 76f, "Cuatro personas, frente y tres cuartos, retrato de 48 dp, cara y manos ampliadas, un conjunto por deporte", 14f, "#5a6170", "start")
        people.forEachIndexed { i, p ->
            val x = 40f + i * 400f
            fig(sb, defs, Scene(p, Outfit.DEFAULT, ArtView.FRONT), x, 100f, 180f, 360f)
            fig(sb, defs, Scene(p, Outfit.DEFAULT, ArtView.THREE_QUARTER, expr = Expression(smile = 0.6f)), x + 190f, 100f, 180f, 360f)
            fig(sb, defs, Scene(p, Outfit.DEFAULT), x + 20f, 480f, 48f, 48f, portrait = true)
            fig(sb, defs, Scene(p, Outfit.DEFAULT), x + 90f, 470f, 96f, 96f, portrait = true)
            SvgExport.text(sb, x + 185f, 600f, "${Looks.hairStyles[p.hair].name} · ${Looks.skins[p.skin].name} · ${Looks.builds[p.build].name}", 13f, "#5a6170")
        }
        // Cara y manos ampliadas.
        val face = Figure.draw(Scene(people[1], Outfit.DEFAULT, ArtView.THREE_QUARTER, expr = Expression(smile = 0.7f, brow = 0.6f)))
        SvgExport.cell(sb, defs, face.first, floatArrayOf(face.second.hc.x - 40f, face.second.hc.y - 48f, face.second.hc.x + 40f, face.second.hc.y + 44f), 40f, 630f, 300f, 340f)
        val wave = Figure.draw(Scene(people[0], outfit("COR-07"), ArtView.THREE_QUARTER, wave = 0.5f))
        SvgExport.cell(sb, defs, wave.first, floatArrayOf(wave.second.wr[0].x - 30f, wave.second.wr[0].y - 40f, wave.second.wr[0].x + 30f, wave.second.wr[0].y + 24f), 360f, 630f, 260f, 280f)
        val grip = Figure.draw(Scene(people[2], outfit("SEN-11"), pose = ArtPose.HIKE))
        SvgExport.cell(sb, defs, grip.first, floatArrayOf(grip.second.wr[0].x - 30f, grip.second.wr[0].y - 30f, grip.second.wr[0].x + 30f, grip.second.wr[0].y + 30f), 640f, 630f, 260f, 280f)
        SvgExport.text(sb, 190f, 990f, "Rostro: párpado, ceja levantada, nariz y sonrisa asimétrica", 13f, "#5a6170")
        SvgExport.text(sb, 640f, 990f, "Mano saludando (manga larga con pulgar) · dedos sujetando el bastón", 13f, "#5a6170")
        Sport.entries.forEachIndexed { i, s ->
            val x = 40f + i * 400f
            fig(sb, defs, Scene(people[i], sportOutfits[s]!!, pose = poseOf(s)), x, 1010f, 360f, 360f)
            SvgExport.text(sb, x + 180f, 1390f, "${s.label}: pose propia y conjunto", 14f)
        }
        write(dir, "hoja_modelo.svg", SvgExport.doc(1640, 1420, "#f4f6f9", sb, defs))
    }

    private fun qaSheet(dir: File) {
        val sb = StringBuilder(); val defs = StringBuilder()
        SvgExport.text(sb, 40f, 50f, "Control de calidad artístico", 26f, anchor = "start")
        val base = people[0]
        val cases = listOf(
            "Afro y casco" to Scene(base, outfit("BIC-07"), ArtView.THREE_QUARTER),
            "Trenzas y mochila" to Scene(people[1].copy(hair = 17), outfit("SEN-04")),
            "Rapado y gafas" to Scene(people[2].copy(hair = 1), outfit("BIC-23")),
            "Manga larga al saludar" to Scene(people[3], outfit("COR-07"), wave = 0.55f),
            "Pantalón largo y botas" to Scene(base.copy(hair = 13), outfit("straight_long", "SEN-10")),
            "Complexión más ancha" to Scene(base.copy(build = 3, hair = 4), outfit("SEN-08", "SEN-07")),
            "Complexión más estrecha" to Scene(base.copy(build = 0, hair = 4), outfit("SEN-08", "SEN-07")),
            "Cambio de tono de piel" to Scene(base.copy(skin = 0, hair = 4), outfit("COR-04")),
        )
        cases.forEachIndexed { i, (label, s) ->
            val x = 40f + (i % 4) * 400f; val y = 80f + (i / 4) * 440f
            fig(sb, defs, s, x + 60f, y, 260f, 380f)
            SvgExport.text(sb, x + 190f, y + 410f, label, 15f)
        }
        // Tema oscuro: halos.
        val dark = StringBuilder(); val dd = StringBuilder()
        fig(dark, dd, Scene(base, outfit("BIC-07", "BIC-08")), 20f, 20f, 260f, 380f)
        write(dir, "control_calidad.svg", SvgExport.doc(1640, 980, "#f4f6f9", sb, defs))
        write(dir, "tema_oscuro.svg", SvgExport.doc(300, 420, "#0b0c0f", dark, dd))
    }

    private fun hairSheet(dir: File) {
        val sb = StringBuilder(); val defs = StringBuilder()
        SvgExport.text(sb, 40f, 50f, "24 peinados (y sin pelo) · Rostro y Pelo con encuadre cercano", 24f, anchor = "start")
        Looks.hairStyles.forEachIndexed { i, st ->
            val x = 30f + (i % 9) * 178f; val y = 80f + (i / 9) * 240f
            val look = people[i % 4].copy(hair = i, hairColor = i % 12)
            fig(sb, defs, Scene(look, Outfit.DEFAULT, if (i % 2 == 0) ArtView.THREE_QUARTER else ArtView.FRONT), x, y, 160f, 190f, portrait = true)
            SvgExport.text(sb, x + 80f, y + 212f, st.name, 13f)
        }
        write(dir, "peinados.svg", SvgExport.doc(1650, 820, "#f4f6f9", sb, defs))
    }

    private fun inventory(dir: File, s: Sport) {
        val sb = StringBuilder(); val defs = StringBuilder()
        SvgExport.text(sb, 40f, 50f, "Inventario de ${s.label}: 24 recompensas de logro", 24f, anchor = "start")
        GearCatalog.achievements.filter { it.sport == s }.forEachIndexed { i, g ->
            val x = 30f + (i % 6) * 270f; val y = 80f + (i / 6) * 260f
            sb.append("<rect x=\"$x\" y=\"$y\" width=\"250\" height=\"240\" rx=\"20\" fill=\"#ffffff\" stroke=\"#e1e5ec\"/>")
            val dr = GearArt.thumbnail(g)
            val b = dr.bounds()!!
            val pad = 6f
            SvgExport.cell(sb, defs, dr, floatArrayOf(b[0] - pad, b[1] - pad, b[2] + pad, b[3] + pad), x + 20f, y + 14f, 210f, 160f)
            SvgExport.text(sb, x + 125f, y + 196f, g.id, 13f, "#5a6170")
            val words = g.name.split(" "); val lines = mutableListOf(""); words.forEach { w -> if ((lines.last() + " " + w).length > 30) lines += w else lines[lines.size - 1] = (lines.last() + " " + w).trim() }
            lines.take(2).forEachIndexed { k, l -> SvgExport.text(sb, x + 125f, y + 214f + k * 15f, l, 13f) }
        }
        write(dir, "inventario_${s.name.lowercase()}.svg", SvgExport.doc(1640, 1140, "#f4f6f9", sb, defs))
    }
}
