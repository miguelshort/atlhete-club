package app.fuckrun.domain.art

/** Exporta un [Drawing] a SVG: el mismo dibujo que pinta la app, para láminas de modelo e inventario. */
object SvgExport {
    private var id = 0

    fun d(p: Path): String = buildString {
        for (c in p.cmds) when (c) {
            is Cmd.M -> append("M${f(c.p.x)} ${f(c.p.y)}")
            is Cmd.L -> append("L${f(c.p.x)} ${f(c.p.y)}")
            is Cmd.Q -> append("Q${f(c.c.x)} ${f(c.c.y)} ${f(c.p.x)} ${f(c.p.y)}")
            is Cmd.C -> append("C${f(c.c1.x)} ${f(c.c1.y)} ${f(c.c2.x)} ${f(c.c2.y)} ${f(c.p.x)} ${f(c.p.y)}")
            Cmd.Z -> append("Z")
        }
    }
    private fun f(v: Float) = "%.2f".format(java.util.Locale.ROOT, v)

    private fun paint(c: Long) = "${Col.hex(c)}\" fill-opacity=\"${"%.3f".format(java.util.Locale.ROOT, Col.a(c) / 255.0)}"

    fun ops(sb: StringBuilder, defs: StringBuilder, list: List<Op>) {
        for (op in list) when (op) {
            is Op.Fill -> sb.append("<path d=\"${d(op.path)}\" fill=\"${paint(op.color)}\"/>")
            is Op.Stroke -> sb.append("<path d=\"${d(op.path)}\" fill=\"none\" stroke=\"${Col.hex(op.color)}\" stroke-opacity=\"${"%.3f".format(java.util.Locale.ROOT, Col.a(op.color) / 255.0)}\" stroke-width=\"${f(op.width)}\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>")
            is Op.Group -> {
                var open = "<g"
                if (op.clip != null) { val i = ++id; defs.append("<clipPath id=\"c$i\"><path d=\"${d(op.clip)}\"/></clipPath>"); open += " clip-path=\"url(#c$i)\"" }
                if (op.clipOut != null) { val i = ++id
                    defs.append("<mask id=\"m$i\" maskUnits=\"userSpaceOnUse\" x=\"-2000\" y=\"-2000\" width=\"4000\" height=\"4000\"><rect x=\"-2000\" y=\"-2000\" width=\"4000\" height=\"4000\" fill=\"#fff\"/><path d=\"${d(op.clipOut)}\" fill=\"#000\"/></mask>")
                    open += " mask=\"url(#m$i)\"" }
                sb.append("$open>"); ops(sb, defs, op.ops); sb.append("</g>")
            }
        }
    }

    /** Coloca un dibujo dentro de una celda (x, y, w, h) ajustando el rectángulo de origen [vb]. */
    fun cell(sb: StringBuilder, defs: StringBuilder, dr: Drawing, vb: FloatArray, x: Float, y: Float, w: Float, h: Float) {
        val sw = vb[2] - vb[0]; val shh = vb[3] - vb[1]
        val k = minOf(w / sw, h / shh)
        val ox = x + (w - sw * k) / 2 - vb[0] * k; val oy = y + (h - shh * k) / 2 - vb[1] * k
        val cid = ++id
        defs.append("<clipPath id=\"k$cid\"><rect x=\"${f(x)}\" y=\"${f(y)}\" width=\"${f(w)}\" height=\"${f(h)}\"/></clipPath>")
        sb.append("<g clip-path=\"url(#k$cid)\"><g transform=\"translate(${f(ox)} ${f(oy)}) scale(${f(k)})\">"); ops(sb, defs, dr.ops); sb.append("</g></g>")
    }

    fun text(sb: StringBuilder, x: Float, y: Float, s: String, size: Float = 12f, color: String = "#2a2e34", anchor: String = "middle") {
        sb.append("<text x=\"${f(x)}\" y=\"${f(y)}\" font-family=\"Inter, DejaVu Sans, sans-serif\" font-size=\"${f(size)}\" letter-spacing=\"-0.08em\" fill=\"$color\" text-anchor=\"$anchor\">")
        sb.append(s.replace("&", "&amp;").replace("<", "&lt;")); sb.append("</text>")
    }

    fun doc(w: Int, h: Int, bg: String, body: StringBuilder, defs: StringBuilder) =
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$w\" height=\"$h\" viewBox=\"0 0 $w $h\"><defs>$defs</defs><rect width=\"$w\" height=\"$h\" fill=\"$bg\"/>$body</svg>"
}
