# Puntos, marcas y logros

## Reglas
- **Sesión válida**: personal, medida con GPS, guardada y ≥ 5 min activos → +10 puntos («act:<actividad>»). Las manuales
  siguen en el historial pero no suman. Con tiempo válido y GPS insuficiente cuenta para tiempo y constancia, no para km.
- **Marcas** (contra actividades ANTERIORES del mismo deporte, en orden de fecha con desempate estable): la primera fija
  la referencia; cada mejora estricta → +5 («rec:<actividad>:<categoría>»). Se compara en la precisión mostrada
  (km con 2 decimales, segundos, s/km, décimas de km/h). Mejor km: ventanas continuas de 1 km interpoladas, sin pausas
  ni huecos; Bicicleta compara velocidad y los deportes a pie, ritmo.
- **Sumar** = total histórico; **en una sesión** = una actividad; **semanas distintas** = semanas lunes–domingo con
  actividad válida; **planificadas** = sesión vinculada a una actividad completada del deporte (una vez cada una);
  **rutas verificadas distintas** = ≥ 80 % del trazado seguido (tolerancia 35 m, admite sentido inverso). Sin catálogo
  en el municipio: SEN-23/24 con 4 y 8 semanas activas.
- **Concesión**: al cruzar un umbral, todas las piezas recién elegibles a la vez (`inventory`, id = pieza, por cuenta).
  Lo conseguido no se retira al borrar actividades; el progreso se recalcula con el historial vigente.
- **Puntos ya pagados no se vuelven a acreditar**: una actividad se evalúa una sola vez.
- **Actualización, importación y sincronización**: `reconcile()` reproduce el historial en orden cronológico y concede lo
  pendiente; es idempotente, así que dos móviles o una reinstalación convergen.
- **Compras**: confirmación previa, transacción «buy:<pieza>», sin saldo negativo ni cargo doble. Comprar ≠ equipar.

## Resultados de las pruebas (app/src/test/.../AchievementsTest.kt)
| Familia | Por debajo | En el umbral | Por encima |
|---|---|---|---|
| Sesiones (BIC-02) | 2 → no | 3 → sí | 4 → sí |
| Km en una sesión (CAM-10) | 2,99 → no | 3,00 → sí | 3,4 → sí |
| Km acumulados (SEN-06) | 24,9 → no | 25,1 → sí, sin marca | — |
| Minutos (COR-12, sin GPS) | 59 → no | 65 → sí | — |
| Semanas distintas (CAM-15) | 3 días en 2 semanas → no | 3 semanas → sí | — |
| Planificadas (SEN-17) | misma sesión dos veces → 1 | 2 distintas → sí | — |
| Mejoras (BIC-19/20) | 2 mejoras → BIC-19 sí, BIC-20 no | 3 → BIC-20 sí | — |
| Ritmo 1 km (COR-23) | 6:12 → referencia | 6:05 → sí, +5 | repetir 6:05 → nada |
| Rutas (SEN-23) | 2 distintas cubiertas → no | 3 → sí | sin catálogo: 4 semanas |
| Manual / < 5 min | no puntúan ni cuentan | | |
| Importación desordenada | se evalúa por fecha | | |
