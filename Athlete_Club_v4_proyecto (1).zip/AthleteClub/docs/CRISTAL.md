# Material de cristal

## Capas
1. **Escena** (`Backdrop`): la pantalla se registra en una `GraphicsLayer` cada fotograma (GPU, sin capturas en CPU).
   Raíz → barra y menús. Escenas locales → Rutas (mapa) y Preparar (contenido bajo «Empezar»). Lo que está DENTRO de una
   escena no puede usarla (recursión): ahí `LocalBackdrop = null` y el control usa la película de su variante reducida.
2. **Centro**: `BlurEffect` sobre la muestra recortada (área visible del control + margen). Radio por control.
3. **Borde** (Android 13+): `RuntimeShader` AGSL sobre la escena nítida; franja de 9 dp, desplazamiento de 6 dp, se
   desvanece hacia dentro. Uniformes: límites, radio, posición y progreso de la presión.
4. **Volumen y contraste**: sombra corta de contacto, tinte base (oscuro 0,34 · claro 0,46; acción 0,72) + 0,18 × detalle
   del fondo; tinta clara u oscura según la luminosidad medida (≤ 3 sondeos por segundo, transición de 280–320 ms).
5. **Primer plano**: iconos y textos encima, nítidos.

## Variantes
| Android | Resultado |
|---|---|
| 13+ | Completo: centro difuminado + borde refractado + reflejo curvado |
| 12 | Centro difuminado y respuesta táctil; sin borde refractado (filo de luz en gradiente) |
| ≤ 11 o «Reducir transparencia» | Película casi opaca, misma respuesta táctil |

## Mapa
osmdroid dibuja una vista normal (no `SurfaceView`), así que participa en la escena. **Comprobar en dispositivo** que
la capa de Compose registra el mapa; si un fabricante usara aceleración por superficie aparte, el cristal mostraría la
película reducida sobre el mapa.

## Prueba de aceptación (en teléfono)
Grabar a velocidad normal: reposo, presión izquierda/derecha/centro, presión mantenida moviendo el dedo, liberación,
menú a media apertura y cierre interrumpido; en claro y oscuro, con una ruta azul y el borde de un parque pasando bajo la
barra (Rutas → mapa). Comprobar: desviación del trazo en el canto, difusión central, icono nítido, el mismo parque en la
misma posición detrás del menú abierto. Anotar dispositivo, versión de Android y variante mostrada.
