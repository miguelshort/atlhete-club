# Avatar 2D

## Producción
- Ilustración vectorial original generada por código (`domain/art/`), en Kotlin puro: el mismo dibujo lo pinta Compose
  en la app y lo exporta a SVG por capas el test `ArtSheetsTest` (`-Dart.out=carpeta`).
- Esqueleto 2D con anclajes de cabeza, clavícula (hombros), codo, mano, cintura, cadera, rodilla, tobillo y pie (`Sk`).
  Piezas separadas: pelo trasero y delantero, pupila y párpado, brazo lejano y cercano, cuerpo y mangas.
- Máscaras: casco/gorra recortan el pelo por encima del ala (no lo atraviesa); calcetines bajo el pantalón; gafas sobre
  la cara; mochila con volumen detrás del cuerpo y correas delante del torso.
- Ropa construida sobre las articulaciones: se adapta a 4 complexiones y 3 estaturas.
- Bici auxiliar con anclajes compartidos (tubo diagonal, tubo de sillín, triángulo, sillín, manillar, portaequipajes).
- Poses: reposo (peso en una pierna), Correr (pie adelantado, brazos flexionados), Sendero (mano en el bastón),
  Bicicleta (manos en el manillar), Caminata (zancada relajada). Vistas dibujadas de frente y de tres cuartos.

## Interacción
Respiración y parpadeo en reposo; tocar la cara → mirada al toque y sonrisa; tocar la mano → saludo con anticipación
del codo y retraso de la muñeca; deslizar → frente / tres cuartos. Movimiento reducido: pose estática expresiva.
Retrato en caché (`avatar_portrait.png`) que se actualiza al equipar.

## Identidad (gratis desde el inicio)
12 tonos de piel (cálidos, neutros y fríos), 6 contornos, 6 ojos, 8 iris, 6 cejas, 5 narices, 6 bocas, pecas en 4 niveles,
7 opciones de vello facial (incluida afeitado), 3 familias de gafas de diario, 24 peinados + sin pelo, 12 colores de pelo,
4 complexiones, 3 estaturas.

## Vestuario
Inicial: camiseta lisa de cuello redondo, bicolor raglán, calzonas y pantalón (recto y con banda), dos zapatillas.
Color principal y acento por prenda (16 muestras con nombre). Probar, Equipar, Quitar, Deshacer. Conjunto por deporte
(guardar, usar, copiar). Tienda (8 básicos por puntos) y 96 piezas de logro, cada una con dibujo propio (comprobado por test).

## Pendiente de revisión humana
El dibujo procedural es la base de producción, pero conviene que un ilustrador revise expresividad y acabado, sobre todo
los peinados de volumen (casquete) y las caras a 48 dp. Láminas en docs/arte/.
