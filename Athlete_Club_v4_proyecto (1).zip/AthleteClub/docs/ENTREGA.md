# Entrega v4 — Corrección: cristal, avatar 2D y 96 recompensas

## Qué cambia

**Cristal de los controles** (`ui/components/Glass.kt`, `Components.kt`):
- Escena compartida propia (sustituye a Haze): el contenido se registra en una capa de GPU y la barra, los menús y los
  controles flotantes la muestrean en sus coordenadas de pantalla. Fuera del control, la escena conserva toda su definición.
- Centro difuminado (32 dp en barra y menús; menos en el selector cerrado, más al abrirse).
- Borde refractado con shader AGSL en Android 13+: desplazamiento perpendicular al contorno en una franja estrecha que se
  desvanece hacia el centro, y reflejo con la misma curvatura (gana luz arriba-izquierda, la pierde en el lado opuesto).
- Sombra de contacto, tinte y color de tinta adaptados a lo que hay detrás (sondeo de la muestra ya difuminada ~3 veces
  por segundo, transiciones suavizadas).
- Respuesta táctil asimétrica: cede 1–3 dp hacia el lado tocado con el extremo opuesto anclado, entrada de 85 ms desde el
  primer fotograma, brillo que sigue al dedo, retorno con muelle de ~170 ms, acción una sola vez al soltar, cancelación
  si el gesto pasa a desplazamiento.
- Menús que crecen desde el propio control (una sola silueta), con más difusión y sombra a medida que se abren; se
  invierten desde el fotograma en curso al cerrar; abren por arriba si no cabe debajo; el foco vuelve al botón.
- Barra inferior con una sola lente que se estira hacia la pestaña elegida; con movimiento reducido, solo tinte breve.
- Perfil → «Reducir transparencia» (y el texto de alto contraste del sistema) aumentan la opacidad.
- Las tres escenas de ajuste: **Rutas** tiene ahora vista de mapa con el selector «Deporte» de cristal encima y la barra
  sobre el mapa; **Preparar** tiene «Empezar» flotando sobre el contenido (mapa de la ruta, música y texto); **Inicio**
  y **Perfil** dan el fondo casi uniforme.

**Avatar 2D** (`domain/art/`, `ui/components/Avatar.kt`, `ui/screens/WardrobeScreen.kt`): ver docs/AVATAR.md.

**Logros y puntos** (`domain/Rewards.kt`, `data/Rewards.kt`): ver docs/LOGROS.md.

**Base de datos v4**: cobertura de ruta por actividad y traducción de identificadores de la v3 (nada conseguido se pierde).

## Comprobado aquí
- 46 pruebas de dominio correctas (logros por familia de meta, ejemplo 6:12 → 6:05, 24,9 → 25,1 km, GPS insuficiente,
  manual, importación desordenada, cobertura de ruta, catálogo de 96 piezas con dibujo propio, traducción de ids).
- Láminas exportadas del mismo motor que dibuja la app: docs/arte/hoja_modelo, control_calidad, peinados, tema_oscuro e
  inventario_{run,hike,bike,walk} (SVG vectorial por capas + PNG).

## No se ha podido hacer aquí (requiere SDK de Android o un teléfono)
- Compilar el APK: lo hace el workflow de GitHub (`.github/workflows/build.yml`), que imprime los errores en el resumen.
- Grabar el gesto en la barra y en «Deporte» y comparar con los capítulos de Apple: procedimiento en docs/CRISTAL.md.
- Probar en dispositivo qué variante del cristal se ve (completa, sin borde o reducida) y afinar tiempos a escala real.
