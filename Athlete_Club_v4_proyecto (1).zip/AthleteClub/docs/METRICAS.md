# Métricas de sesión

Implementación: `domain/metrics/RunMetrics.kt`. Tests: `app/src/test/.../RunMetricsTest.kt` (14 casos).

## Definiciones
| Métrica | Definición |
|---|---|
| Tiempo transcurrido | Desde el inicio hasta el final. **Incluye** pausas. |
| Tiempo activo | Suma de intervalos grabando. **Excluye** pausas y tramos perdidos por cierre de la app o reinicio. |
| Distancia | Suma dentro de cada segmento registrado. Entre segmentos (pausa, pérdida de señal, cierre) no se suma nada. |
| Velocidad media activa | Distancia / tiempo activo. |
| Ritmo medio activo | Tiempo activo / distancia (min/km). |
| Velocidad actual | Desplazamiento en los últimos 10 s. En una parada real es **0**. Sin fijos recientes (>10 s): «–». |
| Velocidad máxima | Máximo de velocidades suavizadas (ventanas de 10 s con ≥3 puntos y ≥5 s). Nunca de un único salto. |
| Velocidad mínima en movimiento | Mínimo de esas ventanas por encima de 1,8 km/h (excluye paradas). |
| Parciales | Tiempo en movimiento registrado para cada km, interpolando el cruce. |

Los tiempos se miden con el reloj monotónico del sistema (`elapsedRealtime`), así que **cambiar la hora no altera duraciones**. Tras un reinicio se usa el reloj de pared y se marca el hueco.

## Filtros
1. Se descartan fijos con precisión peor que **25 m**.
2. Se descartan fijos que implican una velocidad imposible **para el deporte** respecto al último aceptado (saltos de GPS).
   Sustituye al antiguo límite global de 45 km/h, que descartaba bicicleta válida:

   | Deporte | Velocidad máxima plausible | Ventana de velocidad actual |
   |---|---|---|
   | Correr | 45 km/h (12,5 m/s) | 10 s |
   | Sendero (a pie) | 25 km/h (7 m/s) | 10 s |
   | Caminata | 18 km/h (5 m/s) | 10 s |
   | Bicicleta | 90 km/h (25 m/s) | 6 s |

   Código: `domain/Sport.kt` (`SportRules`). Prueba: `SportTest.fastCyclingIsKeptWithBikeLimit`.
3. Posiciones suavizadas con una media centrada de **5 fijos** (ventana simétrica en los extremos).
4. Umbral anti-ruido **acumulado** desde un punto ancla: solo se suma cuando el desplazamiento supera `max(4 m, precisión declarada)`. Evita distancia fantasma estando parado sin perder distancia en trotes lentos.
5. Las velocidades de ventana usan los instantes de los puntos ancla para evitar sesgos.
6. Sin señal durante **15 s**: se registra el hueco y, al volver, se abre un segmento nuevo.

## Agregados (Progreso)
El ritmo de un periodo es **tiempo acumulado / distancia acumulada** de las actividades con distancia, no la media de ritmos. Las actividades manuales se cuentan aparte y no tienen ruta ni máximos o mínimos.


## Desnivel positivo (Sendero)

- Solo se guarda la altitud de un fijo si el sistema declara **precisión vertical ≤ 12 m** (`Location.verticalAccuracyMeters`).
- Se considera fiable si **≥ 70 %** de los puntos aceptados tienen altitud y hay **≥ 20**. Si no, se muestra «—».
- Altitud suavizada (media de 5) y suma con **histéresis de 4 m**, solo dentro de cada segmento (los huecos no suman).
- Prueba: `SportTest.elevationOnlyWhenReliable`.

## Cifra principal por deporte

Correr → ritmo actual (min/km) · Bicicleta → velocidad actual (km/h) · Sendero → distancia (+ desnivel) · Caminata → tiempo activo y distancia.
Se puede cambiar tocando la cifra; la elección se guarda por deporte.

## Sin datos

Siempre «—». Una parada real da velocidad 0.


## v3 — Mejor 1 km
`best1kMs`: ventana deslizante sobre puntos con precisión ≤15 m, sin huecos >10 s, interpolando la entrada y la salida del kilómetro.
Bicicleta lo muestra como velocidad (km/h); el resto como ritmo (min/km). Se guarda con la actividad y se recalcula al recortar.


## v4 — Cobertura de ruta verificada
`routeCoverage`: fracción del trazado (muestreado cada 10 m) con un punto válido de la actividad (precisión ≤ 30 m) a
menos de 35 m, si el avance sigue mayoritariamente un sentido (≥ 70 %; se admite el inverso). Cuenta como ruta completada
con ≥ 80 % y longitud de referencia > 0.
